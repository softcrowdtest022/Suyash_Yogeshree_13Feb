import React, { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  Grid,
  Button,
  Stack,
  alpha,
  CircularProgress,
  Avatar,
  Chip
} from '@mui/material';
import {
  ViewList as ViewListIcon,
  Assignment as AssignmentIcon,
  Description as DescriptionIcon,
  GppGood as GppGoodIcon,
  HowToReg as HowToRegIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../config/Config';

// Import utilities and constants
import { HEADER_GRADIENT, TEXT_COLOR_MAIN, TAB_CONFIG } from './components/utils/constants';
import { calculateCandidateProgress } from './components/utils/helpers';

// Import section components
import OfferManagement from './Offer/OfferManagement';
import DocumentManagement from './Documents/DocumentManagement';
import BGVManagement from './BGV/BGVManagement';
import OnboardingManagement from './Onboard/OnboardingManagement';
import StatsCard from './components/shared/StatsCard';

// Import all modal components 
import AddRequisition from '../requisitionmaster/AddRequisition';
import InitiateOffer from './Offer/InitiateOffer';
import SubmitOffer from './Offer/SubmitOffer';
import ApproveOffer from './Offer/ApproveOffer';
import OfferLetter from './Offer/OfferLetter';
import SendToCandidate from './Offer/SendToCandidate';
import AcceptOffer from './Offer/AcceptOffer';
import ViewOffer from './Offer/ViewOffer';
import UploadDoc from './Documents/UploadDoc';
import VerifyDoc from './Documents/VerifyDoc';
import ViewAllDoc from './Documents/ViewAllDoc';
import InitiateBGV from './BGV/InitiateBGV';
import ViewReportBGV from './BGV/ViewReportBGV';
import ViewStatusBGV from './BGV/ViewStatusBGV';
import CreateEmployee from './Onboard/CreateEmployee';
import AddDetails from './Onboard/AddDetails';
import GetStatus from './Onboard/GetStatus';
import MarkComplete from './Onboard/MarkComplete';

// const HEADER_GRADIENT = 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)';
// const TEXT_COLOR_MAIN = '#0f172a';
const PRIMARY_BLUE = '#00B4D8';

const SelectedCandidatesMaster = () => {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selected, setSelected] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  // Modal states
  const [selectedCandidateForAction, setSelectedCandidateForAction] = useState(null);
  const [selectedCandidateId, setSelectedCandidateId] = useState(null);
  const [selectedOfferId, setSelectedOfferId] = useState(null);
  const [selectedBGVId, setSelectedBGVId] = useState(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);

  // Modal open states
  const [openInitiateOffer, setOpenInitiateOffer] = useState(false);
  const [openSubmitOffer, setOpenSubmitOffer] = useState(false);
  const [openApproveOffer, setOpenApproveOffer] = useState(false);
  const [openOfferLetter, setOpenOfferLetter] = useState(false);
  const [openSendToCandidate, setOpenSendToCandidate] = useState(false);
  const [openAcceptOffer, setOpenAcceptOffer] = useState(false);
  const [openViewOffer, setOpenViewOffer] = useState(false);
  const [openUploadDoc, setOpenUploadDoc] = useState(false);
  const [openVerifyDoc, setOpenVerifyDoc] = useState(false);
  const [openViewAllDoc, setOpenViewAllDoc] = useState(false);
  const [openInitiateBGV, setOpenInitiateBGV] = useState(false);
  const [openViewBGVStatus, setOpenViewBGVStatus] = useState(false);
  const [openViewBGVReport, setOpenViewBGVReport] = useState(false);
  const [openCreateEmployee, setOpenCreateEmployee] = useState(false);
  const [openAddStatutory, setOpenAddStatutory] = useState(false);
  const [openOnboardingStatus, setOpenOnboardingStatus] = useState(false);
  const [openCompleteOnboarding, setOpenCompleteOnboarding] = useState(false);

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  const [stats, setStats] = useState({
    total: 0,
    offerInitiated: 0,
    offerApproved: 0,
    offerAccepted: 0,
    documentsPending: 0,
    bgvInitiated: 0,
    bgvCompleted: 0,
    onboardingCompleted: 0,
    totalOffers: 0,
    pendingApproval: 0,
    approved: 0,
    accepted: 0,
    totalDocuments: 0,
    verifiedDocuments: 0,
    pendingDocuments: 0,
    pendingVerification: 0,
    totalBGV: 0,
    bgvInProgress: 0,
    bgvFailed: 0,
    totalOnboarding: 0,
    onboardingNotStarted: 0,
    onboardingInProgress: 0
  });

  // Cache for storing fetched data to avoid multiple calls
  const [dataCache, setDataCache] = useState({
    offers: null,
    documents: null,
    bgv: null
  });

  useEffect(() => {
    fetchCandidates();
  }, []);

  const fetchCandidates = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');

      // Fetch all required data in parallel
      const [candidatesRes, offersRes, documentsRes, bgvRes] = await Promise.all([
        axios.get(`${BASE_URL}/api/candidates`, {
          headers: { 'Authorization': `Bearer ${token}` },
          params: { status: 'selected' }
        }).catch(() => ({ data: { success: false, data: [] } })),

        axios.get(`${BASE_URL}/api/offers`, {
          headers: { 'Authorization': `Bearer ${token}` }
        }).catch(() => ({ data: { success: false, data: [] } })),

        axios.get(`${BASE_URL}/api/documents`, {
          headers: { 'Authorization': `Bearer ${token}` }
        }).catch(() => ({ data: { success: false, data: [] } })),

        axios.get(`${BASE_URL}/api/bgv`, {
          headers: { 'Authorization': `Bearer ${token}` }
        }).catch(() => ({ data: { success: false, data: [] } }))
      ]);

      // Update cache
      setDataCache({
        offers: offersRes.data.success ? offersRes.data.data : [],
        documents: documentsRes.data.success ? documentsRes.data.data : [],
        bgv: bgvRes.data.success ? bgvRes.data.data : []
      });

      if (candidatesRes.data.success) {
        const candidatesData = candidatesRes.data.data || [];

        // Enhance candidates with related data
        const enhancedCandidates = await Promise.all(
          candidatesData.map(async (candidate) => {
            // Find related records by candidateId
            const candidateOffers = offersRes.data.success
              ? offersRes.data.data?.filter(o => o.candidateId === candidate._id) || []
              : [];

            const candidateOffer =
              candidateOffers.length > 0
                ? candidateOffers.sort(
                  (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
                )[0]   // ✅ latest offer
                : null;

            const candidateDocs = documentsRes.data.success
              ? documentsRes.data.data?.filter(doc => doc.candidateId === candidate._id) || []
              : [];

            const candidateBGV = bgvRes.data.success
              ? bgvRes.data.data?.find(bgv => bgv.candidateId === candidate._id)
              : null;

            // Fetch onboarding status separately (unique endpoint)
            let onboardingData = { status: 'not_started', steps: [] };
            try {
              const onboardingRes = await axios.get(`${BASE_URL}/api/onboarding/status/${candidate._id}`, {
                headers: { 'Authorization': `Bearer ${token}` }
              });
              if (onboardingRes.data.success) {
                onboardingData = onboardingRes.data.data;
              }
            } catch (err) {
              console.debug('Onboarding not available for candidate:', candidate._id);
            }

            return {
              ...candidate,
              offer: candidateOffer || null,
              documents: {
                total: candidateDocs.length,
                verified: candidateDocs.filter(doc => doc.status === 'verified').length,
                pending: candidateDocs.filter(doc => doc.status === 'pending').length,
                rejected: candidateDocs.filter(doc => doc.status === 'rejected').length,
                lastUpload: candidateDocs[0]?.uploadedAt,
                documents: candidateDocs
              },
              bgv: candidateBGV || null,
              onboarding: onboardingData
            };
          })
        );

        setCandidates(enhancedCandidates);
        calculateStats(enhancedCandidates);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
      showNotification('Failed to load candidates', 'error');
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (candidatesData) => {
    const stats = {
      total: candidatesData.length,
      offerInitiated: candidatesData.filter(c => c.offer && c.offer.status && c.offer.status !== 'draft').length,
      offerApproved: candidatesData.filter(c => c.offer && c.offer.status === 'approved').length,
      offerAccepted: candidatesData.filter(c => c.offer && c.offer.status === 'accepted').length,
      documentsPending: candidatesData.filter(c => c.documents && c.documents.pending > 0).length,
      bgvInitiated: candidatesData.filter(c => c.bgv && c.bgv.status && c.bgv.status !== 'not_started').length,
      bgvCompleted: candidatesData.filter(c => c.bgv && c.bgv.status === 'completed').length,
      onboardingCompleted: candidatesData.filter(c => c.onboarding && c.onboarding.status === 'completed').length,

      totalOffers: candidatesData.filter(c => c.offer).length,
      pendingApproval: candidatesData.filter(c => c.offer && c.offer.status === 'pending_approval').length,
      approved: candidatesData.filter(c => c.offer && c.offer.status === 'approved').length,
      accepted: candidatesData.filter(c => c.offer && c.offer.status === 'accepted').length,

      totalDocuments: candidatesData.reduce((acc, c) => acc + (c.documents?.total || 0), 0),
      verifiedDocuments: candidatesData.reduce((acc, c) => acc + (c.documents?.verified || 0), 0),
      pendingDocuments: candidatesData.reduce((acc, c) => acc + (c.documents?.pending || 0), 0),
      pendingVerification: candidatesData.filter(c => c.documents && c.documents.pending > 0).length,

      totalBGV: candidatesData.filter(c => c.bgv).length,
      bgvInProgress: candidatesData.filter(c => c.bgv && c.bgv.status === 'in_progress').length,
      bgvFailed: candidatesData.filter(c => c.bgv && c.bgv.status === 'failed').length,

      totalOnboarding: candidatesData.filter(c => c.onboarding).length,
      onboardingNotStarted: candidatesData.filter(c => !c.onboarding || c.onboarding.status === 'not_started').length,
      onboardingInProgress: candidatesData.filter(c => c.onboarding && c.onboarding.status === 'in_progress').length
    };
    setStats(stats);
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
    setPage(0);
    setSelected([]);
    setSearchTerm('');
  };

  const handleAction = (candidate, action) => {
    setSelectedCandidateForAction(candidate);
    setSelectedCandidateId(candidate._id);
    setSelectedOfferId(candidate.offer?._id);
    setSelectedBGVId(candidate.bgv?._id);
    setSelectedEmployeeId(candidate.employee?._id);

    switch (action) {
      // Offer Management
      case 'initiate_offer': setOpenInitiateOffer(true); break;
      case 'submit_offer':
        if (!candidate.offer?._id) {
          showNotification('No offer found for this candidate', 'error');
          return;
        }
        setOpenSubmitOffer(true);
        break;
      case 'approve_offer':
        if (!candidate.offer?._id) {
          showNotification('No offer found for this candidate', 'error');
          return;
        }
        setOpenApproveOffer(true);
        break;
      case 'offer_letter':
        if (!candidate.offer?._id) {
          showNotification('No offer letter found', 'error');
          return;
        }
        setOpenOfferLetter(true);
        break;
      case 'send_to_candidate':
        if (!candidate.offer?._id) {
          showNotification('No offer found to send', 'error');
          return;
        }
        setOpenSendToCandidate(true);
        break;
      case 'accept_offer':
        if (!candidate.offer?._id) {
          showNotification('No offer found to accept', 'error');
          return;
        }
        setOpenAcceptOffer(true);
        break;
      case 'view_offer':
        if (!candidate.offer?._id) {
          showNotification('No offer details found', 'error');
          return;
        }
        setOpenViewOffer(true);
        break;

      // Document Management
      case 'upload_doc': setOpenUploadDoc(true); break;
      case 'verify_doc': setOpenVerifyDoc(true); break;
      case 'view_docs': setOpenViewAllDoc(true); break;

      // BGV Management
      case 'initiate_bgv': setOpenInitiateBGV(true); break;
      case 'view_bgv_status':
        if (!candidate.bgv?._id) {
          showNotification('No BGV record found', 'error');
          return;
        }
        setOpenViewBGVStatus(true);
        break;
      case 'view_bgv_report':
        if (!candidate.bgv?._id) {
          showNotification('No BGV report found', 'error');
          return;
        }
        setOpenViewBGVReport(true);
        break;

      // Onboarding Management
      case 'create_employee': setOpenCreateEmployee(true); break;
      case 'add_statutory': setOpenAddStatutory(true); break;
      case 'onboarding_status': setOpenOnboardingStatus(true); break;
      case 'complete_onboarding': setOpenCompleteOnboarding(true); break;

      default: break;
    }
  };

  const handleModalClose = () => {
    setOpenInitiateOffer(false);
    setOpenSubmitOffer(false);
    setOpenApproveOffer(false);
    setOpenOfferLetter(false);
    setOpenSendToCandidate(false);
    setOpenAcceptOffer(false);
    setOpenViewOffer(false);
    setOpenUploadDoc(false);
    setOpenVerifyDoc(false);
    setOpenViewAllDoc(false);
    setOpenInitiateBGV(false);
    setOpenViewBGVStatus(false);
    setOpenViewBGVReport(false);
    setOpenCreateEmployee(false);
    setOpenAddStatutory(false);
    setOpenOnboardingStatus(false);
    setOpenCompleteOnboarding(false);
    setSelectedCandidateForAction(null);
  };

  const showNotification = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  const getFilteredCandidates = () => {
    if (!searchTerm) return candidates;

    const term = searchTerm.toLowerCase();
    return candidates.filter(candidate =>
      (candidate.name && candidate.name.toLowerCase().includes(term)) ||
      (candidate.email && candidate.email.toLowerCase().includes(term)) ||
      (candidate.phone && candidate.phone.includes(term)) ||
      (candidate.position && candidate.position.toLowerCase().includes(term)) ||
      (candidate.offer?.offerId && candidate.offer.offerId.toLowerCase().includes(term))
    );
  };

  const sharedProps = {
    candidates: getFilteredCandidates(),
    loading,
    onRefresh: fetchCandidates,
    onAction: handleAction,
    selected,
    onSelect: (id) => {
      const selectedIndex = selected.indexOf(id);
      let newSelected = [];
      if (selectedIndex === -1) {
        newSelected = newSelected.concat(selected, id);
      } else {
        newSelected = selected.filter(item => item !== id);
      }
      setSelected(newSelected);
    },
    onSelectAll: (event) => {
      if (event.target.checked) {
        setSelected(getFilteredCandidates().map(c => c._id));
      } else {
        setSelected([]);
      }
    },
    searchTerm,
    onSearchChange: (e) => setSearchTerm(e.target.value),
    page,
    rowsPerPage,
    onPageChange: (event, newPage) => setPage(newPage),
    onRowsPerPageChange: (event) => {
      setRowsPerPage(parseInt(event.target.value, 10));
      setPage(0);
    },
    stats,
    dataCache
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Typography
          variant="h5"
          component="h1"
          fontWeight="600"
          sx={{
            color: TEXT_COLOR_MAIN,
            background: HEADER_GRADIENT,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            display: 'inline-block'
          }}
        >
          Selected Candidates Master
        </Typography>
        <Typography variant="body2" color="#64748B" sx={{ mt: 0.5 }}>
          Manage selected candidates through offer, document, BGV, and onboarding processes
        </Typography>
      </Box>

      {/* Tabs */}
      <Paper sx={{ mb: 3, borderRadius: 2, overflow: 'hidden' }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            bgcolor: '#FFFFFF',
            borderBottom: '1px solid #e2e8f0',
            '& .MuiTab-root': {
              minHeight: 48,
              fontWeight: 500,
              textTransform: 'none',
              fontSize: '0.875rem'
            },
            '& .Mui-selected': {
              color: PRIMARY_BLUE,
              fontWeight: 600
            },
            '& .MuiTabs-indicator': {
              backgroundColor: PRIMARY_BLUE,
              height: 3
            }
          }}
        >
          <Tab icon={<ViewListIcon sx={{ fontSize: 20, mr: 1 }} />} label="Overview" iconPosition="start" />
          <Tab icon={<AssignmentIcon sx={{ fontSize: 20, mr: 1 }} />} label="Offer Management" iconPosition="start" />
          <Tab icon={<DescriptionIcon sx={{ fontSize: 20, mr: 1 }} />} label="Documents" iconPosition="start" />
          <Tab icon={<GppGoodIcon sx={{ fontSize: 20, mr: 1 }} />} label="BGV" iconPosition="start" />
          <Tab icon={<HowToRegIcon sx={{ fontSize: 20, mr: 1 }} />} label="Onboarding" iconPosition="start" />
        </Tabs>
      </Paper>

      {/* Section Components */}
      {activeTab === 0 && (
        <Box>
          {/* Enhanced Stats Cards Section */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <StatsCard
                title="Total Selected"
                value={stats.total}
                icon={ViewListIcon}
                color="#00B4D8"
                // cardBgColor="#164e63" // Dark blue background
                trend={stats.total > 0 ? '+12%' : '0%'}
                trendDirection="up"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatsCard
                title="Offer Accepted"
                value={stats.offerAccepted}
                icon={AssignmentIcon}
                color="#10B981"
                // cardBgColor="#7C3AED" // Purple background
                subtitle={`${stats.offerApproved} pending approval`}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatsCard
                title="BGV Completed"
                value={stats.bgvCompleted}
                icon={GppGoodIcon}
                color="#8B5CF6"
                subtitle={`${stats.bgvInProgress} in progress`}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatsCard
                title="Onboarded"
                value={stats.onboardingCompleted}
                icon={HowToRegIcon}
                color="#3B82F6"
                subtitle={`${stats.onboardingInProgress} in progress`}
              />
            </Grid>
          </Grid>

          {/* Quick Stats Row */}
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 3, borderRadius: 2, height: '100%' }}>
                <Typography variant="h6" gutterBottom>Process Overview</Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Box sx={{ textAlign: 'center', p: 2 }}>
                      <Typography variant="h4" color={PRIMARY_BLUE}>{stats.totalOffers}</Typography>
                      <Typography variant="body2" color="#64748B">Total Offers</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box sx={{ textAlign: 'center', p: 2 }}>
                      <Typography variant="h4" color="#F59E0B">{stats.pendingApproval}</Typography>
                      <Typography variant="body2" color="#64748B">Pending Approval</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box sx={{ textAlign: 'center', p: 2 }}>
                      <Typography variant="h4" color="#10B981">{stats.verifiedDocuments}</Typography>
                      <Typography variant="body2" color="#64748B">Verified Docs</Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box sx={{ textAlign: 'center', p: 2 }}>
                      <Typography variant="h4" color="#EF4444">{stats.pendingDocuments}</Typography>
                      <Typography variant="body2" color="#64748B">Pending Docs</Typography>
                    </Box>
                  </Grid>
                </Grid>
              </Paper>
            </Grid>

            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 3, borderRadius: 2, height: '100%' }}>
                <Typography variant="h6" gutterBottom>Recent Candidates</Typography>
                {loading ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                    <CircularProgress size={32} />
                  </Box>
                ) : candidates.slice(0, 3).map((candidate, index) => (
                  <Stack key={index} direction="row" spacing={2} alignItems="center" sx={{ py: 1 }}>
                    <Avatar sx={{ bgcolor: '#00B4D8', width: 32, height: 32 }}>
                      {candidate.name?.charAt(0) || 'U'}
                    </Avatar>
                    <Box flex={1}>
                      <Typography variant="body2" fontWeight={500}>{candidate.name}</Typography>
                      <Typography variant="caption" color="#64748B">{candidate.position || 'N/A'}</Typography>
                    </Box>
                    <Chip
                      label={candidate.offer?.status || 'No Offer'}
                      size="small"
                      sx={{
                        bgcolor: candidate.offer?.status === 'accepted' ? alpha('#10B981', 0.1) : alpha('#F59E0B', 0.1),
                        color: candidate.offer?.status === 'accepted' ? '#10B981' : '#F59E0B',
                      }}
                    />
                  </Stack>
                ))}
                {!loading && candidates.length === 0 && (
                  <Typography color="#64748B" sx={{ py: 4, textAlign: 'center' }}>
                    No candidates found
                  </Typography>
                )}
              </Paper>
            </Grid>
          </Grid>

          {/* Action Buttons */}
          <Stack direction="row" spacing={2} justifyContent="flex-end">
            <Button
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={fetchCandidates}
              sx={{ borderRadius: 1.5, textTransform: 'none' }}
            >
              Refresh Data
            </Button>
          </Stack>
        </Box>
      )}

      {activeTab === 1 && <OfferManagement {...sharedProps} />}
      {activeTab === 2 && <DocumentManagement {...sharedProps} />}
      {activeTab === 3 && <BGVManagement {...sharedProps} />}
      {activeTab === 4 && <OnboardingManagement {...sharedProps} />}

      {/* Modals */}
      <InitiateOffer
        open={openInitiateOffer}
        onClose={handleModalClose}
        onInitiate={() => {
          showNotification('Offer initiated successfully');
          fetchCandidates();
        }}
        candidateId={selectedCandidateId}
      />

      <SubmitOffer
        open={openSubmitOffer}
        candidateId={selectedCandidateId}
        onClose={handleModalClose}
        onSubmit={() => {
          showNotification('Offer submitted for approval');
          fetchCandidates();
        }}
        offerId={selectedOfferId}
      />

      <ApproveOffer
        open={openApproveOffer}
        onClose={handleModalClose}
        onApprove={() => {
          showNotification('Offer approved/rejected');
          fetchCandidates();
        }}
        offerId={selectedOfferId}
      />

      <OfferLetter
        open={openOfferLetter}
        onClose={handleModalClose}
        offerId={selectedOfferId}
      />

      <SendToCandidate
        open={openSendToCandidate}
        onClose={handleModalClose}
        onSend={() => {
          showNotification('Offer sent to candidate');
          fetchCandidates();
        }}
        offerId={selectedOfferId}
      />

      <AcceptOffer
        open={openAcceptOffer}
        onClose={handleModalClose}
        onAccept={() => {
          showNotification('Offer accepted');
          fetchCandidates();
        }}
        offerId={selectedOfferId}
        offerToken={selectedCandidateForAction?.offer?.shareToken}
      />

      <ViewOffer
        open={openViewOffer}
        onClose={handleModalClose}
        offerId={selectedOfferId}
        offerToken={selectedCandidateForAction?.offer?.shareToken}
      />

      <UploadDoc
        open={openUploadDoc}
        onClose={handleModalClose}
        onUpload={() => {
          showNotification('Document uploaded successfully');
          fetchCandidates();
        }}
        candidateId={selectedCandidateId}
      />

      <VerifyDoc
        open={openVerifyDoc}
        onClose={handleModalClose}
        onVerify={() => {
          showNotification('Document verified');
          fetchCandidates();
        }}
        documentId={selectedCandidateForAction?.documents?.documents?.[0]?._id}
      />

      <ViewAllDoc
        open={openViewAllDoc}
        onClose={handleModalClose}
        candidateId={selectedCandidateId}
        onDocumentAction={(action, doc) => {
          if (action === 'verify') {
            handleAction(selectedCandidateForAction, 'verify_doc');
          }
        }}
      />

      <InitiateBGV
        open={openInitiateBGV}
        onClose={handleModalClose}
        onInitiate={() => {
          showNotification('BGV initiated successfully');
          fetchCandidates();
        }}
        candidateId={selectedCandidateId}
        offerId={selectedOfferId}
      />

      <ViewStatusBGV
        open={openViewBGVStatus}
        onClose={handleModalClose}
        bgvId={selectedBGVId}
      />

      <ViewReportBGV
        open={openViewBGVReport}
        onClose={handleModalClose}
        bgvId={selectedBGVId}
      />

      <CreateEmployee
        open={openCreateEmployee}
        onClose={handleModalClose}
        onCreate={() => {
          showNotification('Employee created successfully');
          fetchCandidates();
        }}
        candidateId={selectedCandidateId}
      />

      <AddDetails
        open={openAddStatutory}
        onClose={handleModalClose}
        onAdd={() => {
          showNotification('Statutory details added');
          fetchCandidates();
        }}
        employeeId={selectedEmployeeId}
      />

      <GetStatus
        open={openOnboardingStatus}
        onClose={handleModalClose}
        candidateId={selectedCandidateId}
      />

      <MarkComplete
        open={openCompleteOnboarding}
        onClose={handleModalClose}
        onComplete={() => {
          showNotification('Onboarding completed');
          fetchCandidates();
        }}
        candidateId={selectedCandidateId}
      />

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          variant="filled"
          sx={{ borderRadius: 1.5 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default SelectedCandidatesMaster;