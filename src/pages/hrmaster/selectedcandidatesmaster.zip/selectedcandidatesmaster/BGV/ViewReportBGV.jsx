import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Feedback components
  Alert,  // Moved Alert here from comments
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
  // Progress
  LinearProgress,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
  // Tabs
  Tab,
  Tabs,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  
} from '@mui/material';

// Icons - REMOVED Alert from here since it's not an icon
import {
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  LocationOn as LocationIcon,
  Badge as BadgeIcon,
  Verified as VerifiedIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Close as CloseIcon,
  Visibility as VisibilityIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Share as ShareIcon,
  Description as DescriptionIcon,
  PictureAsPdf as PdfIcon,
  Image as ImageIcon,
  InsertDriveFile as FileIcon,
  Security as SecurityIcon,
  Fingerprint as FingerprintIcon,
  GppGood as GppGoodIcon,
  GppMaybe as GppMaybeIcon,
  GppBad as GppBadIcon,
  Shield as ShieldIcon,
  VerifiedUser as VerifiedUserIcon,
  Assignment as AssignmentIcon,
  Assessment as AssessmentIcon,
  Report as ReportIcon,
  Timeline as TimelineIcon,
  History as HistoryIcon,
  FilePresent as FilePresentIcon,
  CloudDownload as CloudDownloadIcon,
  OpenInNew as OpenInNewIcon,
  PlayArrow as PlayArrowIcon,
  Stop as StopIcon,
  HourglassEmpty as HourglassIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    pending: { bg: '#FFF3E0', color: '#E65100' },
    initiated: { bg: '#E3F2FD', color: '#1976D2' },
    in_progress: { bg: '#E3F2FD', color: '#1976D2' },
    completed: { bg: '#E8F5E9', color: '#2E7D32' },
    cleared: { bg: '#E8F5E9', color: '#2E7D32' },
    rejected: { bg: '#FFEBEE', color: '#C62828' },
    failed: { bg: '#FFEBEE', color: '#C62828' },
    on_hold: { bg: '#F3E5F5', color: '#7B1FA2' },
    generating: { bg: '#E1F5FE', color: '#0288D1' },
    generated: { bg: '#E8F5E9', color: '#2E7D32' },
    not_available: { bg: '#F5F5F5', color: '#9E9E9E' }
  };
  const color = colors[status] || colors.pending;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const InfoCard = styled(Card)(({ theme }) => ({
  backgroundColor: '#F8FAFC',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const ReportCard = styled(Card)(({ theme }) => ({
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  transition: 'all 0.2s',
  cursor: 'pointer',
  '&:hover': {
    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
    transform: 'translateY(-2px)'
  }
}));

const ViewReportBGV = ({ open, onClose, onView, bgvId: propBGVId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState({
    bgvId: propBGVId || '',
    reportFormat: 'pdf', // 'pdf', 'html', 'json'
    includeDetails: true,
    includeSummary: true,
    includeChecks: true
  });

  // BGV list dropdown state
  const [bgvList, setBGVList] = useState([]);
  const [bgvLoading, setBGVLoading] = useState(false);
  const [bgvSearch, setBGVSearch] = useState('');
  const [bgvOpen, setBGVOpen] = useState(false);
  const [bgvPage, setBGVPage] = useState(1);
  const [bgvTotalPages, setBGVTotalPages] = useState(1);
  const [bgvInputValue, setBGVInputValue] = useState('');

  // BGV details state
  const [bgvDetails, setBGVDetails] = useState(null);
  const [bgvDetailsLoading, setBGVDetailsLoading] = useState(false);
  
  // Report state
  const [reportData, setReportData] = useState(null);
  const [reportLoading, setReportLoading] = useState(false);
  const [reportUrl, setReportUrl] = useState(null);
  const [reportGeneratedAt, setReportGeneratedAt] = useState(null);
  const [reportStatus, setReportStatus] = useState('not_available'); // 'not_available', 'generating', 'generated', 'failed'

  // Candidate details
  const [candidateDetails, setCandidateDetails] = useState(null);
  
  // Report generation timer (for polling)
  const [generationTimer, setGenerationTimer] = useState(null);
  const [generationAttempts, setGenerationAttempts] = useState(0);
  const MAX_GENERATION_ATTEMPTS = 30; // 30 attempts * 2 seconds = 1 minute max wait

  // Viewing state
  const [viewing, setViewing] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // Preview dialog
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewUrl, setPreviewUrl] = useState('');

  // Steps definition
  const steps = ['Select BGV', 'View Report', 'Download/Share'];

  // Fetch BGV list
  const fetchBGVList = async (search = '', page = 1) => {
    setBGVLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/bgv`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setBGVList(response.data.data || []);
        } else {
          setBGVList(prev => [...prev, ...(response.data.data || [])]);
        }
        setBGVTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching BGV list:', err);
    } finally {
      setBGVLoading(false);
    }
  };

  // Fetch BGV details
  const fetchBGVDetails = async (bgvId) => {
    if (!bgvId) return;
    
    setBGVDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/bgv/${bgvId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setBGVDetails(response.data.data);
        
        // Fetch candidate details
        if (response.data.data.candidateId) {
          fetchCandidateDetails(response.data.data.candidateId);
        }
        
        // Check report status
        checkReportStatus(bgvId);
      }
    } catch (err) {
      console.error('Error fetching BGV details:', err);
    } finally {
      setBGVDetailsLoading(false);
    }
  };

  // Fetch candidate details
  const fetchCandidateDetails = async (candidateId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setCandidateDetails(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching candidate details:', err);
    }
  };

  // Check report status
  const checkReportStatus = async (bgvId) => {
    if (!bgvId) return;
    
    setReportLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/bgv/${bgvId}/report`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setReportData(response.data.data);
        
        if (response.data.data.reportUrl) {
          setReportUrl(response.data.data.reportUrl);
          setReportGeneratedAt(response.data.data.generatedAt);
          setReportStatus('generated');
          stopGenerationTimer();
        } else {
          setReportStatus('not_available');
          
          // If BGV is completed but report not generated, start generation
          if (bgvDetails && bgvDetails.status === 'completed') {
            startGenerationTimer(bgvId);
          }
        }
      }
    } catch (err) {
      console.error('Error checking report status:', err);
      if (err.response && err.response.status === 404) {
        setReportStatus('not_available');
      } else {
        setReportStatus('failed');
      }
    } finally {
      setReportLoading(false);
    }
  };

  // Generate report
  const generateReport = async (bgvId) => {
    if (!bgvId) return;
    
    setReportStatus('generating');
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${BASE_URL}/api/bgv/${bgvId}/generate-report`,
        {}, // Empty body
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      if (response.data.success) {
        // Start polling for report
        startGenerationTimer(bgvId);
      } else {
        setReportStatus('failed');
        setError(response.data.message || 'Failed to generate report');
      }
    } catch (err) {
      console.error('Error generating report:', err);
      setReportStatus('failed');
      setError(err.response?.data?.message || 'Failed to generate report');
    }
  };

  // Start generation timer (polling)
  const startGenerationTimer = (bgvId) => {
    if (generationTimer) {
      clearInterval(generationTimer);
    }
    
    setGenerationAttempts(0);
    
    const timer = setInterval(() => {
      setGenerationAttempts(prev => {
        const newAttempts = prev + 1;
        
        if (newAttempts >= MAX_GENERATION_ATTEMPTS) {
          // Stop polling after max attempts
          clearInterval(timer);
          setReportStatus('failed');
          setError('Report generation timed out. Please try again.');
          return prev;
        }
        
        // Check report status
        checkReportStatus(bgvId);
        return newAttempts;
      });
    }, 2000); // Check every 2 seconds
    
    setGenerationTimer(timer);
  };

  // Stop generation timer
  const stopGenerationTimer = () => {
    if (generationTimer) {
      clearInterval(generationTimer);
      setGenerationTimer(null);
    }
    setGenerationAttempts(0);
  };

  // Load BGV list when dropdown opens
  useEffect(() => {
    if (bgvOpen) {
      fetchBGVList(bgvSearch, 1);
    }
  }, [bgvOpen]);

  // Search BGV with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (bgvOpen) {
        setBGVPage(1);
        fetchBGVList(bgvSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [bgvSearch, bgvOpen]);

  // Load BGV details when selected
  useEffect(() => {
    if (formData.bgvId) {
      fetchBGVDetails(formData.bgvId);
    } else {
      setBGVDetails(null);
      setCandidateDetails(null);
      setReportUrl(null);
      setReportStatus('not_available');
    }
    
    // Cleanup timer on unmount or when BGV changes
    return () => {
      stopGenerationTimer();
    };
  }, [formData.bgvId]);

  // Cleanup timer on component unmount
  useEffect(() => {
    return () => {
      stopGenerationTimer();
    };
  }, []);

  // Handle BGV scroll load more
  const handleBGVScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (bgvPage < bgvTotalPages && !bgvLoading) {
        const nextPage = bgvPage + 1;
        setBGVPage(nextPage);
        fetchBGVList(bgvSearch, nextPage);
      }
    }
  };

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'includeDetails' || name === 'includeSummary' || name === 'includeChecks' ? checked : value
    }));

    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.bgvId) {
        errors.bgvId = 'Please select a BGV record';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors({});
    // Small delay before retrying
    setTimeout(() => {
      if (formData.bgvId) {
        checkReportStatus(formData.bgvId);
      }
    }, 500);
  };

  const handleGenerateReport = () => {
    if (formData.bgvId) {
      generateReport(formData.bgvId);
    }
  };

  const handleViewReport = async () => {
    if (!reportUrl) {
      setError('Report not available');
      return;
    }

    setViewing(true);
    
    try {
      // If reportUrl is a full URL, open it directly
      if (reportUrl.startsWith('http')) {
        window.open(reportUrl, '_blank');
      } else {
        // Otherwise, fetch from API
        const token = localStorage.getItem('token');
        const response = await axios.get(`${BASE_URL}${reportUrl}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          },
          responseType: 'blob'
        });

        const url = window.URL.createObjectURL(new Blob([response.data]));
        setPreviewUrl(url);
        setPreviewOpen(true);
      }
    } catch (err) {
      console.error('Error viewing report:', err);
      setError('Failed to view report');
    } finally {
      setViewing(false);
    }
  };

  const handleDownloadReport = async () => {
    if (!reportUrl) {
      setError('Report not available');
      return;
    }

    setViewing(true);
    
    try {
      let blob;
      let filename = `bgv-report-${formData.bgvId}.pdf`;

      // If reportUrl is a full URL, fetch it
      if (reportUrl.startsWith('http')) {
        const response = await axios.get(reportUrl, {
          responseType: 'blob'
        });
        blob = new Blob([response.data]);
      } else {
        // Otherwise, fetch from API
        const token = localStorage.getItem('token');
        const response = await axios.get(`${BASE_URL}${reportUrl}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          },
          responseType: 'blob'
        });
        blob = new Blob([response.data]);
      }

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Error downloading report:', err);
      setError('Failed to download report');
    } finally {
      setViewing(false);
    }
  };

  const handleShareReport = () => {
    // Share functionality (could open email dialog, etc.)
    setError('Share functionality coming soon');
  };

  const handlePrintReport = () => {
    if (reportUrl) {
      handleViewReport(); // Open in new tab, user can print from there
    }
  };

  const resetForm = () => {
    setFormData({
      bgvId: propBGVId || '',
      reportFormat: 'pdf',
      includeDetails: true,
      includeSummary: true,
      includeChecks: true
    });
    setBGVDetails(null);
    setCandidateDetails(null);
    setReportData(null);
    setReportUrl(null);
    setReportStatus('not_available');
    setError('');
    setValidationErrors({});
    setSuccess(false);
    setActiveStep(0);
    setActiveTab(0);
    setBGVSearch('');
    setBGVInputValue('');
    stopGenerationTimer();
    setRetryCount(0);
  };

  const handleClose = () => {
    stopGenerationTimer();
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status icon - FIXED: Changed HourglassEmptyIcon to HourglassIcon
  const getStatusIcon = (status) => {
    switch(status) {
      case 'generated':
        return <CheckCircleIcon sx={{ fontSize: 16, color: '#4CAF50' }} />;
      case 'generating':
        return <HourglassIcon sx={{ fontSize: 16, color: '#0288D1' }} />; // Changed from HourglassEmptyIcon to HourglassIcon
      case 'failed':
        return <ErrorIcon sx={{ fontSize: 16, color: '#F44336' }} />;
      default:
        return <FilePresentIcon sx={{ fontSize: 16, color: '#9E9E9E' }} />;
    }
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select BGV */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select BGV Record
              </Typography>

              <Grid container spacing={1.5}>
                <Grid item xs={12}>
                  <Autocomplete
                    size="small"
                    id="bgv-autocomplete"
                    open={bgvOpen}
                    onOpen={() => setBGVOpen(true)}
                    onClose={() => setBGVOpen(false)}
                    options={bgvList}
                    loading={bgvLoading}
                    value={formData.bgvId ? bgvList.find(b => b._id === formData.bgvId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        bgvId: newValue?._id || null 
                      }));
                      if (validationErrors.bgvId) {
                        setValidationErrors(prev => ({ ...prev, bgvId: '' }));
                      }
                    }}
                    inputValue={bgvInputValue}
                    onInputChange={(event, newInputValue) => {
                      setBGVInputValue(newInputValue);
                      setBGVSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.bgvId || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select BGV Record"
                        required
                        error={!!validationErrors.bgvId}
                        helperText={validationErrors.bgvId}
                        size="small"
                        placeholder="Search by BGV ID or Candidate Name"
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {bgvLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.bgvId}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.candidateName} • Status: {option.status}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleBGVScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* BGV Quick Info */}
            {bgvDetailsLoading && (
              <Box sx={{ py: 2, textAlign: 'center' }}>
                <CircularProgress size={24} />
              </Box>
            )}

            {bgvDetails && !bgvDetailsLoading && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  BGV Information
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>BGV ID</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{bgvDetails.bgvId}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Status</Typography>
                    <StatusChip 
                      label={bgvDetails.status} 
                      size="small"
                      status={bgvDetails.status}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Initiated On</Typography>
                    <Typography variant="body2">{formatDateTime(bgvDetails.initiatedAt)}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Completed On</Typography>
                    <Typography variant="body2">{bgvDetails.completedAt ? formatDateTime(bgvDetails.completedAt) : 'Not completed'}</Typography>
                  </Grid>
                </Grid>
              </Paper>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Candidate Info */}
            {candidateDetails && (
              <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Candidate Information
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid item xs={12} sm={6}>
                    <DetailRow>
                      <DetailIcon><PersonIcon /></DetailIcon>
                      <Box>
                        <Typography variant="caption" color="textSecondary">Name</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>{candidateDetails.name}</Typography>
                      </Box>
                    </DetailRow>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <DetailRow>
                      <DetailIcon><EmailIcon /></DetailIcon>
                      <Box>
                        <Typography variant="caption" color="textSecondary">Email</Typography>
                        <Typography variant="body2">{candidateDetails.email}</Typography>
                      </Box>
                    </DetailRow>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <DetailRow>
                      <DetailIcon><PhoneIcon /></DetailIcon>
                      <Box>
                        <Typography variant="caption" color="textSecondary">Phone</Typography>
                        <Typography variant="body2">{candidateDetails.phone}</Typography>
                      </Box>
                    </DetailRow>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <DetailRow>
                      <DetailIcon><WorkIcon /></DetailIcon>
                      <Box>
                        <Typography variant="caption" color="textSecondary">Position</Typography>
                        <Typography variant="body2">{candidateDetails.position || 'N/A'}</Typography>
                      </Box>
                    </DetailRow>
                  </Grid>
                </Grid>
              </Paper>
            )}

            {/* Report Status */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Report Status
              </Typography>

              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  {reportLoading ? (
                    <CircularProgress size={24} sx={{ mr: 2 }} />
                  ) : (
                    <Box sx={{ mr: 2 }}>
                      {getStatusIcon(reportStatus)}
                    </Box>
                  )}
                  <Box>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      Report Status: <StatusChip 
                        label={reportStatus.replace('_', ' ')} 
                        size="small"
                        status={reportStatus}
                      />
                    </Typography>
                    {reportGeneratedAt && (
                      <Typography variant="caption" color="textSecondary">
                        Generated on: {formatDateTime(reportGeneratedAt)}
                      </Typography>
                    )}
                    {reportStatus === 'generating' && (
                      <Typography variant="caption" color="textSecondary" sx={{ display: 'block' }}>
                        Generating report... {generationAttempts * 2} seconds elapsed
                        <LinearProgress sx={{ mt: 1, width: 200 }} />
                      </Typography>
                    )}
                  </Box>
                </Box>

                {reportStatus === 'not_available' && bgvDetails?.status === 'completed' && (
                  <Button
                    variant="contained"
                    size="small"
                    onClick={handleGenerateReport}
                    startIcon={<PlayArrowIcon />}
                  >
                    Generate Report
                  </Button>
                )}
              </Box>
            </Paper>

            {/* Report Preview */}
            {reportStatus === 'generated' && reportUrl && (
              <ReportCard onClick={handleViewReport}>
                <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <PdfIcon sx={{ fontSize: 40, color: '#C62828', mr: 2 }} />
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="subtitle2">BGV Report</Typography>
                      <Typography variant="caption" color="textSecondary">
                        bgv-report-{formData.bgvId}.pdf • Generated on {formatDateTime(reportGeneratedAt)}
                      </Typography>
                    </Box>
                    <Chip 
                      icon={<CheckCircleIcon />}
                      label="Available"
                      size="small"
                      sx={{ backgroundColor: '#E8F5E9', color: '#2E7D32' }}
                    />
                  </Box>
                </CardContent>
              </ReportCard>
            )}

            {/* No Report State */}
            {reportStatus === 'not_available' && (
              <Paper sx={{ p: 3, textAlign: 'center', backgroundColor: '#F8FAFC' }}>
                <FilePresentIcon sx={{ fontSize: 48, color: '#BDBDBD', mb: 2 }} />
                <Typography variant="body1" color="textSecondary" gutterBottom>
                  No report available
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  {bgvDetails?.status === 'completed' 
                    ? 'Click "Generate Report" to create the BGV report'
                    : 'Report will be available once BGV is completed'}
                </Typography>
              </Paper>
            )}

            {/* Error State */}
            {error && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  <Button color="inherit" size="small" onClick={handleRetry}>
                    Retry
                  </Button>
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Report Actions */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Report Actions
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<VisibilityIcon />}
                    onClick={handleViewReport}
                    disabled={reportStatus !== 'generated'}
                    sx={{ justifyContent: 'flex-start', p: 1.5 }}
                  >
                    <Box sx={{ textAlign: 'left' }}>
                      <Typography variant="body2">View Report</Typography>
                      <Typography variant="caption" color="textSecondary">
                        Open report in browser
                      </Typography>
                    </Box>
                  </Button>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<DownloadIcon />}
                    onClick={handleDownloadReport}
                    disabled={reportStatus !== 'generated'}
                    sx={{ justifyContent: 'flex-start', p: 1.5 }}
                  >
                    <Box sx={{ textAlign: 'left' }}>
                      <Typography variant="body2">Download Report</Typography>
                      <Typography variant="caption" color="textSecondary">
                        Save as PDF file
                      </Typography>
                    </Box>
                  </Button>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<PrintIcon />}
                    onClick={handlePrintReport}
                    disabled={reportStatus !== 'generated'}
                    sx={{ justifyContent: 'flex-start', p: 1.5 }}
                  >
                    <Box sx={{ textAlign: 'left' }}>
                      <Typography variant="body2">Print Report</Typography>
                      <Typography variant="caption" color="textSecondary">
                        Send to printer
                      </Typography>
                    </Box>
                  </Button>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Button
                    fullWidth
                    variant="outlined"
                    startIcon={<ShareIcon />}
                    onClick={handleShareReport}
                    disabled={reportStatus !== 'generated'}
                    sx={{ justifyContent: 'flex-start', p: 1.5 }}
                  >
                    <Box sx={{ textAlign: 'left' }}>
                      <Typography variant="body2">Share Report</Typography>
                      <Typography variant="caption" color="textSecondary">
                        Email or share link
                      </Typography>
                    </Box>
                  </Button>
                </Grid>
              </Grid>
            </Paper>

            {/* Report Options */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Report Options
              </Typography>

              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Report Format</InputLabel>
                    <Select
                      name="reportFormat"
                      value={formData.reportFormat}
                      onChange={handleChange}
                      label="Report Format"
                      disabled
                    >
                      <MenuItem value="pdf">PDF Document</MenuItem>
                      <MenuItem value="html">HTML Page</MenuItem>
                      <MenuItem value="json">JSON Data</MenuItem>
                    </Select>
                    <FormHelperText>PDF format is currently supported</FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={4}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="includeSummary"
                        checked={formData.includeSummary}
                        onChange={handleChange}
                        size="small"
                        disabled
                      />
                    }
                    label="Include Summary"
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="includeDetails"
                        checked={formData.includeDetails}
                        onChange={handleChange}
                        size="small"
                        disabled
                      />
                    }
                    label="Include Details"
                  />
                </Grid>
                <Grid item xs={12} sm={4}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="includeChecks"
                        checked={formData.includeChecks}
                        onChange={handleChange}
                        size="small"
                        disabled
                      />
                    }
                    label="Include Check Results"
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Report Info */}
            <Alert severity="info" sx={{ borderRadius: 1 }} icon={<ReportIcon />}>
              <Typography variant="body2">
                <strong>Report Information:</strong> The BGV report contains detailed verification results
                including address confirmation, employment history, education verification, and criminal record check.
              </Typography>
            </Alert>
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 1.5,
            maxHeight: '95vh',
            overflow: 'auto'
          }
        }}
      >
        <DialogTitle sx={{
          borderBottom: '1px solid #E0E0E0',
          py: 1.5,
          px: 2,
          backgroundColor: '#F8FAFC',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
            View BGV Report
          </Typography>
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>

        <DialogContent sx={{ p: 2, overflow: 'auto' }}>
          {/* Stepper */}
          <Stepper
            activeStep={activeStep}
            alternativeLabel
            connector={<ColorConnector />}
            sx={{ mb: 2, mt: 1 }}
          >
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>
                  <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                </StepLabel>
              </Step>
            ))}
          </Stepper>

          {renderStepContent(activeStep)}
        </DialogContent>

        <DialogActions sx={{
          px: 2,
          py: 1.5,
          borderTop: '1px solid #E0E0E0',
          backgroundColor: '#F8FAFC',
          justifyContent: 'space-between'
        }}>
          <Button
            onClick={handleBack}
            disabled={activeStep === 0 || viewing}
            size="small"
            sx={{ color: '#666' }}
          >
            Back
          </Button>
          <Box>
            <Button
              onClick={handleClose}
              disabled={viewing}
              size="small"
              sx={{ mr: 1, color: '#666' }}
            >
              Close
            </Button>
            {activeStep === steps.length - 1 ? (
              <Button
                variant="contained"
                onClick={handleClose}
                size="small"
              >
                Done
              </Button>
            ) : (
              <Button
                variant="contained"
                onClick={handleNext}
                disabled={viewing || !formData.bgvId}
                size="small"
                sx={{
                  backgroundColor: '#1976D2',
                  '&:hover': { backgroundColor: '#1565C0' }
                }}
              >
                Next
              </Button>
            )}
          </Box>
        </DialogActions>
      </Dialog>

      {/* Report Preview Dialog */}
      <Dialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle sx={{ 
          borderBottom: '1px solid #E0E0E0',
          py: 1.5,
          px: 2,
          backgroundColor: '#F8FAFC',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Typography variant="subtitle2">
            BGV Report - {bgvDetails?.bgvId}
          </Typography>
          <Box>
            <IconButton size="small" onClick={handleDownloadReport} sx={{ mr: 1 }}>
              <DownloadIcon fontSize="small" />
            </IconButton>
            <IconButton size="small" onClick={() => setPreviewOpen(false)}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ p: 0, height: '70vh' }}>
          <iframe
            src={previewUrl}
            style={{ width: '100%', height: '100%', border: 'none' }}
            title="BGV Report Preview"
          />
        </DialogContent>
      </Dialog>

      {/* Success Snackbar */}
      <Snackbar
        open={success}
        autoHideDuration={3000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity="success" sx={{ width: '100%' }} onClose={() => setSuccess(false)}>
          Report downloaded successfully
        </Alert>
      </Snackbar>
    </>
  );
};

export default ViewReportBGV;