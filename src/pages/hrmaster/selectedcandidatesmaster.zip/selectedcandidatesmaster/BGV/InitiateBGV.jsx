import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  Grid,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  RadioGroup,
  Radio,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Progress
  LinearProgress,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
} from '@mui/material';

// Icons - FIXED: Removed Alert from here
import { 
  Close as CloseIcon,
  PlayArrow as PlayArrowIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Visibility as VisibilityIcon,
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  LocationOn as LocationIcon,
  Description as DescriptionIcon,
  Assignment as AssignmentIcon,
  Security as SecurityIcon,
  Verified as VerifiedIcon,
  GppGood as GppGoodIcon,
  GppMaybe as GppMaybeIcon,
  GppBad as GppBadIcon,
  Shield as ShieldIcon,
  VerifiedUser as VerifiedUserIcon,
  Policy as PolicyIcon,
  PrivacyTip as PrivacyTipIcon,
  FactCheck as FactCheckIcon,
  Ballot as BallotIcon,
  Checklist as ChecklistIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  TrendingFlat as TrendingFlatIcon,
  Add as AddIcon,
  NavigateNext as NavigateNextIcon,
  NavigateBefore as NavigateBeforeIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    pending: { bg: '#FFF3E0', color: '#E65100' },
    initiated: { bg: '#E3F2FD', color: '#1976D2' },
    in_progress: { bg: '#E3F2FD', color: '#1976D2' },
    completed: { bg: '#E8F5E9', color: '#2E7D32' },
    cleared: { bg: '#E8F5E9', color: '#2E7D32' },
    rejected: { bg: '#FFEBEE', color: '#C62828' },
    failed: { bg: '#FFEBEE', color: '#C62828' },
    on_hold: { bg: '#F3E5F5', color: '#7B1FA2' }
  };
  const color = colors[status] || colors.pending;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const InfoCard = styled(Card)(({ theme }) => ({
  backgroundColor: '#F8FAFC',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const CheckItemCard = styled(Card)(({ theme, checked }) => ({
  border: `1px solid ${checked ? '#4CAF50' : '#E0E0E0'}`,
  borderRadius: 1,
  cursor: 'pointer',
  transition: 'all 0.2s',
  backgroundColor: checked ? '#F1F8E9' : '#FFFFFF',
  '&:hover': {
    borderColor: '#1976D2',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
  }
}));

const InitiateBGV = ({ open, onClose, onInitiate, candidateId: propCandidateId, offerId: propOfferId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    candidateId: propCandidateId || '',
    offerId: propOfferId || '',
    
    // BGV Configuration
    bgvType: 'comprehensive', // 'basic', 'comprehensive', 'custom'
    priority: 'medium', // 'low', 'medium', 'high'
    vendor: '',
    
    // Checks to include
    checks: {
      addressVerification: true,
      employmentVerification: true,
      educationVerification: true,
      criminalCheck: true,
      referenceCheck: true,
      drugTest: false,
      creditCheck: false,
      globalDatabase: false
    },
    
    // Additional options
    notifyCandidate: true,
    sendConsentForm: true,
    expedite: false,
    comments: ''
  });

  // Dropdown states
  const [candidates, setCandidates] = useState([]);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState('');
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [candidatePage, setCandidatePage] = useState(1);
  const [candidateTotalPages, setCandidateTotalPages] = useState(1);
  const [candidateInputValue, setCandidateInputValue] = useState('');

  const [offers, setOffers] = useState([]);
  const [offerLoading, setOfferLoading] = useState(false);
  const [offerSearch, setOfferSearch] = useState('');
  const [offerOpen, setOfferOpen] = useState(false);
  const [offerPage, setOfferPage] = useState(1);
  const [offerTotalPages, setOfferTotalPages] = useState(1);
  const [offerInputValue, setOfferInputValue] = useState('');

  const [vendors, setVendors] = useState([]);
  const [vendorLoading, setVendorLoading] = useState(false);
  const [vendorSearch, setVendorSearch] = useState('');
  const [vendorOpen, setVendorOpen] = useState(false);
  const [vendorPage, setVendorPage] = useState(1);
  const [vendorTotalPages, setVendorTotalPages] = useState(1);
  const [vendorInputValue, setVendorInputValue] = useState('');

  // Candidate details
  const [candidateDetails, setCandidateDetails] = useState(null);
  const [candidateDetailsLoading, setCandidateDetailsLoading] = useState(false);
  
  // Offer details
  const [offerDetails, setOfferDetails] = useState(null);
  const [offerDetailsLoading, setOfferDetailsLoading] = useState(false);

  // Existing BGV check
  const [existingBGV, setExistingBGV] = useState(null);
  const [bgvCheckLoading, setBGVCheckLoading] = useState(false);

  // Initiating state
  const [initiating, setInitiating] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});
  const [validationErrors, setValidationErrors] = useState([]);
  const [success, setSuccess] = useState(false);
  const [initiateResult, setInitiateResult] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // Steps definition
  const steps = ['Select Candidate', 'Configure BGV', 'Review & Initiate'];

  // BGV Types
  const bgvTypes = [
    { 
      id: 'basic', 
      label: 'Basic Check', 
      description: 'Address verification, employment verification (current/last employer)',
      icon: <FactCheckIcon />,
      checks: {
        addressVerification: true,
        employmentVerification: true,
        educationVerification: false,
        criminalCheck: false,
        referenceCheck: false,
        drugTest: false,
        creditCheck: false,
        globalDatabase: false
      }
    },
    { 
      id: 'comprehensive', 
      label: 'Comprehensive Check', 
      description: 'All standard checks including education, criminal, and references',
      icon: <ShieldIcon />,
      checks: {
        addressVerification: true,
        employmentVerification: true,
        educationVerification: true,
        criminalCheck: true,
        referenceCheck: true,
        drugTest: false,
        creditCheck: false,
        globalDatabase: true
      }
    },
    { 
      id: 'custom', 
      label: 'Custom Check', 
      description: 'Select specific checks as per requirement',
      icon: <ChecklistIcon />,
      checks: {
        addressVerification: true,
        employmentVerification: true,
        educationVerification: false,
        criminalCheck: false,
        referenceCheck: false,
        drugTest: false,
        creditCheck: false,
        globalDatabase: false
      }
    }
  ];

  // Priority levels
  const priorityLevels = [
    { id: 'low', label: 'Low', color: '#4CAF50', icon: <TrendingFlatIcon /> },
    { id: 'medium', label: 'Medium', color: '#FF9800', icon: <TrendingUpIcon /> },
    { id: 'high', label: 'High', color: '#F44336', icon: <TrendingDownIcon /> }
  ];

  // BGV Vendors
  const bgvVendors = [
    { id: 'vendor1', name: 'First Advantage', rating: 4.5, turnaround: '5-7 days' },
    { id: 'vendor2', name: 'AuthBridge', rating: 4.3, turnaround: '4-6 days' },
    { id: 'vendor3', name: 'Hauzing', rating: 4.0, turnaround: '3-5 days' },
    { id: 'vendor4', name: 'Shield Verify', rating: 4.2, turnaround: '5-7 days' }
  ];

  // Fetch candidates
  const fetchCandidates = async (search = '', page = 1) => {
    setCandidateLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/for-bgv`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search,
          status: 'accepted,onboarding' // Candidates who accepted offers or are in onboarding
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setCandidates(response.data.data || []);
        } else {
          setCandidates(prev => [...prev, ...(response.data.data || [])]);
        }
        setCandidateTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
    } finally {
      setCandidateLoading(false);
    }
  };

  // Fetch offers for selected candidate
  const fetchOffers = async (candidateId, search = '', page = 1) => {
    if (!candidateId) return;
    
    setOfferLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/candidate/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setOffers(response.data.data || []);
        } else {
          setOffers(prev => [...prev, ...(response.data.data || [])]);
        }
        setOfferTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching offers:', err);
    } finally {
      setOfferLoading(false);
    }
  };

  // Fetch BGV vendors
  const fetchVendors = async (search = '', page = 1) => {
    setVendorLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/bgv/vendors`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setVendors(response.data.data || bgvVendors);
        } else {
          setVendors(prev => [...prev, ...(response.data.data || [])]);
        }
        setVendorTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching vendors:', err);
      // Use mock data if API fails
      setVendors(bgvVendors);
    } finally {
      setVendorLoading(false);
    }
  };

  // Fetch candidate details
  const fetchCandidateDetails = async (candidateId) => {
    if (!candidateId) return;
    
    setCandidateDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setCandidateDetails(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching candidate details:', err);
    } finally {
      setCandidateDetailsLoading(false);
    }
  };

  // Fetch offer details
  const fetchOfferDetails = async (offerId) => {
    if (!offerId) return;
    
    setOfferDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/${offerId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setOfferDetails(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching offer details:', err);
    } finally {
      setOfferDetailsLoading(false);
    }
  };

  // Check existing BGV
  const checkExistingBGV = async (candidateId) => {
    if (!candidateId) return;
    
    setBGVCheckLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/bgv/candidate/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success && response.data.data) {
        setExistingBGV(response.data.data);
      }
    } catch (err) {
      console.error('Error checking existing BGV:', err);
      // 404 means no existing BGV, that's fine
    } finally {
      setBGVCheckLoading(false);
    }
  };

  // Load candidates when dropdown opens
  useEffect(() => {
    if (candidateOpen) {
      fetchCandidates(candidateSearch, 1);
    }
  }, [candidateOpen]);

  // Search candidates with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (candidateOpen) {
        setCandidatePage(1);
        fetchCandidates(candidateSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [candidateSearch, candidateOpen]);

  // Load vendors when dropdown opens
  useEffect(() => {
    if (vendorOpen) {
      fetchVendors(vendorSearch, 1);
    }
  }, [vendorOpen]);

  // Search vendors with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (vendorOpen) {
        setVendorPage(1);
        fetchVendors(vendorSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [vendorSearch, vendorOpen]);

  // Load offers when candidate is selected and dropdown opens
  useEffect(() => {
    if (offerOpen && formData.candidateId) {
      fetchOffers(formData.candidateId, offerSearch, 1);
    }
  }, [offerOpen, formData.candidateId]);

  // Search offers with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (offerOpen && formData.candidateId) {
        setOfferPage(1);
        fetchOffers(formData.candidateId, offerSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [offerSearch, offerOpen, formData.candidateId]);

  // Load candidate details and check existing BGV when selected
  useEffect(() => {
    if (formData.candidateId) {
      fetchCandidateDetails(formData.candidateId);
      checkExistingBGV(formData.candidateId);
    } else {
      setCandidateDetails(null);
      setExistingBGV(null);
    }
  }, [formData.candidateId]);

  // Load offer details when selected
  useEffect(() => {
    if (formData.offerId) {
      fetchOfferDetails(formData.offerId);
    } else {
      setOfferDetails(null);
    }
  }, [formData.offerId]);

  // Handle candidate scroll load more
  const handleCandidateScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (candidatePage < candidateTotalPages && !candidateLoading) {
        const nextPage = candidatePage + 1;
        setCandidatePage(nextPage);
        fetchCandidates(candidateSearch, nextPage);
      }
    }
  };

  // Handle offer scroll load more
  const handleOfferScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (offerPage < offerTotalPages && !offerLoading) {
        const nextPage = offerPage + 1;
        setOfferPage(nextPage);
        fetchOffers(formData.candidateId, offerSearch, nextPage);
      }
    }
  };

  // Handle vendor scroll load more
  const handleVendorScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (vendorPage < vendorTotalPages && !vendorLoading) {
        const nextPage = vendorPage + 1;
        setVendorPage(nextPage);
        fetchVendors(vendorSearch, nextPage);
      }
    }
  };

  const handleChange = (e) => {
    const { name, value, checked, type } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else if (name.startsWith('checks.')) {
      const checkName = name.replace('checks.', '');
      setFormData(prev => ({
        ...prev,
        checks: {
          ...prev.checks,
          [checkName]: checked
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }

    if (fieldErrors[name]) {
      setFieldErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleBGVTypeChange = (typeId) => {
    const selectedType = bgvTypes.find(t => t.id === typeId);
    if (selectedType) {
      setFormData(prev => ({
        ...prev,
        bgvType: typeId,
        checks: selectedType.checks
      }));
    }
  };

  const handleCheckToggle = (checkName) => {
    setFormData(prev => ({
      ...prev,
      checks: {
        ...prev.checks,
        [checkName]: !prev.checks[checkName]
      }
    }));
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.candidateId) {
        errors.candidateId = 'Please select a candidate';
      }
      if (!formData.offerId) {
        errors.offerId = 'Please select an offer';
      }
    } else if (step === 1) {
      if (!formData.bgvType) {
        errors.bgvType = 'Please select BGV type';
      }
      
      // Check if at least one verification type is selected
      const hasChecks = Object.values(formData.checks).some(value => value === true);
      if (!hasChecks) {
        errors.checks = 'Please select at least one verification check';
      }
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors([]);
    // Small delay before retrying
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  const handleSubmit = async () => {
    if (!validateStep(1)) {
      setError('Please complete all required fields');
      return;
    }

    setInitiating(true);
    setError('');
    setValidationErrors([]);

    try {
      const token = localStorage.getItem('token');

      // Prepare data according to API expectations
      const submitData = {
        candidateId: formData.candidateId,
        offerId: formData.offerId
      };

      // Add metadata for tracking (optional, not part of API spec)
      const metadata = {
        bgvType: formData.bgvType,
        priority: formData.priority,
        vendor: formData.vendor,
        checks: formData.checks,
        notifyCandidate: formData.notifyCandidate,
        sendConsentForm: formData.sendConsentForm,
        expedite: formData.expedite,
        comments: formData.comments
      };

      console.log('Initiating BGV with data:', submitData, 'Metadata:', metadata);

      const response = await axios.post(`${BASE_URL}/api/bgv/initiate`, submitData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'X-BGV-Metadata': JSON.stringify(metadata)
        }
      });

      if (response.data.success) {
        setInitiateResult(response.data.data);
        setSuccess(true);
        
        if (onInitiate) {
          onInitiate(response.data.data);
        }
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to initiate BGV');
      }
    } catch (err) {
      console.error('Error initiating BGV:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to initiate BGV';
        
        // Handle specific error cases
        if (err.response.status === 400) {
          if (err.response.data.errors) {
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setFieldErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 404) {
          setError('Candidate or offer not found');
        } else if (err.response.status === 409) {
          setError(
            <Box>
              <Typography variant="body2" sx={{ mb: 1 }}>
                BGV already initiated for this candidate.
              </Typography>
              <Button
                size="small"
                variant="outlined"
                startIcon={<VisibilityIcon />}
                onClick={() => {
                  // Navigate to view BGV status
                  handleClose();
                }}
                sx={{ mt: 1 }}
              >
                View Status
              </Button>
            </Box>
          );
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setInitiating(false);
    }
  };

  const resetForm = () => {
    setFormData({
      candidateId: propCandidateId || '',
      offerId: propOfferId || '',
      bgvType: 'comprehensive',
      priority: 'medium',
      vendor: '',
      checks: {
        addressVerification: true,
        employmentVerification: true,
        educationVerification: true,
        criminalCheck: true,
        referenceCheck: true,
        drugTest: false,
        creditCheck: false,
        globalDatabase: false
      },
      notifyCandidate: true,
      sendConsentForm: true,
      expedite: false,
      comments: ''
    });
    setCandidateDetails(null);
    setOfferDetails(null);
    setExistingBGV(null);
    setError('');
    setFieldErrors({});
    setValidationErrors([]);
    setInitiateResult(null);
    setSuccess(false);
    setActiveStep(0);
    setCandidateSearch('');
    setOfferSearch('');
    setVendorSearch('');
    setCandidateInputValue('');
    setOfferInputValue('');
    setVendorInputValue('');
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  // Get priority color
  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'high': return '#F44336';
      case 'medium': return '#FF9800';
      case 'low': return '#4CAF50';
      default: return '#9E9E9E';
    }
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select Candidate */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Candidate for BGV
              </Typography>

              <Grid container spacing={1.5}>
                <Grid item xs={12}>
                  <Autocomplete
                    size="small"
                    id="candidate-autocomplete"
                    open={candidateOpen}
                    onOpen={() => setCandidateOpen(true)}
                    onClose={() => setCandidateOpen(false)}
                    options={candidates}
                    loading={candidateLoading}
                    value={formData.candidateId ? candidates.find(c => c._id === formData.candidateId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        candidateId: newValue?._id || null,
                        offerId: '' // Reset offer when candidate changes
                      }));
                      setOffers([]); // Clear offers
                      if (fieldErrors.candidateId) {
                        setFieldErrors(prev => ({ ...prev, candidateId: '' }));
                      }
                    }}
                    inputValue={candidateInputValue}
                    onInputChange={(event, newInputValue) => {
                      setCandidateInputValue(newInputValue);
                      setCandidateSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.name || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Candidate"
                        required
                        error={!!fieldErrors.candidateId}
                        helperText={fieldErrors.candidateId}
                        size="small"
                        placeholder="Search by name or email"
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {candidateLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.name}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.email} • {option.phone}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleCandidateScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>

                {/* Select Offer */}
                <Grid item xs={12}>
                  <Autocomplete
                    size="small"
                    id="offer-autocomplete"
                    open={offerOpen}
                    onOpen={() => setOfferOpen(true)}
                    onClose={() => setOfferOpen(false)}
                    options={offers}
                    loading={offerLoading}
                    value={formData.offerId ? offers.find(o => o._id === formData.offerId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ ...prev, offerId: newValue?._id || null }));
                      if (fieldErrors.offerId) {
                        setFieldErrors(prev => ({ ...prev, offerId: '' }));
                      }
                    }}
                    inputValue={offerInputValue}
                    onInputChange={(event, newInputValue) => {
                      setOfferInputValue(newInputValue);
                      setOfferSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.offerId || ''}
                    disabled={!formData.candidateId}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Offer"
                        required
                        error={!!fieldErrors.offerId}
                        helperText={fieldErrors.offerId || (!formData.candidateId ? 'Select a candidate first' : '')}
                        size="small"
                        placeholder={formData.candidateId ? "Search offers" : "Select candidate first"}
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {offerLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.offerId}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.positionTitle} • {formatDate(option.createdAt)}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleOfferScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Candidate Quick Info */}
            {candidateDetailsLoading && (
              <Box sx={{ py: 2, textAlign: 'center' }}>
                <CircularProgress size={24} />
              </Box>
            )}

            {candidateDetails && !candidateDetailsLoading && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Candidate Information
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{candidateDetails.name}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                    <Typography variant="body2">{candidateDetails.email}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Phone</Typography>
                    <Typography variant="body2">{candidateDetails.phone}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Current Status</Typography>
                    <StatusChip 
                      label={candidateDetails.status || 'Active'} 
                      size="small"
                      status={candidateDetails.status || 'active'}
                    />
                  </Grid>
                </Grid>
              </Paper>
            )}

            {/* Existing BGV Warning */}
            {existingBGV && (
              <Alert severity="warning" sx={{ borderRadius: 1 }}>
                <Typography variant="body2">
                  <strong>BGV already exists:</strong> This candidate already has a BGV with status "{existingBGV.status}".
                  Initiating a new BGV may create a duplicate record.
                </Typography>
              </Alert>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* BGV Type Selection */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                BGV Type *
              </Typography>

              <Grid container spacing={1.5}>
                {bgvTypes.map((type) => (
                  <Grid item xs={12} md={4} key={type.id}>
                    <CheckItemCard
                      checked={formData.bgvType === type.id}
                      onClick={() => handleBGVTypeChange(type.id)}
                    >
                      <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Box sx={{ color: formData.bgvType === type.id ? '#1976D2' : '#666', mr: 1 }}>
                            {type.icon}
                          </Box>
                          <Typography variant="subtitle2">{type.label}</Typography>
                          {formData.bgvType === type.id && (
                            <CheckCircleIcon sx={{ ml: 'auto', fontSize: 16, color: '#1976D2' }} />
                          )}
                        </Box>
                        <Typography variant="caption" color="textSecondary">
                          {type.description}
                        </Typography>
                      </CardContent>
                    </CheckItemCard>
                  </Grid>
                ))}
              </Grid>

              {fieldErrors.bgvType && (
                <FormHelperText error sx={{ mt: 1 }}>
                  {fieldErrors.bgvType}
                </FormHelperText>
              )}
            </Paper>

            {/* Priority and Vendor */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Configuration
              </Typography>

              <Grid container spacing={1.5}>
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Priority</InputLabel>
                    <Select
                      name="priority"
                      value={formData.priority}
                      onChange={handleChange}
                      label="Priority"
                    >
                      {priorityLevels.map(priority => (
                        <MenuItem key={priority.id} value={priority.id}>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Box sx={{ color: priority.color, mr: 1 }}>{priority.icon}</Box>
                            {priority.label}
                          </Box>
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={6}>
                  <Autocomplete
                    size="small"
                    id="vendor-autocomplete"
                    open={vendorOpen}
                    onOpen={() => setVendorOpen(true)}
                    onClose={() => setVendorOpen(false)}
                    options={vendors}
                    loading={vendorLoading}
                    value={formData.vendor ? vendors.find(v => v.id === formData.vendor) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ ...prev, vendor: newValue?.id || '' }));
                    }}
                    inputValue={vendorInputValue}
                    onInputChange={(event, newInputValue) => {
                      setVendorInputValue(newInputValue);
                      setVendorSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.name || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Vendor"
                        size="small"
                        placeholder="Choose BGV vendor"
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {vendorLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option.id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.name}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            Rating: {option.rating} • TAT: {option.turnaround}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleVendorScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Verification Checks */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Verification Checks
              </Typography>

              <Grid container spacing={1.5}>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.addressVerification}
                        onChange={() => handleCheckToggle('addressVerification')}
                        size="small"
                      />
                    }
                    label="Address Verification"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.employmentVerification}
                        onChange={() => handleCheckToggle('employmentVerification')}
                        size="small"
                      />
                    }
                    label="Employment Verification"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.educationVerification}
                        onChange={() => handleCheckToggle('educationVerification')}
                        size="small"
                      />
                    }
                    label="Education Verification"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.criminalCheck}
                        onChange={() => handleCheckToggle('criminalCheck')}
                        size="small"
                      />
                    }
                    label="Criminal Record Check"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.referenceCheck}
                        onChange={() => handleCheckToggle('referenceCheck')}
                        size="small"
                      />
                    }
                    label="Reference Check"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.drugTest}
                        onChange={() => handleCheckToggle('drugTest')}
                        size="small"
                      />
                    }
                    label="Drug Test"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.creditCheck}
                        onChange={() => handleCheckToggle('creditCheck')}
                        size="small"
                      />
                    }
                    label="Credit Check"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formData.checks.globalDatabase}
                        onChange={() => handleCheckToggle('globalDatabase')}
                        size="small"
                      />
                    }
                    label="Global Database Check"
                  />
                </Grid>
              </Grid>

              {fieldErrors.checks && (
                <FormHelperText error sx={{ mt: 1 }}>
                  {fieldErrors.checks}
                </FormHelperText>
              )}
            </Paper>

            {/* Additional Options */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Additional Options
              </Typography>

              <Grid container spacing={1.5}>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="notifyCandidate"
                        checked={formData.notifyCandidate}
                        onChange={handleChange}
                        size="small"
                      />
                    }
                    label="Notify candidate about BGV initiation"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="sendConsentForm"
                        checked={formData.sendConsentForm}
                        onChange={handleChange}
                        size="small"
                      />
                    }
                    label="Send consent form to candidate"
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="expedite"
                        checked={formData.expedite}
                        onChange={handleChange}
                        size="small"
                      />
                    }
                    label="Expedite processing (additional cost)"
                  />
                </Grid>
              </Grid>

              <Box sx={{ mt: 2 }}>
                <TextField
                  fullWidth
                  size="small"
                  label="Comments / Special Instructions"
                  name="comments"
                  value={formData.comments}
                  onChange={handleChange}
                  multiline
                  rows={2}
                  placeholder="Any specific instructions for the verification team..."
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                />
              </Box>
            </Paper>
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Review Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Review BGV Initiation
              </Typography>

              <Grid container spacing={2}>
                {/* Candidate Information */}
                <Grid item xs={12}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Candidate
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {candidateDetails?.name}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {candidateDetails?.email} • {candidateDetails?.phone}
                    </Typography>
                  </Paper>
                </Grid>

                {/* Offer Information */}
                {offerDetails && (
                  <Grid item xs={12}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Offer Details
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">
                        {offerDetails.offerId} - {offerDetails.positionTitle}
                      </Typography>
                      <Typography variant="caption" color="textSecondary">
                        Joining Date: {formatDate(offerDetails.joiningDate)}
                      </Typography>
                    </Paper>
                  </Grid>
                )}

                {/* BGV Configuration */}
                <Grid item xs={12}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    BGV Configuration
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid item xs={4}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Type</Typography>
                        <Typography variant="body2">
                          {bgvTypes.find(t => t.id === formData.bgvType)?.label || formData.bgvType}
                        </Typography>
                      </Grid>
                      <Grid item xs={4}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Priority</Typography>
                        <Chip
                          label={formData.priority}
                          size="small"
                          sx={{ 
                            backgroundColor: getPriorityColor(formData.priority),
                            color: 'white',
                            height: 20
                          }}
                        />
                      </Grid>
                      <Grid item xs={4}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Vendor</Typography>
                        <Typography variant="body2">
                          {vendors.find(v => v.id === formData.vendor)?.name || 'Not selected'}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>

                {/* Selected Checks */}
                <Grid item xs={12}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Verification Checks
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {Object.entries(formData.checks).map(([key, value]) => {
                        if (value) {
                          return (
                            <Chip
                              key={key}
                              label={key.replace(/([A-Z])/g, ' $1').trim()}
                              size="small"
                              sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                            />
                          );
                        }
                        return null;
                      })}
                    </Box>
                  </Paper>
                </Grid>

                {/* Additional Options */}
                {(formData.notifyCandidate || formData.sendConsentForm || formData.expedite) && (
                  <Grid item xs={12}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Additional Options
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {formData.notifyCandidate && (
                          <Chip
                            icon={<EmailIcon />}
                            label="Notify Candidate"
                            size="small"
                            sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                          />
                        )}
                        {formData.sendConsentForm && (
                          <Chip
                            icon={<PrivacyTipIcon />}
                            label="Send Consent"
                            size="small"
                            sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                          />
                        )}
                        {formData.expedite && (
                          <Chip
                            icon={<TrendingUpIcon />}
                            label="Expedited"
                            size="small"
                            sx={{ backgroundColor: '#FFF3E0', color: '#E65100' }}
                          />
                        )}
                      </Box>
                    </Paper>
                  </Grid>
                )}

                {/* Comments */}
                {formData.comments && (
                  <Grid item xs={12}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Comments
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.comments}</Typography>
                    </Paper>
                  </Grid>
                )}
              </Grid>
            </Paper>

            {/* Privacy Notice */}
            <Alert severity="info" sx={{ borderRadius: 1 }} icon={<PolicyIcon />}>
              <Typography variant="body2">
                <strong>Privacy Notice:</strong> Background verification will be conducted in compliance 
                with data protection regulations. Candidate consent will be obtained before proceeding.
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {validationErrors.length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {validationErrors.map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err.message}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !validationErrors.length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Initiate Background Verification
        </Typography>
        {!initiating && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            <Stepper
              activeStep={activeStep}
              alternativeLabel
              connector={<ColorConnector />}
              sx={{ mb: 2, mt: 1 }}
            >
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>
                    <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || initiating}
              size="small"
              startIcon={<NavigateBeforeIcon />}
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={initiating}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={initiating || !formData.candidateId || !formData.offerId}
                  size="small"
                  startIcon={initiating ? <CircularProgress size={16} color="inherit" /> : <PlayArrowIcon />}
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  {initiating ? 'Initiating...' : 'Initiate BGV'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={initiating}
                  size="small"
                  endIcon={<NavigateNextIcon />}
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <ShieldIcon sx={{ fontSize: 64, color: '#4CAF50', mb: 2 }} />
            <Typography variant="h5" sx={{ mb: 2, color: '#101010', fontWeight: 600 }}>
              BGV Initiated Successfully!
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              {initiateResult?.message || 'Background verification has been initiated.'}
            </Typography>
            
            {initiateResult && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', mb: 3, maxWidth: 400, mx: 'auto' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1 }}>
                  BGV Details
                </Typography>
                <Typography variant="body2">
                  <strong>BGV ID:</strong> {initiateResult.bgvId}
                </Typography>
                <Typography variant="body2">
                  <strong>Status:</strong>{' '}
                  <StatusChip 
                    label={initiateResult.status} 
                    size="small"
                    status={initiateResult.status}
                  />
                </Typography>
              </Paper>
            )}

            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  resetForm();
                  setSuccess(false);
                }}
                startIcon={<PlayArrowIcon />}
              >
                Initiate Another
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default InitiateBGV;