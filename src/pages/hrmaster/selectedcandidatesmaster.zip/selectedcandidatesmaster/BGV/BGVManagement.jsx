// import React, { useState } from 'react';
// import {
//   Box,
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   IconButton,
//   Button,
//   TextField,
//   InputAdornment,
//   Tooltip,
//   Typography,
//   TablePagination,
//   Checkbox,
//   Stack,
//   alpha,
//   Avatar,
//   Chip,
//   LinearProgress,
//   CircularProgress,
//   Grid,
//   Menu,
//   MenuItem,
//   ListItemIcon,
//   ListItemText,
//   Divider
// } from '@mui/material';
// import {
//   Search as SearchIcon,
//   Refresh as RefreshIcon,
//   Download as DownloadIcon,
//   GppGood as GppGoodIcon,
//   Timeline as TimelineIcon,
//   PictureAsPdf as PictureAsPdfIcon,
//   MoreVert as MoreVertIcon,
//   CheckCircle as CheckCircleIcon,
//   Warning as WarningIcon,
//   HourglassEmpty as HourglassIcon
// } from '@mui/icons-material';

// import { PRIMARY_BLUE, TEXT_COLOR_MAIN, SUCCESS_COLOR, WARNING_COLOR, PURPLE_COLOR } from '../components/utils/constants';
// import { formatDate, getAvatarInitials, getAvatarColor } from '../components/utils/helpers';
// import StatusChip from '../components/shared/StatusChip';
// import StatsCard from '../components/shared/StatsCard';

// // Import BGV modals
// import InitiateBGV from './InitiateBGV';
// import ViewReportBGV from './ViewReportBGV';
// import ViewStatusBGV from './ViewStatusBGV';

// const BGVManagement = ({ 
//   candidates, 
//   loading, 
//   onRefresh,
//   onAction,
//   selected,
//   onSelect,
//   onSelectAll,
//   searchTerm,
//   onSearchChange,
//   page,
//   rowsPerPage,
//   onPageChange,
//   onRowsPerPageChange,
//   stats
// }) => {
//   const [actionMenuAnchor, setActionMenuAnchor] = useState(null);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);

//   const handleActionClick = (event, candidate) => {
//     setActionMenuAnchor(event.currentTarget);
//     setSelectedCandidate(candidate);
//   };

//   const handleActionClose = () => {
//     setActionMenuAnchor(null);
//     setSelectedCandidate(null);
//   };

//   const handleAction = (action) => {
//     if (selectedCandidate) {
//       onAction(selectedCandidate, action);
//     }
//     handleActionClose();
//   };

//   const getBGVProgressValue = (status) => {
//     const progressMap = {
//       'not_started': 0,
//       'initiated': 25,
//       'in_progress': 50,
//       'verified': 75,
//       'completed': 100,
//       'failed': 100
//     };
//     return progressMap[status] || 0;
//   };

//   const paginatedCandidates = candidates.slice(
//     page * rowsPerPage,
//     page * rowsPerPage + rowsPerPage
//   );

//   return (
//     <Box>
//       {/* BGV Stats */}
//       <Grid container spacing={2} sx={{ mb: 3 }}>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Total BGV"
//             value={stats.totalBGV || 0}
//             icon={GppGoodIcon}
//             color={PRIMARY_BLUE}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="In Progress"
//             value={stats.bgvInProgress || 0}
//             icon={HourglassIcon}
//             color={WARNING_COLOR}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Completed"
//             value={stats.bgvCompleted || 0}
//             icon={CheckCircleIcon}
//             color={SUCCESS_COLOR}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Failed/Issues"
//             value={stats.bgvFailed || 0}
//             icon={WarningIcon}
//             color={PURPLE_COLOR}
//           />
//         </Grid>
//       </Grid>

//       {/* Action Bar - similar to previous components */}
//       <Paper sx={{ p: 2, mb: 3, borderRadius: 2, border: '1px solid #e2e8f0' }}>
//         <Stack direction="row" spacing={2} alignItems="center" justifyContent="space-between">
//           <TextField
//             placeholder="Search BGV..."
//             size="small"
//             value={searchTerm}
//             onChange={onSearchChange}
//             sx={{ width: 300 }}
//             InputProps={{
//               startAdornment: (
//                 <InputAdornment position="start">
//                   <SearchIcon sx={{ color: '#64748B' }} />
//                 </InputAdornment>
//               ),
//               sx: { height: 40, bgcolor: '#f8fafc' }
//             }}
//           />
//           <Stack direction="row" spacing={1}>
//             <Button variant="outlined" startIcon={<DownloadIcon />} sx={{ height: 40, textTransform: 'none' }}>
//               Export
//             </Button>
//             <IconButton onClick={onRefresh} sx={{ height: 40, width: 40, border: '1px solid #cbd5e1' }}>
//               <RefreshIcon fontSize="small" />
//             </IconButton>
//           </Stack>
//         </Stack>
//       </Paper>

//       {/* BGV Table */}
//       <Paper sx={{ borderRadius: 2, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
//         {loading && <LinearProgress sx={{ bgcolor: PRIMARY_BLUE }} />}
        
//         <TableContainer>
//           <Table stickyHeader>
//             <TableHead>
//               <TableRow sx={{ bgcolor: '#f8fafc' }}>
//                 <TableCell padding="checkbox">
//                   <Checkbox onChange={onSelectAll} sx={{ color: PRIMARY_BLUE }} />
//                 </TableCell>
//                 <TableCell>Candidate</TableCell>
//                 <TableCell>BGV ID</TableCell>
//                 <TableCell>Initiated Date</TableCell>
//                 <TableCell>Status</TableCell>
//                 <TableCell>Progress</TableCell>
//                 <TableCell>Completed Date</TableCell>
//                 <TableCell>Actions</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {loading ? (
//                 <TableRow><TableCell colSpan={8} align="center" sx={{ py: 8 }}><CircularProgress /></TableCell></TableRow>
//               ) : paginatedCandidates.length === 0 ? (
//                 <TableRow><TableCell colSpan={8} align="center" sx={{ py: 8 }}>No BGV records found</TableCell></TableRow>
//               ) : (
//                 paginatedCandidates.map((candidate) => {
//                   const progress = getBGVProgressValue(candidate.bgv?.status);
                  
//                   return (
//                     <TableRow key={candidate._id} hover>
//                       <TableCell padding="checkbox">
//                         <Checkbox checked={selected.includes(candidate._id)} onChange={() => onSelect(candidate._id)} />
//                       </TableCell>
//                       <TableCell>
//                         <Stack direction="row" spacing={2} alignItems="center">
//                           <Avatar sx={{ bgcolor: getAvatarColor(candidate.name) }}>
//                             {getAvatarInitials(candidate.name)}
//                           </Avatar>
//                           <Box>
//                             <Typography variant="body2" fontWeight={600}>{candidate.name}</Typography>
//                             <Typography variant="caption" color="#64748B">{candidate.email}</Typography>
//                           </Box>
//                         </Stack>
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2">{candidate.bgv?.bgvId || '-'}</Typography>
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2">{formatDate(candidate.bgv?.initiatedDate)}</Typography>
//                       </TableCell>
//                       <TableCell>
//                         <StatusChip status={candidate.bgv?.status || 'not_started'} />
//                       </TableCell>
//                       <TableCell>
//                         <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
//                           <Box sx={{ width: 80 }}>
//                             <LinearProgress 
//                               variant="determinate" 
//                               value={progress} 
//                               sx={{ 
//                                 height: 6, 
//                                 borderRadius: 3,
//                                 bgcolor: alpha(PRIMARY_BLUE, 0.1),
//                                 '& .MuiLinearProgress-bar': {
//                                   bgcolor: progress === 100 ? SUCCESS_COLOR : 
//                                           progress > 50 ? PRIMARY_BLUE : WARNING_COLOR
//                                 }
//                               }}
//                             />
//                           </Box>
//                           <Typography variant="caption">{progress}%</Typography>
//                         </Box>
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2">{formatDate(candidate.bgv?.completedDate)}</Typography>
//                       </TableCell>
//                       <TableCell>
//                         <IconButton onClick={(e) => handleActionClick(e, candidate)}>
//                           <MoreVertIcon fontSize="small" />
//                         </IconButton>
//                       </TableCell>
//                     </TableRow>
//                   );
//                 })
//               )}
//             </TableBody>
//           </Table>
//         </TableContainer>

//         <TablePagination
//           rowsPerPageOptions={[5, 10, 25]}
//           component="div"
//           count={candidates.length}
//           rowsPerPage={rowsPerPage}
//           page={page}
//           onPageChange={onPageChange}
//           onRowsPerPageChange={onRowsPerPageChange}
//         />
//       </Paper>

//       {/* Action Menu */}
//       <Menu anchorEl={actionMenuAnchor} open={Boolean(actionMenuAnchor)} onClose={handleActionClose}>
//         <MenuItem onClick={() => handleAction('initiate_bgv')}>
//           <ListItemIcon><GppGoodIcon fontSize="small" /></ListItemIcon>
//           <ListItemText>Initiate BGV</ListItemText>
//         </MenuItem>
//         <MenuItem onClick={() => handleAction('view_bgv_status')}>
//           <ListItemIcon><TimelineIcon fontSize="small" /></ListItemIcon>
//           <ListItemText>View Status</ListItemText>
//         </MenuItem>
//         <MenuItem onClick={() => handleAction('view_bgv_report')}>
//           <ListItemIcon><PictureAsPdfIcon fontSize="small" /></ListItemIcon>
//           <ListItemText>View Report</ListItemText>
//         </MenuItem>
//       </Menu>
//     </Box>
//   );
// };

// export default BGVManagement;

import React, { useState } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Button,
  TextField,
  InputAdornment,
  Tooltip,
  Typography,
  TablePagination,
  Checkbox,
  Stack,
  alpha,
  Avatar,
  Chip,
  LinearProgress,
  CircularProgress,
  Grid,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Divider
} from '@mui/material';
import {
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Download as DownloadIcon,
  GppGood as GppGoodIcon,
  Timeline as TimelineIcon,
  PictureAsPdf as PictureAsPdfIcon,
  MoreVert as MoreVertIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  HourglassEmpty as HourglassIcon,
  Error as ErrorIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';
import { formatDate, getAvatarInitials, getAvatarColor } from '../components/utils/helpers';
import StatusChip from '../components/shared/StatusChip';
import StatsCard from '../components/shared/StatsCard';

const PRIMARY_BLUE = '#00B4D8';
const TEXT_COLOR_MAIN = '#0f172a';
const SUCCESS_COLOR = '#10B981';
const WARNING_COLOR = '#F59E0B';
const PURPLE_COLOR = '#8B5CF6';
const DANGER_COLOR = '#EF4444';

const BGVManagement = ({ 
  candidates, 
  loading, 
  onRefresh,
  onAction,
  selected,
  onSelect,
  onSelectAll,
  searchTerm,
  onSearchChange,
  page,
  rowsPerPage,
  onPageChange,
  onRowsPerPageChange,
  stats
}) => {
  const [actionMenuAnchor, setActionMenuAnchor] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const handleActionClick = (event, candidate) => {
    setActionMenuAnchor(event.currentTarget);
    setSelectedCandidate(candidate);
  };

  const handleActionClose = () => {
    setActionMenuAnchor(null);
    setSelectedCandidate(null);
  };

  const handleAction = (action) => {
    if (selectedCandidate) {
      onAction(selectedCandidate, action);
    }
    handleActionClose();
  };

  const getBGVProgressValue = (status) => {
    const progressMap = {
      'not_started': 0,
      'initiated': 25,
      'in_progress': 50,
      'verified': 75,
      'completed': 100,
      'failed': 100,
      'on_hold': 30
    };
    return progressMap[status] || 0;
  };

  const getBGVStatusIcon = (status) => {
    switch(status) {
      case 'completed': return <CheckCircleIcon sx={{ fontSize: 16, color: SUCCESS_COLOR }} />;
      case 'in_progress': return <HourglassIcon sx={{ fontSize: 16, color: WARNING_COLOR }} />;
      case 'failed': return <ErrorIcon sx={{ fontSize: 16, color: DANGER_COLOR }} />;
      case 'on_hold': return <WarningIcon sx={{ fontSize: 16, color: PURPLE_COLOR }} />;
      default: return null;
    }
  };

  const paginatedCandidates = candidates.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  return (
    <Box>
      {/* BGV Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Total BGV"
            value={stats.totalBGV || 0}
            icon={GppGoodIcon}
            color={PRIMARY_BLUE}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="In Progress"
            value={stats.bgvInProgress || 0}
            icon={HourglassIcon}
            color={WARNING_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Completed"
            value={stats.bgvCompleted || 0}
            icon={CheckCircleIcon}
            color={SUCCESS_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Failed/Issues"
            value={stats.bgvFailed || 0}
            icon={ErrorIcon}
            color={DANGER_COLOR}
          />
        </Grid>
      </Grid>

      {/* Action Bar */}
      <Paper sx={{ 
        p: 2, 
        mb: 3, 
        borderRadius: 2,
        bgcolor: '#FFFFFF',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
        border: '1px solid #e2e8f0'
      }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems="center" justifyContent="space-between">
          <TextField
            placeholder="Search BGV..."
            size="small"
            value={searchTerm}
            onChange={onSearchChange}
            sx={{ 
              width: { xs: '100%', sm: 300 },
              '& .MuiOutlinedInput-root': {
                borderRadius: 1.5,
                '&:hover fieldset': {
                  borderColor: PRIMARY_BLUE,
                },
              }
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#64748B' }} />
                </InputAdornment>
              ),
              sx: { height: 40, bgcolor: '#f8fafc' }
            }}
          />

          <Stack direction="row" spacing={1}>
            <Button
              variant="outlined"
              startIcon={<DownloadIcon />}
              sx={{ 
                height: 40,
                borderRadius: 1.5,
                borderColor: '#cbd5e1',
                color: '#475569',
                textTransform: 'none'
              }}
            >
              Export
            </Button>
            <IconButton
              onClick={onRefresh}
              disabled={loading}
              sx={{
                height: 40,
                width: 40,
                borderRadius: 1.5,
                border: '1px solid #cbd5e1',
                color: '#475569'
              }}
            >
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Stack>
        </Stack>
      </Paper>

      {/* BGV Table */}
      <Paper sx={{ 
        width: '100%', 
        borderRadius: 2, 
        overflow: 'hidden',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
        border: '1px solid #e2e8f0'
      }}>
        {loading && <LinearProgress sx={{ bgcolor: PRIMARY_BLUE }} />}
        
        <TableContainer>
          <Table stickyHeader>
            <TableHead>
              <TableRow sx={{ 
                bgcolor: '#f8fafc',
                '& .MuiTableCell-root': {
                  fontWeight: 600,
                  fontSize: '0.875rem',
                  color: TEXT_COLOR_MAIN,
                  borderBottom: '2px solid #e2e8f0'
                }
              }}>
                <TableCell padding="checkbox" sx={{ width: 50 }}>
                  <Checkbox
                    indeterminate={selected.length > 0 && selected.length < candidates.length}
                    checked={candidates.length > 0 && selected.length === candidates.length}
                    onChange={onSelectAll}
                    sx={{ color: PRIMARY_BLUE }}
                  />
                </TableCell>
                <TableCell>Candidate</TableCell>
                <TableCell>BGV ID</TableCell>
                <TableCell>Initiated Date</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Progress</TableCell>
                <TableCell>Completed Date</TableCell>
                <TableCell>Remarks</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 8 }}>
                    <CircularProgress size={32} sx={{ color: PRIMARY_BLUE }} />
                  </TableCell>
                </TableRow>
              ) : paginatedCandidates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 8 }}>
                    <Box sx={{ textAlign: 'center' }}>
                      <GppGoodIcon sx={{ fontSize: 48, color: '#D1D5DB', mb: 2 }} />
                      <Typography variant="body1" color="#64748B" fontWeight={500}>
                        No BGV records found
                      </Typography>
                      <Typography variant="body2" color="#94A3B8" sx={{ mt: 1 }}>
                        Initiate BGV checks for candidates
                      </Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              ) : (
                paginatedCandidates.map((candidate) => {
                  const isSelected = selected.includes(candidate._id);
                  const avatarColor = getAvatarColor(candidate.name);
                  const bgvStatus = candidate.bgv?.status || 'not_started';
                  const progress = getBGVProgressValue(bgvStatus);

                  return (
                    <TableRow
                      key={candidate._id}
                      hover
                      selected={isSelected}
                      sx={{ 
                        '&:hover': { bgcolor: alpha(PRIMARY_BLUE, 0.04) },
                        '&.Mui-selected': { bgcolor: alpha(PRIMARY_BLUE, 0.08) }
                      }}
                    >
                      <TableCell padding="checkbox">
                        <Checkbox
                          checked={isSelected}
                          onChange={() => onSelect(candidate._id)}
                          sx={{ color: PRIMARY_BLUE }}
                        />
                      </TableCell>
                      <TableCell>
                        <Stack direction="row" spacing={2} alignItems="center">
                          <Avatar sx={{ width: 40, height: 40, bgcolor: avatarColor }}>
                            {getAvatarInitials(candidate.name)}
                          </Avatar>
                          <Box>
                            <Typography variant="body2" fontWeight={600}>
                              {candidate.name}
                            </Typography>
                            <Typography variant="caption" color="#64748B">
                              {candidate.email}
                            </Typography>
                          </Box>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight={500}>
                          {candidate.bgv?.bgvId || '-'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {candidate.bgv?.initiatedDate ? formatDate(candidate.bgv.initiatedDate) : '-'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                          {getBGVStatusIcon(bgvStatus)}
                          <StatusChip status={bgvStatus} />
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, minWidth: 100 }}>
                          <Box sx={{ width: 60 }}>
                            <LinearProgress 
                              variant="determinate" 
                              value={progress} 
                              sx={{ 
                                height: 6, 
                                borderRadius: 3,
                                bgcolor: alpha(PRIMARY_BLUE, 0.1),
                                '& .MuiLinearProgress-bar': {
                                  bgcolor: progress === 100 ? SUCCESS_COLOR : 
                                          progress >= 50 ? PRIMARY_BLUE : WARNING_COLOR
                                }
                              }}
                            />
                          </Box>
                          <Typography variant="caption" fontWeight={500}>
                            {progress}%
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {candidate.bgv?.completedDate ? formatDate(candidate.bgv.completedDate) : '-'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption" color="#64748B" sx={{ maxWidth: 150, display: 'block' }}>
                          {candidate.bgv?.remarks || '-'}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Tooltip title="BGV Actions">
                          <IconButton
                            size="small"
                            onClick={(e) => handleActionClick(e, candidate)}
                            sx={{ 
                              color: '#64748b',
                              '&:hover': {
                                bgcolor: alpha(PRIMARY_BLUE, 0.1)
                              }
                            }}
                          >
                            <MoreVertIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={candidates.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={onPageChange}
          onRowsPerPageChange={onRowsPerPageChange}
          sx={{ 
            borderTop: '1px solid #e2e8f0',
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
              fontSize: '0.875rem',
              color: '#64748B'
            }
          }}
        />
      </Paper>

      {/* Action Menu */}
      <Menu
        anchorEl={actionMenuAnchor}
        open={Boolean(actionMenuAnchor)}
        onClose={handleActionClose}
        PaperProps={{
          elevation: 3,
          sx: {
            minWidth: 200,
            borderRadius: 2,
            border: '1px solid #e2e8f0'
          }
        }}
      >
        <MenuItem disabled sx={{ opacity: 0.7 }}>
          <Typography variant="caption" color="textSecondary">
            BGV Actions
          </Typography>
        </MenuItem>
        <Divider />

        <MenuItem onClick={() => handleAction('initiate_bgv')}>
          <ListItemIcon>
            <GppGoodIcon fontSize="small" sx={{ color: PRIMARY_BLUE }} />
          </ListItemIcon>
          <ListItemText primary="Initiate BGV" />
        </MenuItem>

        <MenuItem 
          onClick={() => handleAction('view_bgv_status')}
          disabled={!selectedCandidate?.bgv}
        >
          <ListItemIcon>
            <TimelineIcon fontSize="small" sx={{ color: WARNING_COLOR }} />
          </ListItemIcon>
          <ListItemText primary="View Status" />
        </MenuItem>

        <MenuItem 
          onClick={() => handleAction('view_bgv_report')}
          disabled={!selectedCandidate?.bgv}
        >
          <ListItemIcon>
            <PictureAsPdfIcon fontSize="small" sx={{ color: DANGER_COLOR }} />
          </ListItemIcon>
          <ListItemText primary="View Report" />
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default BGVManagement;