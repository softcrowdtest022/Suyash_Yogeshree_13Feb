import React from 'react'

export default function ViewStatusBGV() {
  return (
    <div>
      
    </div>
  )
}
