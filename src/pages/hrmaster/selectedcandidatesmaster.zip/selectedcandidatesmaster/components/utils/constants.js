// Color constants
export const HEADER_GRADIENT = 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)';
export const STRIPE_COLOR_ODD = '#FFFFFF';
export const STRIPE_COLOR_EVEN = '#f8fafc';
export const HOVER_COLOR = '#f1f5f9';
export const PRIMARY_BLUE = '#00B4D8';
export const TEXT_COLOR_HEADER = '#FFFFFF';
export const TEXT_COLOR_MAIN = '#0f172a';
export const WARNING_COLOR = '#F59E0B';
export const DANGER_COLOR = '#EF4444';
export const SUCCESS_COLOR = '#10B981';
export const INFO_COLOR = '#3B82F6';
export const PURPLE_COLOR = '#8B5CF6';

// Status color mapping
export const STATUS_COLORS = {
  'draft': { bg: '#f1f5f9', color: '#475569', label: 'Draft' },
  'pending_approval': { bg: '#fff7ed', color: '#c2410c', label: 'Pending Approval' },
  'approved': { bg: '#f0fdf4', color: '#166534', label: 'Approved' },
  'rejected': { bg: '#fef2f2', color: '#991b1b', label: 'Rejected' },
  'sent_to_candidate': { bg: '#eff6ff', color: '#1e40af', label: 'Sent to Candidate' },
  'viewed': { bg: '#f0fdf4', color: '#166534', label: 'Viewed' },
  'accepted': { bg: '#f0fdf4', color: '#166534', label: 'Accepted' },
  'declined': { bg: '#fef2f2', color: '#991b1b', label: 'Declined' },
  'expired': { bg: '#f1f5f9', color: '#64748b', label: 'Expired' },
  'initiated': { bg: '#eff6ff', color: '#1e40af', label: 'Initiated' },
  'in_progress': { bg: '#fff7ed', color: '#c2410c', label: 'In Progress' },
  'completed': { bg: '#f0fdf4', color: '#166534', label: 'Completed' },
  'verified': { bg: '#f0fdf4', color: '#166534', label: 'Verified' },
  'failed': { bg: '#fef2f2', color: '#991b1b', label: 'Failed' },
  'on_hold': { bg: '#faf5ff', color: '#7e22ce', label: 'On Hold' },
  'not_started': { bg: '#f1f5f9', color: '#64748b', label: 'Not Started' }
};

// Tab configuration
export const TAB_CONFIG = [
  { id: 'overview', label: 'Overview', icon: 'ViewList' },
  { id: 'offer', label: 'Offer Management', icon: 'Assignment' },
  { id: 'documents', label: 'Documents', icon: 'Description' },
  { id: 'bgv', label: 'BGV', icon: 'GppGood' },
  { id: 'onboarding', label: 'Onboarding', icon: 'HowToReg' }
];