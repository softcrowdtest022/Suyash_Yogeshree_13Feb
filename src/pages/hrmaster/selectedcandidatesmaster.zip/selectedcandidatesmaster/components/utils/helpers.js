import { format, parseISO } from 'date-fns';
import { PRIMARY_BLUE, SUCCESS_COLOR, WARNING_COLOR, INFO_COLOR, DANGER_COLOR } from './constants';

// Format date
export const formatDate = (dateString) => {
  if (!dateString) return '-';
  try {
    return format(parseISO(dateString), 'dd MMM yyyy');
  } catch (e) {
    return dateString;
  }
};

// Get avatar initials
export const getAvatarInitials = (name) => {
  if (!name) return '?';
  return name.split(' ').map(word => word[0]).join('').slice(0, 2).toUpperCase() || 'U';
};

// Get avatar color
export const getAvatarColor = (name) => {
  if (!name) return PRIMARY_BLUE;
  
  const colors = [
    '#164e63', '#0e7490', '#0891b2', '#0c4a6e', '#1d4ed8',
    '#7c3aed', '#7e22ce', '#be185d', '#c2410c', '#059669'
  ];
  
  const charCode = name.charCodeAt(0) || 0;
  return colors[charCode % colors.length];
};

// Calculate candidate progress
export const calculateCandidateProgress = (candidate) => {
  let total = 5; // Offer, Documents, BGV, Statutory, Onboarding
  let completed = 0;

  if (candidate.offer && candidate.offer.status === 'accepted') completed++;
  if (candidate.documents && candidate.documents.verified === candidate.documents.total) completed++;
  if (candidate.bgv && candidate.bgv.status === 'completed') completed++;
  if (candidate.statutory && candidate.statutory.completed) completed++;
  if (candidate.onboarding && candidate.onboarding.status === 'completed') completed++;

  return (completed / total) * 100;
};

// Get progress color
export const getProgressColor = (value) => {
  return value >= 75 ? SUCCESS_COLOR : 
         value >= 50 ? WARNING_COLOR : 
         value >= 25 ? INFO_COLOR : DANGER_COLOR;
};