import React from 'react';
import { Card, CardContent, Stack, Typography, Avatar, Box } from '@mui/material';
import { alpha } from '@mui/material/styles';

const StatsCard = ({ 
  title, 
  value, 
  icon: Icon, 
  color, 
  bgColor,
  cardBgColor = '#FFFFFF', // Add card background color prop
  gradient = false, // Add gradient option
  width = '100%',
  minWidth = 270
}) => {
  // Define gradient backgrounds
  const gradients = {
    blue: 'linear-gradient(135deg, #00B4D8 0%, #0e7490 100%)',
    green: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
    purple: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
    orange: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)',
    red: 'linear-gradient(135deg, #EF4444 0%, #DC2626 100%)',
    indigo: 'linear-gradient(135deg, #6366F1 0%, #4F46E5 100%)',
    pink: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)'
  };

  // Determine background style
  const backgroundStyle = gradient 
    ? { background: gradients[gradient] || gradients.blue }
    : { backgroundColor: cardBgColor };

  // Determine text color based on background
  const textColor = gradient ? '#FFFFFF' : (color || '#0f172a');
  const iconBgColor = gradient 
    ? alpha('#FFFFFF', 0.2) 
    : alpha(color || bgColor || '#00B4D8', 0.1);
  const iconColor = gradient ? '#FFFFFF' : (color || bgColor || '#00B4D8');

  return (
    <Card sx={{ 
      borderRadius: 2, 
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
      width: width,
      minWidth: minWidth,
      height: '100%',
      transition: 'transform 0.2s, box-shadow 0.2s',
      '&:hover': {
        transform: 'translateY(-4px)',
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
      },
      ...backgroundStyle
    }}>
      <CardContent sx={{ 
        p: 3,
        '&:last-child': { pb: 3 }
      }}>
        <Stack direction="row" justifyContent="space-between" alignItems="center">
          <Box>
            <Typography 
              variant="caption" 
              sx={{ 
                color: gradient ? alpha('#FFFFFF', 0.9) : '#64748B',
                fontWeight: 500,
                textTransform: 'uppercase',
                letterSpacing: '0.5px'
              }}
            >
              {title}
            </Typography>
            <Typography 
              variant="h4" 
              fontWeight={700} 
              sx={{ 
                color: textColor,
                mt: 1,
                fontSize: '2rem'
              }}
            >
              {value}
            </Typography>
          </Box>
          <Avatar sx={{ 
            bgcolor: iconBgColor, 
            color: iconColor, 
            width: 56, 
            height: 56,
            borderRadius: 2 // Square avatar for modern look
          }}>
            <Icon sx={{ fontSize: 28 }} />
          </Avatar>
        </Stack>
      </CardContent>
    </Card>
  );
};

export default StatsCard;