import React from 'react';
import { Chip } from '@mui/material';
import { STATUS_COLORS } from '../utils/constants';
// import { STATUS_COLORS } from '../documen/utils/constants';

const StatusChip = ({ status }) => {
  const statusConfig = STATUS_COLORS[status] || STATUS_COLORS['draft'];
  
  return (
    <Chip
      label={statusConfig.label}
      size="small"
      sx={{
        backgroundColor: statusConfig.bg,
        color: statusConfig.color,
        fontWeight: 500,
        fontSize: '0.75rem',
        height: '24px',
        '& .MuiChip-label': {
          px: 1
        }
      }}
    />
  );
};

export default StatusChip;