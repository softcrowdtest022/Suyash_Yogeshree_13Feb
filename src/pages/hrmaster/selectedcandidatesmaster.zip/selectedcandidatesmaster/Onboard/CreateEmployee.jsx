import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  RadioGroup,
  Radio,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
  // Progress
  LinearProgress,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
  // Tabs
  Tab,
  Tabs,
  
} from '@mui/material';

// Icons - Fixed: Removed duplicates and added missing icons
import {
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  LocationOn as LocationIcon,
  Badge as BadgeIcon,
  Verified as VerifiedIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Close as CloseIcon,
  Save as SaveIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  Description as DescriptionIcon,
  Assignment as AssignmentIcon,
  Group as GroupIcon,
  SupervisorAccount as SupervisorIcon,
  AttachMoney as MoneyIcon,
  DateRange as DateRangeIcon,
  AccessTime as TimeIcon,
  HowToReg as HowToRegIcon,
  PersonAdd as PersonAddIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  HourglassEmpty as HourglassIcon  // Added missing HourglassIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    ACCEPTED: { bg: '#E8F5E9', color: '#2E7D32' },
    PENDING: { bg: '#FFF3E0', color: '#E65100' },
    REJECTED: { bg: '#FFEBEE', color: '#C62828' },
    ONBOARDED: { bg: '#E3F2FD', color: '#1976D2' },
    COMPLETED: { bg: '#E8F5E9', color: '#2E7D32' }
  };
  const color = colors[status] || colors.PENDING;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const InfoCard = styled(Card)(({ theme }) => ({
  backgroundColor: '#F8FAFC',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const CreateEmployee = ({ open, onClose, onCreate, candidateId: propCandidateId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    candidateId: propCandidateId || '',
    joiningDate: '',
    
    // Additional fields for employee creation (optional enhancements)
    employeeId: '',
    designation: '',
    department: '',
    reportingTo: '',
    employmentType: 'Permanent',
    probationPeriod: 6,
    workLocation: '',
    shift: 'General',
    bankDetails: {
      accountNumber: '',
      ifscCode: '',
      bankName: ''
    },
    emergencyContact: {
      name: '',
      relationship: '',
      phone: ''
    },
    documents: [],
    notes: ''
  });

  // Dropdown states
  const [candidates, setCandidates] = useState([]);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState('');
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [candidatePage, setCandidatePage] = useState(1);
  const [candidateTotalPages, setCandidateTotalPages] = useState(1);
  const [candidateInputValue, setCandidateInputValue] = useState('');

  // Candidate details
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [candidateDetails, setCandidateDetails] = useState(null);
  const [candidateDetailsLoading, setCandidateDetailsLoading] = useState(false);
  const [offerDetails, setOfferDetails] = useState(null);
  const [documentStatus, setDocumentStatus] = useState(null);

  // Creating state
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [createResult, setCreateResult] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // Steps definition
  const steps = ['Select Candidate', 'Review Details', 'Confirm & Create'];

  // Employment types
  const employmentTypes = ['Permanent', 'Contract', 'Temporary', 'Intern', 'Probation'];

  // Shift types
  const shiftTypes = ['General', 'Morning', 'Evening', 'Night', 'Rotational'];

  // Fetch candidates who have accepted offers
  const fetchCandidates = async (search = '', page = 1) => {
    setCandidateLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/ready-for-onboarding`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search,
          status: 'accepted' // Only candidates who accepted offers
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setCandidates(response.data.data || []);
        } else {
          setCandidates(prev => [...prev, ...(response.data.data || [])]);
        }
        setCandidateTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
    } finally {
      setCandidateLoading(false);
    }
  };

  // Fetch candidate details
  const fetchCandidateDetails = async (candidateId) => {
    if (!candidateId) return;
    
    setCandidateDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setCandidateDetails(response.data.data);
        
        // Auto-populate form with candidate data
        setFormData(prev => ({
          ...prev,
          candidateId: candidateId,
          designation: response.data.data.position || '',
          department: response.data.data.department || '',
          workLocation: response.data.data.location || '',
          // Auto-populate joining date from offer if available
          joiningDate: response.data.data.joiningDate || ''
        }));

        // Fetch offer details for this candidate
        fetchOfferDetails(candidateId);
        // Fetch document status
        fetchDocumentStatus(candidateId);
      }
    } catch (err) {
      console.error('Error fetching candidate details:', err);
    } finally {
      setCandidateDetailsLoading(false);
    }
  };

  // Fetch offer details
  const fetchOfferDetails = async (candidateId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/candidate/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setOfferDetails(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching offer details:', err);
    }
  };

  // Fetch document status
  const fetchDocumentStatus = async (candidateId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents/candidate/${candidateId}/status`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setDocumentStatus(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching document status:', err);
    }
  };

  // Load candidates when dropdown opens
  useEffect(() => {
    if (candidateOpen) {
      fetchCandidates(candidateSearch, 1);
    }
  }, [candidateOpen]);

  // Search candidates with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (candidateOpen) {
        setCandidatePage(1);
        fetchCandidates(candidateSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [candidateSearch, candidateOpen]);

  // Load candidate details when selected
  useEffect(() => {
    if (formData.candidateId) {
      fetchCandidateDetails(formData.candidateId);
    } else {
      setSelectedCandidate(null);
      setCandidateDetails(null);
      setOfferDetails(null);
      setDocumentStatus(null);
    }
  }, [formData.candidateId]);

  // Handle candidate scroll load more
  const handleCandidateScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (candidatePage < candidateTotalPages && !candidateLoading) {
        const nextPage = candidatePage + 1;
        setCandidatePage(nextPage);
        fetchCandidates(candidateSearch, nextPage);
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Handle nested objects (bankDetails, emergencyContact)
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }

    // Clear field error when user types
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.candidateId) {
        errors.candidateId = 'Please select a candidate';
      }
    } else if (step === 1) {
      if (!formData.joiningDate) {
        errors.joiningDate = 'Joining date is required';
      } else {
        const joiningDate = new Date(formData.joiningDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (joiningDate < today) {
          errors.joiningDate = 'Joining date cannot be in the past';
        }
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors({});
    // Small delay before retrying
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  const handleSubmit = async () => {
    if (!validateStep(1)) {
      setError('Please complete all required fields');
      return;
    }

    setCreating(true);
    setError('');
    setValidationErrors({});

    try {
      const token = localStorage.getItem('token');

      // Prepare data according to API expectations
      const submitData = {
        candidateId: formData.candidateId,
        joiningDate: formData.joiningDate
      };

      // Add optional fields if they have values (for enhanced version)
      if (formData.designation) submitData.designation = formData.designation;
      if (formData.department) submitData.department = formData.department;
      if (formData.reportingTo) submitData.reportingTo = formData.reportingTo;
      if (formData.employmentType) submitData.employmentType = formData.employmentType;
      if (formData.probationPeriod) submitData.probationPeriod = formData.probationPeriod;
      if (formData.workLocation) submitData.workLocation = formData.workLocation;
      if (formData.shift) submitData.shift = formData.shift;
      if (formData.bankDetails?.accountNumber) submitData.bankDetails = formData.bankDetails;
      if (formData.emergencyContact?.name) submitData.emergencyContact = formData.emergencyContact;
      if (formData.notes) submitData.notes = formData.notes;

      console.log('Creating employee with data:', submitData);

      const response = await axios.post(`${BASE_URL}/api/onboarding/employees`, submitData, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.data.success) {
        setCreateResult(response.data.data);
        setSuccess(true);
        
        if (onCreate) {
          onCreate(response.data.data);
        }
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to create employee');
      }
    } catch (err) {
      console.error('Error creating employee:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to create employee';
        
        // Handle specific error cases
        if (err.response.status === 400) {
          if (err.response.data.errors) {
            // Handle field validation errors
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setValidationErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 404) {
          setError('Candidate not found. Please select a valid candidate.');
        } else if (err.response.status === 409) {
          setError('Employee already exists for this candidate.');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setCreating(false);
    }
  };

  const resetForm = () => {
    setFormData({
      candidateId: propCandidateId || '',
      joiningDate: '',
      designation: '',
      department: '',
      reportingTo: '',
      employmentType: 'Permanent',
      probationPeriod: 6,
      workLocation: '',
      shift: 'General',
      bankDetails: {
        accountNumber: '',
        ifscCode: '',
        bankName: ''
      },
      emergencyContact: {
        name: '',
        relationship: '',
        phone: ''
      },
      documents: [],
      notes: ''
    });
    setSelectedCandidate(null);
    setCandidateDetails(null);
    setOfferDetails(null);
    setDocumentStatus(null);
    setError('');
    setValidationErrors({});
    setCreateResult(null);
    setSuccess(false);
    setActiveStep(0);
    setCandidateSearch('');
    setCandidateInputValue('');
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  // Check if all documents are verified
  const allDocumentsVerified = () => {
    if (!documentStatus) return false;
    return documentStatus.verified === documentStatus.total;
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select Candidate */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Candidate for Onboarding
              </Typography>

              <Grid container spacing={1.5}>
                <Grid item xs={12}>
                  <Autocomplete
                    size="small"
                    id="candidate-autocomplete"
                    open={candidateOpen}
                    onOpen={() => setCandidateOpen(true)}
                    onClose={() => setCandidateOpen(false)}
                    options={candidates}
                    loading={candidateLoading}
                    value={formData.candidateId ? candidates.find(c => c._id === formData.candidateId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        candidateId: newValue?._id || null 
                      }));
                      setSelectedCandidate(newValue);
                      if (validationErrors.candidateId) {
                        setValidationErrors(prev => ({ ...prev, candidateId: '' }));
                      }
                    }}
                    inputValue={candidateInputValue}
                    onInputChange={(event, newInputValue) => {
                      setCandidateInputValue(newInputValue);
                      setCandidateSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.name || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Candidate"
                        required
                        error={!!validationErrors.candidateId}
                        helperText={validationErrors.candidateId}
                        size="small"
                        placeholder="Search by name or email"
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            borderRadius: 1
                          }
                        }}
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {candidateLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.name}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.email} • {option.phone}
                          </Typography>
                          <Box sx={{ mt: 0.5 }}>
                            <StatusChip 
                              label={option.status || 'ACCEPTED'} 
                              size="small"
                              status={option.status || 'ACCEPTED'}
                            />
                          </Box>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleCandidateScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Quick Info if candidate selected */}
            {selectedCandidate && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Candidate Quick Info
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{selectedCandidate.name}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                    <Typography variant="body2">{selectedCandidate.email}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Phone</Typography>
                    <Typography variant="body2">{selectedCandidate.phone}</Typography>
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Position</Typography>
                    <Typography variant="body2">{selectedCandidate.position || 'N/A'}</Typography>
                  </Grid>
                </Grid>
              </Paper>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Candidate Details Loading */}
            {candidateDetailsLoading && (
              <Box sx={{ py: 4, textAlign: 'center' }}>
                <CircularProgress size={40} />
              </Box>
            )}

            {/* Candidate Full Details */}
            {candidateDetails && !candidateDetailsLoading && (
              <>
                {/* Personal Information */}
                <InfoCard>
                  <CardContent>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                      Personal Information
                    </Typography>
                    
                    <Grid container spacing={2}>
                      <Grid item xs={12} md={6}>
                        <DetailRow>
                          <DetailIcon><PersonIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Full Name</Typography>
                            <Typography variant="body2">{candidateDetails.name}</Typography>
                          </Box>
                        </DetailRow>
                        <DetailRow>
                          <DetailIcon><EmailIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Email</Typography>
                            <Typography variant="body2">{candidateDetails.email}</Typography>
                          </Box>
                        </DetailRow>
                        <DetailRow>
                          <DetailIcon><PhoneIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Phone</Typography>
                            <Typography variant="body2">{candidateDetails.phone}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                      <Grid item xs={12} md={6}>
                        <DetailRow>
                          <DetailIcon><CalendarIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Date of Birth</Typography>
                            <Typography variant="body2">{formatDate(candidateDetails.dob)}</Typography>
                          </Box>
                        </DetailRow>
                        <DetailRow>
                          <DetailIcon><LocationIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Address</Typography>
                            <Typography variant="body2">{candidateDetails.address || 'N/A'}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                    </Grid>
                  </CardContent>
                </InfoCard>

                {/* Offer Details */}
                {offerDetails && (
                  <InfoCard>
                    <CardContent>
                      <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                        Offer Details
                      </Typography>
                      
                      <Grid container spacing={2}>
                        <Grid item xs={12} md={6}>
                          <DetailRow>
                            <DetailIcon><WorkIcon /></DetailIcon>
                            <Box>
                              <Typography variant="caption" color="textSecondary">Position</Typography>
                              <Typography variant="body2">{offerDetails.positionTitle}</Typography>
                            </Box>
                          </DetailRow>
                          <DetailRow>
                            <DetailIcon><BusinessIcon /></DetailIcon>
                            <Box>
                              <Typography variant="caption" color="textSecondary">Department</Typography>
                              <Typography variant="body2">{offerDetails.department}</Typography>
                            </Box>
                          </DetailRow>
                          <DetailRow>
                            <DetailIcon><LocationIcon /></DetailIcon>
                            <Box>
                              <Typography variant="caption" color="textSecondary">Location</Typography>
                              <Typography variant="body2">{offerDetails.location}</Typography>
                            </Box>
                          </DetailRow>
                        </Grid>
                        <Grid item xs={12} md={6}>
                          <DetailRow>
                            <DetailIcon><SupervisorIcon /></DetailIcon>
                            <Box>
                              <Typography variant="caption" color="textSecondary">Reporting To</Typography>
                              <Typography variant="body2">{offerDetails.reportingTo}</Typography>
                            </Box>
                          </DetailRow>
                          <DetailRow>
                            <DetailIcon><MoneyIcon /></DetailIcon>
                            <Box>
                              <Typography variant="caption" color="textSecondary">Total CTC</Typography>
                              <Typography variant="body2">₹{offerDetails.totalCtc?.toLocaleString()}</Typography>
                            </Box>
                          </DetailRow>
                          <DetailRow>
                            <DetailIcon><DateRangeIcon /></DetailIcon>
                            <Box>
                              <Typography variant="caption" color="textSecondary">Offer Date</Typography>
                              <Typography variant="body2">{formatDate(offerDetails.createdAt)}</Typography>
                            </Box>
                          </DetailRow>
                        </Grid>
                      </Grid>
                    </CardContent>
                  </InfoCard>
                )}

                {/* Document Status */}
                {documentStatus && (
                  <InfoCard>
                    <CardContent>
                      <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                        Document Status
                      </Typography>
                      
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={4}>
                          <Paper sx={{ p: 1.5, textAlign: 'center', backgroundColor: '#E8F5E9' }}>
                            <Typography variant="h6" sx={{ color: '#2E7D32' }}>{documentStatus.verified || 0}</Typography>
                            <Typography variant="caption">Verified</Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <Paper sx={{ p: 1.5, textAlign: 'center', backgroundColor: '#FFF3E0' }}>
                            <Typography variant="h6" sx={{ color: '#E65100' }}>{documentStatus.pending || 0}</Typography>
                            <Typography variant="caption">Pending</Typography>
                          </Paper>
                        </Grid>
                        <Grid item xs={12} sm={4}>
                          <Paper sx={{ p: 1.5, textAlign: 'center', backgroundColor: '#FFEBEE' }}>
                            <Typography variant="h6" sx={{ color: '#C62828' }}>{documentStatus.rejected || 0}</Typography>
                            <Typography variant="caption">Rejected</Typography>
                          </Paper>
                        </Grid>
                      </Grid>

                      {!allDocumentsVerified() && (
                        <Alert severity="warning" sx={{ mt: 2, borderRadius: 1 }}>
                          Some documents are not yet verified. Employee can be created but may be marked as "Pending Verification".
                        </Alert>
                      )}
                    </CardContent>
                  </InfoCard>
                )}

                {/* Joining Details Form */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                    Joining Details
                  </Typography>

                  <Grid container spacing={1.5}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Joining Date *"
                        name="joiningDate"
                        type="date"
                        value={formData.joiningDate}
                        onChange={handleChange}
                        required
                        error={!!validationErrors.joiningDate}
                        helperText={validationErrors.joiningDate}
                        InputLabelProps={{ shrink: true }}
                        inputProps={{ min: new Date().toISOString().split('T')[0] }}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>

                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Employment Type</InputLabel>
                        <Select
                          name="employmentType"
                          value={formData.employmentType}
                          onChange={handleChange}
                          label="Employment Type"
                        >
                          {employmentTypes.map(type => (
                            <MenuItem key={type} value={type}>{type}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>

                    <Grid item xs={12} sm={6}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Probation Period (months)"
                        name="probationPeriod"
                        type="number"
                        value={formData.probationPeriod}
                        onChange={handleChange}
                        inputProps={{ min: 0, max: 12 }}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>

                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Shift</InputLabel>
                        <Select
                          name="shift"
                          value={formData.shift}
                          onChange={handleChange}
                          label="Shift"
                        >
                          {shiftTypes.map(shift => (
                            <MenuItem key={shift} value={shift}>{shift}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Reporting To"
                        name="reportingTo"
                        value={formData.reportingTo}
                        onChange={handleChange}
                        placeholder="Manager/Supervisor name"
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>

                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Notes / Special Instructions"
                        name="notes"
                        value={formData.notes}
                        onChange={handleChange}
                        multiline
                        rows={2}
                        placeholder="Any additional notes for employee creation..."
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                  </Grid>
                </Paper>

                {/* Bank Details (Optional) */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                    Bank Details (Optional)
                  </Typography>

                  <Grid container spacing={1.5}>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Account Number"
                        name="bankDetails.accountNumber"
                        value={formData.bankDetails.accountNumber}
                        onChange={handleChange}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        size="small"
                        label="IFSC Code"
                        name="bankDetails.ifscCode"
                        value={formData.bankDetails.ifscCode}
                        onChange={handleChange}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Bank Name"
                        name="bankDetails.bankName"
                        value={formData.bankDetails.bankName}
                        onChange={handleChange}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                  </Grid>
                </Paper>

                {/* Emergency Contact (Optional) */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                    Emergency Contact (Optional)
                  </Typography>

                  <Grid container spacing={1.5}>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Contact Name"
                        name="emergencyContact.name"
                        value={formData.emergencyContact.name}
                        onChange={handleChange}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Relationship"
                        name="emergencyContact.relationship"
                        value={formData.emergencyContact.relationship}
                        onChange={handleChange}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={4}>
                      <TextField
                        fullWidth
                        size="small"
                        label="Phone Number"
                        name="emergencyContact.phone"
                        value={formData.emergencyContact.phone}
                        onChange={handleChange}
                        sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                      />
                    </Grid>
                  </Grid>
                </Paper>
              </>
            )}
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Confirmation Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Review Employee Creation
              </Typography>

              <Grid container spacing={2}>
                {/* Candidate Information */}
                <Grid item xs={12}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Candidate Information
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>{candidateDetails?.name}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                        <Typography variant="body2">{candidateDetails?.email}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Phone</Typography>
                        <Typography variant="body2">{candidateDetails?.phone}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Position</Typography>
                        <Typography variant="body2">{offerDetails?.positionTitle || candidateDetails?.position}</Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>

                {/* Joining Details */}
                <Grid item xs={12}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Joining Details
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Joining Date</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>{formatDate(formData.joiningDate)}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Employment Type</Typography>
                        <Typography variant="body2">{formData.employmentType}</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Probation Period</Typography>
                        <Typography variant="body2">{formData.probationPeriod} months</Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Shift</Typography>
                        <Typography variant="body2">{formData.shift}</Typography>
                      </Grid>
                      {formData.reportingTo && (
                        <Grid item xs={12}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Reporting To</Typography>
                          <Typography variant="body2">{formData.reportingTo}</Typography>
                        </Grid>
                      )}
                    </Grid>
                  </Paper>
                </Grid>

                {/* Document Status Summary */}
                {documentStatus && (
                  <Grid item xs={12}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Document Status
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                        <Chip
                          icon={<CheckCircleIcon />}
                          label={`${documentStatus.verified || 0} Verified`}
                          size="small"
                          sx={{ backgroundColor: '#E8F5E9', color: '#2E7D32' }}
                        />
                        <Chip
                          icon={<HourglassIcon />}
                          label={`${documentStatus.pending || 0} Pending`}
                          size="small"
                          sx={{ backgroundColor: '#FFF3E0', color: '#E65100' }}
                        />
                        <Chip
                          icon={<ErrorIcon />}
                          label={`${documentStatus.rejected || 0} Rejected`}
                          size="small"
                          sx={{ backgroundColor: '#FFEBEE', color: '#C62828' }}
                        />
                      </Box>
                    </Paper>
                  </Grid>
                )}

                {/* Additional Info if provided */}
                {formData.notes && (
                  <Grid item xs={12}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Notes
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.notes}</Typography>
                    </Paper>
                  </Grid>
                )}
              </Grid>
            </Paper>

            {/* Confirmation Notice */}
            <Alert 
              severity={allDocumentsVerified() ? "success" : "warning"} 
              sx={{ borderRadius: 1 }}
              icon={allDocumentsVerified() ? <VerifiedIcon /> : <WarningIcon />}
            >
              <Typography variant="body2">
                {allDocumentsVerified() 
                  ? "All documents are verified. Employee can be created with full status."
                  : "Some documents are pending verification. Employee will be created but marked for document follow-up."}
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {Object.keys(validationErrors).length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Create Employee
        </Typography>
        {!creating && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            <Stepper
              activeStep={activeStep}
              alternativeLabel
              connector={<ColorConnector />}
              sx={{ mb: 2, mt: 1 }}
            >
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>
                    <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || creating}
              size="small"
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={creating}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={creating || !formData.candidateId || !formData.joiningDate}
                  size="small"
                  startIcon={creating ? <CircularProgress size={16} color="inherit" /> : <PersonAddIcon />}
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  {creating ? 'Creating...' : 'Create Employee'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={creating}
                  size="small"
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <HowToRegIcon sx={{ fontSize: 64, color: '#4CAF50', mb: 2 }} />
            <Typography variant="h5" sx={{ mb: 2, color: '#101010', fontWeight: 600 }}>
              Employee Created Successfully!
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              The employee has been added to the system.
            </Typography>
            
            {createResult && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', mb: 3, maxWidth: 400, mx: 'auto' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1 }}>
                  Employee Details
                </Typography>
                <Typography variant="body2">
                  <strong>Employee ID:</strong> {createResult.employeeId}
                </Typography>
                <Typography variant="body2">
                  <strong>Candidate ID:</strong> {createResult.candidateId}
                </Typography>
                <Typography variant="body2">
                  <strong>Name:</strong> {candidateDetails?.name}
                </Typography>
              </Paper>
            )}

            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  resetForm();
                  setSuccess(false);
                }}
                startIcon={<PersonAddIcon />}
              >
                Create Another
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default CreateEmployee;