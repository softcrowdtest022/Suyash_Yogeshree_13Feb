import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  RadioGroup,
  Radio,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
  // Progress
  LinearProgress,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
  // Tabs
  Tab,
  Tabs,
  
} from '@mui/material';

// Icons - Fixed: Removed duplicates and added missing icons
import {
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  LocationOn as LocationIcon,
  Badge as BadgeIcon,
  Verified as VerifiedIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Close as CloseIcon,
  Save as SaveIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  Description as DescriptionIcon,
  Assignment as AssignmentIcon,
  Group as GroupIcon,
  SupervisorAccount as SupervisorIcon,
  AttachMoney as MoneyIcon,
  DateRange as DateRangeIcon,
  AccessTime as TimeIcon,
  HowToReg as HowToRegIcon,
  PersonAdd as PersonAddIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  HourglassEmpty as HourglassIcon  // Added missing HourglassIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    COMPLETED: { bg: '#E8F5E9', color: '#2E7D32' },
    PENDING: { bg: '#FFF3E0', color: '#E65100' },
    VERIFIED: { bg: '#E8F5E9', color: '#2E7D32' },
    REJECTED: { bg: '#FFEBEE', color: '#C62828' },
    ACTIVE: { bg: '#E3F2FD', color: '#1976D2' }
  };
  const color = colors[status] || colors.PENDING;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const InfoCard = styled(Card)(({ theme }) => ({
  backgroundColor: '#F8FAFC',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const SectionHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginBottom: 16,
  '& .MuiTypography-root': {
    fontWeight: 600,
    color: '#1976D2'
  }
}));

const AddDetails = ({ open, onClose, onAdd, employeeId: propEmployeeId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState({
    employeeId: propEmployeeId || '',
    
    // PAN Details
    pan: '',
    panVerified: false,
    
    // Aadhar Details
    aadhar: '',
    aadharVerified: false,
    
    // UAN (Universal Account Number)
    uan: '',
    uanVerified: false,
    
    // PF Details
    pfNumber: '',
    pfUan: '',
    pfJoinDate: '',
    pfStatus: 'Active',
    pfVerified: false,
    
    // ESIC Details
    esicNumber: '',
    esicJoinDate: '',
    esicStatus: 'Active',
    esicVerified: false,
    
    // Bank Details
    bankDetails: {
      accountNumber: '',
      accountHolderName: '',
      bankName: '',
      branch: '',
      ifscCode: '',
      accountType: 'Savings',
      verified: false
    },
    
    // Additional Details
    gratuityNominee: '',
    gratuityNomineeRelation: '',
    insuranceNominee: '',
    insuranceNomineeRelation: '',
    
    // Documents
    documents: [],
    
    // Notes
    notes: ''
  });

  // Employees dropdown state
  const [employees, setEmployees] = useState([]);
  const [employeeLoading, setEmployeeLoading] = useState(false);
  const [employeeSearch, setEmployeeSearch] = useState('');
  const [employeeOpen, setEmployeeOpen] = useState(false);
  const [employeePage, setEmployeePage] = useState(1);
  const [employeeTotalPages, setEmployeeTotalPages] = useState(1);
  const [employeeInputValue, setEmployeeInputValue] = useState('');

  // Employee details
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [employeeDetails, setEmployeeDetails] = useState(null);
  const [employeeDetailsLoading, setEmployeeDetailsLoading] = useState(false);
  const [existingStatutory, setExistingStatutory] = useState(null);
  const [statutoryLoading, setStatutoryLoading] = useState(false);

  // Saving state
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [saveResult, setSaveResult] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // Steps definition
  const steps = ['Select Employee', 'Add Statutory Details', 'Review & Save'];

  // Account types
  const accountTypes = ['Savings', 'Current', 'Salary', 'Fixed Deposit', 'Recurring Deposit'];

  // PF/ESIC Status types
  const statusTypes = ['Active', 'Inactive', 'Suspended', 'Transferred'];

  // Fetch employees for dropdown
  const fetchEmployees = async (search = '', page = 1) => {
    setEmployeeLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/employees`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setEmployees(response.data.data || []);
        } else {
          setEmployees(prev => [...prev, ...(response.data.data || [])]);
        }
        setEmployeeTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching employees:', err);
    } finally {
      setEmployeeLoading(false);
    }
  };

  // Fetch employee details
  const fetchEmployeeDetails = async (employeeId) => {
    if (!employeeId) return;
    
    setEmployeeDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/employees/${employeeId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setEmployeeDetails(response.data.data);
        
        // Auto-populate some fields if available
        setFormData(prev => ({
          ...prev,
          employeeId: employeeId,
          bankDetails: {
            ...prev.bankDetails,
            accountHolderName: response.data.data.name || ''
          }
        }));
      }
    } catch (err) {
      console.error('Error fetching employee details:', err);
    } finally {
      setEmployeeDetailsLoading(false);
    }
  };

  // Fetch existing statutory details
  const fetchStatutoryDetails = async (employeeId) => {
    if (!employeeId) return;
    
    setStatutoryLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/onboarding/employees/${employeeId}/statutory`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success && response.data.data) {
        setExistingStatutory(response.data.data);
        
        // Pre-fill form with existing data
        const data = response.data.data;
        setFormData(prev => ({
          ...prev,
          pan: data.pan || '',
          aadhar: data.aadhar || '',
          uan: data.uan || '',
          pfNumber: data.pfNumber || '',
          esicNumber: data.esicNumber || '',
          bankDetails: {
            ...prev.bankDetails,
            accountNumber: data.bankDetails?.accountNumber || '',
            accountHolderName: data.bankDetails?.accountHolderName || employeeDetails?.name || '',
            bankName: data.bankDetails?.bankName || '',
            branch: data.bankDetails?.branch || '',
            ifscCode: data.bankDetails?.ifscCode || '',
            accountType: data.bankDetails?.accountType || 'Savings'
          }
        }));
      }
    } catch (err) {
      console.error('Error fetching statutory details:', err);
      // 404 means no existing data, that's fine
    } finally {
      setStatutoryLoading(false);
    }
  };

  // Load employees when dropdown opens
  useEffect(() => {
    if (employeeOpen) {
      fetchEmployees(employeeSearch, 1);
    }
  }, [employeeOpen]);

  // Search employees with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (employeeOpen) {
        setEmployeePage(1);
        fetchEmployees(employeeSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [employeeSearch, employeeOpen]);

  // Load employee details when selected
  useEffect(() => {
    if (formData.employeeId) {
      fetchEmployeeDetails(formData.employeeId);
      fetchStatutoryDetails(formData.employeeId);
    } else {
      setSelectedEmployee(null);
      setEmployeeDetails(null);
      setExistingStatutory(null);
    }
  }, [formData.employeeId]);

  // Handle employee scroll load more
  const handleEmployeeScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (employeePage < employeeTotalPages && !employeeLoading) {
        const nextPage = employeePage + 1;
        setEmployeePage(nextPage);
        fetchEmployees(employeeSearch, nextPage);
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Handle nested objects (bankDetails)
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }

    // Clear field error when user types
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  // Validation functions
  const validatePAN = (pan) => {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return panRegex.test(pan);
  };

  const validateAadhar = (aadhar) => {
    const aadharRegex = /^\d{12}$/;
    return aadharRegex.test(aadhar);
  };

  const validateUAN = (uan) => {
    const uanRegex = /^\d{12}$/;
    return uanRegex.test(uan);
  };

  const validateIFSC = (ifsc) => {
    const ifscRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
    return ifscRegex.test(ifsc);
  };

  const validateAccountNumber = (accNo) => {
    return accNo.length >= 9 && accNo.length <= 18;
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.employeeId) {
        errors.employeeId = 'Please select an employee';
      }
    } else if (step === 1) {
      // PAN validation (optional but if provided must be valid)
      if (formData.pan && !validatePAN(formData.pan)) {
        errors.pan = 'Invalid PAN format (e.g., ABCDE1234F)';
      }
      
      // Aadhar validation (optional but if provided must be valid)
      if (formData.aadhar && !validateAadhar(formData.aadhar)) {
        errors.aadhar = 'Invalid Aadhar number (12 digits required)';
      }
      
      // UAN validation (optional but if provided must be valid)
      if (formData.uan && !validateUAN(formData.uan)) {
        errors.uan = 'Invalid UAN (12 digits required)';
      }
      
      // PF Number format (optional)
      if (formData.pfNumber && !formData.pfNumber.match(/^[A-Z]{2}\/\d{5}\/\d{3}$/)) {
        errors.pfNumber = 'Invalid PF number format (e.g., MH/12345/123)';
      }
      
      // ESIC Number format (optional)
      if (formData.esicNumber && !formData.esicNumber.match(/^\d{10}$/)) {
        errors.esicNumber = 'Invalid ESIC number (10 digits required)';
      }
      
      // Bank Details validation (optional but if provided must be valid)
      if (formData.bankDetails.accountNumber) {
        if (!validateAccountNumber(formData.bankDetails.accountNumber)) {
          errors['bankDetails.accountNumber'] = 'Account number should be 9-18 digits';
        }
      }
      
      if (formData.bankDetails.ifscCode && !validateIFSC(formData.bankDetails.ifscCode)) {
        errors['bankDetails.ifscCode'] = 'Invalid IFSC code (e.g., SBIN0001234)';
      }
      
      if (formData.bankDetails.accountHolderName && !formData.bankDetails.accountHolderName.trim()) {
        errors['bankDetails.accountHolderName'] = 'Account holder name is required if bank details are provided';
      }
      
      if (formData.bankDetails.bankName && !formData.bankDetails.bankName.trim()) {
        errors['bankDetails.bankName'] = 'Bank name is required if bank details are provided';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please correct the validation errors');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors({});
    // Small delay before retrying
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  const handleSubmit = async () => {
    if (!validateStep(1)) {
      setError('Please correct the validation errors');
      return;
    }

    setSaving(true);
    setError('');
    setValidationErrors({});

    try {
      const token = localStorage.getItem('token');

      // Prepare data according to API expectations
      const submitData = {
        pan: formData.pan || undefined,
        aadhar: formData.aadhar || undefined,
        uan: formData.uan || undefined,
        pfNumber: formData.pfNumber || undefined,
        esicNumber: formData.esicNumber || undefined,
        bankDetails: {
          accountNumber: formData.bankDetails.accountNumber || undefined,
          accountHolderName: formData.bankDetails.accountHolderName || undefined,
          bankName: formData.bankDetails.bankName || undefined,
          branch: formData.bankDetails.branch || undefined,
          ifscCode: formData.bankDetails.ifscCode || undefined,
          accountType: formData.bankDetails.accountType || 'Savings'
        }
      };

      // Remove undefined values
      Object.keys(submitData).forEach(key => {
        if (submitData[key] === undefined) delete submitData[key];
      });
      
      if (submitData.bankDetails) {
        Object.keys(submitData.bankDetails).forEach(key => {
          if (submitData.bankDetails[key] === undefined) delete submitData.bankDetails[key];
        });
      }

      console.log('Submitting statutory details:', submitData);

      const response = await axios.post(
        `${BASE_URL}/api/onboarding/employees/${formData.employeeId}/statutory`,
        submitData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.success) {
        setSaveResult(response.data);
        setSuccess(true);
        
        if (onAdd) {
          onAdd(response.data);
        }
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to save statutory details');
      }
    } catch (err) {
      console.error('Error saving statutory details:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to save statutory details';
        
        // Handle specific error cases
        if (err.response.status === 400) {
          if (err.response.data.errors) {
            // Handle field validation errors
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setValidationErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 404) {
          setError('Employee not found. Please select a valid employee.');
        } else if (err.response.status === 409) {
          setError('Statutory details already exist for this employee.');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setFormData({
      employeeId: propEmployeeId || '',
      pan: '',
      panVerified: false,
      aadhar: '',
      aadharVerified: false,
      uan: '',
      uanVerified: false,
      pfNumber: '',
      pfUan: '',
      pfJoinDate: '',
      pfStatus: 'Active',
      pfVerified: false,
      esicNumber: '',
      esicJoinDate: '',
      esicStatus: 'Active',
      esicVerified: false,
      bankDetails: {
        accountNumber: '',
        accountHolderName: '',
        bankName: '',
        branch: '',
        ifscCode: '',
        accountType: 'Savings',
        verified: false
      },
      gratuityNominee: '',
      gratuityNomineeRelation: '',
      insuranceNominee: '',
      insuranceNomineeRelation: '',
      documents: [],
      notes: ''
    });
    setSelectedEmployee(null);
    setEmployeeDetails(null);
    setExistingStatutory(null);
    setError('');
    setValidationErrors({});
    setSaveResult(null);
    setSuccess(false);
    setActiveStep(0);
    setActiveTab(0);
    setEmployeeSearch('');
    setEmployeeInputValue('');
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  // Mask sensitive data
  const maskSensitiveData = (value, visibleChars = 4) => {
    if (!value) return '';
    if (value.length <= visibleChars) return value;
    const masked = '*'.repeat(value.length - visibleChars) + value.slice(-visibleChars);
    return masked;
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select Employee */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Employee
              </Typography>

              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12 }}>
                  <Autocomplete
                    size="small"
                    id="employee-autocomplete"
                    open={employeeOpen}
                    onOpen={() => setEmployeeOpen(true)}
                    onClose={() => setEmployeeOpen(false)}
                    options={employees}
                    loading={employeeLoading}
                    value={formData.employeeId ? employees.find(e => e._id === formData.employeeId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        employeeId: newValue?._id || null 
                      }));
                      setSelectedEmployee(newValue);
                      if (validationErrors.employeeId) {
                        setValidationErrors(prev => ({ ...prev, employeeId: '' }));
                      }
                    }}
                    inputValue={employeeInputValue}
                    onInputChange={(event, newInputValue) => {
                      setEmployeeInputValue(newInputValue);
                      setEmployeeSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.employeeId || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Employee"
                        required
                        error={!!validationErrors.employeeId}
                        helperText={validationErrors.employeeId}
                        size="small"
                        placeholder="Search by Employee ID or Name"
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            borderRadius: 1
                          }
                        }}
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {employeeLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.employeeId}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.name} • {option.designation}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleEmployeeScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Employee Quick Info */}
            {selectedEmployee && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Employee Information
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Employee ID</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{selectedEmployee.employeeId}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                    <Typography variant="body2">{selectedEmployee.name}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Designation</Typography>
                    <Typography variant="body2">{selectedEmployee.designation}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Department</Typography>
                    <Typography variant="body2">{selectedEmployee.department}</Typography>
                  </Grid>
                </Grid>
              </Paper>
            )}

            {/* Existing Statutory Info */}
            {existingStatutory && (
              <Alert severity="info" sx={{ borderRadius: 1 }}>
                <Typography variant="body2">
                  Statutory details already exist for this employee. You can update them below.
                </Typography>
              </Alert>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Loading State */}
            {(employeeDetailsLoading || statutoryLoading) && (
              <Box sx={{ py: 2, textAlign: 'center' }}>
                <CircularProgress size={30} />
              </Box>
            )}

            {/* Tabs for different sections */}
            {employeeDetails && !employeeDetailsLoading && (
              <>
                <Tabs
                  value={activeTab}
                  onChange={handleTabChange}
                  variant="fullWidth"
                  sx={{
                    borderBottom: '1px solid #E0E0E0',
                    '& .MuiTab-root': {
                      minHeight: 48,
                      fontWeight: 500
                    }
                  }}
                >
                  <Tab label="PAN & Aadhar" icon={<FingerprintIcon />} iconPosition="start" />
                  <Tab label="PF & ESIC" icon={<SecurityIcon />} iconPosition="start" />
                  <Tab label="Bank Details" icon={<AccountBalanceIcon />} iconPosition="start" />
                  <Tab label="Other Details" icon={<BusinessCenterIcon />} iconPosition="start" />
                </Tabs>

                {/* PAN & Aadhar Tab */}
                {activeTab === 0 && (
                  <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                    <SectionHeader>
                      <DetailIcon><FingerprintIcon /></DetailIcon>
                      <Typography variant="subtitle2">PAN & Aadhar Details</Typography>
                    </SectionHeader>

                    <Grid container spacing={2}>
                      {/* PAN */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="PAN Number"
                          name="pan"
                          value={formData.pan}
                          onChange={handleChange}
                          error={!!validationErrors.pan}
                          helperText={validationErrors.pan || 'Format: ABCDE1234F'}
                          placeholder="e.g., ABCDE1234F"
                          inputProps={{ maxLength: 10, style: { textTransform: 'uppercase' } }}
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Aadhar */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Aadhar Number"
                          name="aadhar"
                          value={formData.aadhar}
                          onChange={handleChange}
                          error={!!validationErrors.aadhar}
                          helperText={validationErrors.aadhar || '12 digits required'}
                          placeholder="e.g., 123456789012"
                          inputProps={{ maxLength: 12 }}
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* UAN */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="UAN (Universal Account Number)"
                          name="uan"
                          value={formData.uan}
                          onChange={handleChange}
                          error={!!validationErrors.uan}
                          helperText={validationErrors.uan || '12 digits required'}
                          placeholder="e.g., 101234567890"
                          inputProps={{ maxLength: 12 }}
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>
                    </Grid>
                  </Paper>
                )}

                {/* PF & ESIC Tab */}
                {activeTab === 1 && (
                  <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                    <SectionHeader>
                      <DetailIcon><SecurityIcon /></DetailIcon>
                      <Typography variant="subtitle2">PF & ESIC Details</Typography>
                    </SectionHeader>

                    <Grid container spacing={2}>
                      {/* PF Number */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="PF Number"
                          name="pfNumber"
                          value={formData.pfNumber}
                          onChange={handleChange}
                          error={!!validationErrors.pfNumber}
                          helperText={validationErrors.pfNumber || 'Format: MH/12345/123'}
                          placeholder="e.g., MH/12345/123"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* ESIC Number */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="ESIC Number"
                          name="esicNumber"
                          value={formData.esicNumber}
                          onChange={handleChange}
                          error={!!validationErrors.esicNumber}
                          helperText={validationErrors.esicNumber || '10 digits required'}
                          placeholder="e.g., 1234567890"
                          inputProps={{ maxLength: 10 }}
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* PF Join Date */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="PF Join Date"
                          name="pfJoinDate"
                          type="date"
                          value={formData.pfJoinDate}
                          onChange={handleChange}
                          InputLabelProps={{ shrink: true }}
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* PF Status */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <FormControl fullWidth size="small">
                          <InputLabel>PF Status</InputLabel>
                          <Select
                            name="pfStatus"
                            value={formData.pfStatus}
                            onChange={handleChange}
                            label="PF Status"
                          >
                            {statusTypes.map(status => (
                              <MenuItem key={status} value={status}>{status}</MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Grid>
                    </Grid>
                  </Paper>
                )}

                {/* Bank Details Tab */}
                {activeTab === 2 && (
                  <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                    <SectionHeader>
                      <DetailIcon><AccountBalanceIcon /></DetailIcon>
                      <Typography variant="subtitle2">Bank Account Details</Typography>
                    </SectionHeader>

                    <Grid container spacing={2}>
                      {/* Account Holder Name */}
                      <Grid size={{ xs: 12 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Account Holder Name"
                          name="bankDetails.accountHolderName"
                          value={formData.bankDetails.accountHolderName}
                          onChange={handleChange}
                          error={!!validationErrors['bankDetails.accountHolderName']}
                          helperText={validationErrors['bankDetails.accountHolderName']}
                          placeholder="As per bank records"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Account Number */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Account Number"
                          name="bankDetails.accountNumber"
                          value={formData.bankDetails.accountNumber}
                          onChange={handleChange}
                          error={!!validationErrors['bankDetails.accountNumber']}
                          helperText={validationErrors['bankDetails.accountNumber']}
                          placeholder="Enter account number"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* IFSC Code */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="IFSC Code"
                          name="bankDetails.ifscCode"
                          value={formData.bankDetails.ifscCode}
                          onChange={handleChange}
                          error={!!validationErrors['bankDetails.ifscCode']}
                          helperText={validationErrors['bankDetails.ifscCode'] || 'e.g., SBIN0001234'}
                          placeholder="Enter IFSC code"
                          inputProps={{ style: { textTransform: 'uppercase' } }}
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Bank Name */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Bank Name"
                          name="bankDetails.bankName"
                          value={formData.bankDetails.bankName}
                          onChange={handleChange}
                          error={!!validationErrors['bankDetails.bankName']}
                          helperText={validationErrors['bankDetails.bankName']}
                          placeholder="e.g., State Bank of India"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Branch */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Branch"
                          name="bankDetails.branch"
                          value={formData.bankDetails.branch}
                          onChange={handleChange}
                          placeholder="e.g., Main Branch"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Account Type */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <FormControl fullWidth size="small">
                          <InputLabel>Account Type</InputLabel>
                          <Select
                            name="bankDetails.accountType"
                            value={formData.bankDetails.accountType}
                            onChange={handleChange}
                            label="Account Type"
                          >
                            {accountTypes.map(type => (
                              <MenuItem key={type} value={type}>{type}</MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                      </Grid>
                    </Grid>
                  </Paper>
                )}

                {/* Other Details Tab */}
                {activeTab === 3 && (
                  <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                    <SectionHeader>
                      <DetailIcon><BusinessCenterIcon /></DetailIcon>
                      <Typography variant="subtitle2">Other Details</Typography>
                    </SectionHeader>

                    <Grid container spacing={2}>
                      {/* Gratuity Nominee */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Gratuity Nominee Name"
                          name="gratuityNominee"
                          value={formData.gratuityNominee}
                          onChange={handleChange}
                          placeholder="Enter nominee name"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Gratuity Nominee Relation */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Relationship"
                          name="gratuityNomineeRelation"
                          value={formData.gratuityNomineeRelation}
                          onChange={handleChange}
                          placeholder="e.g., Spouse, Child"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Insurance Nominee */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Insurance Nominee Name"
                          name="insuranceNominee"
                          value={formData.insuranceNominee}
                          onChange={handleChange}
                          placeholder="Enter nominee name"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Insurance Nominee Relation */}
                      <Grid size={{ xs: 12, md: 6 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Relationship"
                          name="insuranceNomineeRelation"
                          value={formData.insuranceNomineeRelation}
                          onChange={handleChange}
                          placeholder="e.g., Spouse, Child"
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>

                      {/* Notes */}
                      <Grid size={{ xs: 12 }}>
                        <TextField
                          fullWidth
                          size="small"
                          label="Additional Notes"
                          name="notes"
                          value={formData.notes}
                          onChange={handleChange}
                          multiline
                          rows={3}
                          placeholder="Any additional notes or remarks..."
                          sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                        />
                      </Grid>
                    </Grid>
                  </Paper>
                )}
              </>
            )}
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Review Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Review Statutory Details
              </Typography>

              <Grid container spacing={2}>
                {/* Employee Information */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Employee
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {employeeDetails?.name} ({employeeDetails?.employeeId})
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {employeeDetails?.designation} • {employeeDetails?.department}
                    </Typography>
                  </Paper>
                </Grid>

                {/* PAN & Aadhar */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    PAN & Aadhar Details
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid size={{ xs: 4 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>PAN</Typography>
                        <Typography variant="body2">
                          {formData.pan ? maskSensitiveData(formData.pan) : 'Not provided'}
                        </Typography>
                      </Grid>
                      <Grid size={{ xs: 4 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Aadhar</Typography>
                        <Typography variant="body2">
                          {formData.aadhar ? maskSensitiveData(formData.aadhar) : 'Not provided'}
                        </Typography>
                      </Grid>
                      <Grid size={{ xs: 4 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>UAN</Typography>
                        <Typography variant="body2">
                          {formData.uan ? maskSensitiveData(formData.uan) : 'Not provided'}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>

                {/* PF & ESIC */}
                {(formData.pfNumber || formData.esicNumber) && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      PF & ESIC Details
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Grid container spacing={1}>
                        {formData.pfNumber && (
                          <Grid size={{ xs: 6 }}>
                            <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>PF Number</Typography>
                            <Typography variant="body2">{formData.pfNumber}</Typography>
                          </Grid>
                        )}
                        {formData.esicNumber && (
                          <Grid size={{ xs: 6 }}>
                            <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>ESIC Number</Typography>
                            <Typography variant="body2">{formData.esicNumber}</Typography>
                          </Grid>
                        )}
                      </Grid>
                    </Paper>
                  </Grid>
                )}

                {/* Bank Details */}
                {formData.bankDetails.accountNumber && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Bank Details
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Grid container spacing={1}>
                        <Grid size={{ xs: 12 }}>
                          <Typography variant="body2">
                            <strong>Account Holder:</strong> {formData.bankDetails.accountHolderName}
                          </Typography>
                        </Grid>
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Account Number</Typography>
                          <Typography variant="body2">
                            {maskSensitiveData(formData.bankDetails.accountNumber)}
                          </Typography>
                        </Grid>
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>IFSC Code</Typography>
                          <Typography variant="body2">{formData.bankDetails.ifscCode}</Typography>
                        </Grid>
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Bank Name</Typography>
                          <Typography variant="body2">{formData.bankDetails.bankName}</Typography>
                        </Grid>
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Account Type</Typography>
                          <Typography variant="body2">{formData.bankDetails.accountType}</Typography>
                        </Grid>
                      </Grid>
                    </Paper>
                  </Grid>
                )}

                {/* Notes */}
                {formData.notes && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Notes
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.notes}</Typography>
                    </Paper>
                  </Grid>
                )}
              </Grid>
            </Paper>

            {/* Data Privacy Notice */}
            <Alert severity="info" sx={{ borderRadius: 1 }} icon={<LockIcon />}>
              <Typography variant="body2">
                <strong>Data Privacy:</strong> All statutory information is encrypted and stored securely 
                as per data protection regulations. Only authorized personnel can access this information.
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {Object.keys(validationErrors).length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Add Statutory Details
        </Typography>
        {!saving && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            <Stepper
              activeStep={activeStep}
              alternativeLabel
              connector={<ColorConnector />}
              sx={{ mb: 2, mt: 1 }}
            >
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>
                    <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || saving}
              size="small"
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={saving}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={saving || !formData.employeeId}
                  size="small"
                  startIcon={saving ? <CircularProgress size={16} color="inherit" /> : <SaveIcon />}
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  {saving ? 'Saving...' : 'Save Details'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={saving}
                  size="small"
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <VerifiedIcon sx={{ fontSize: 64, color: '#4CAF50', mb: 2 }} />
            <Typography variant="h5" sx={{ mb: 2, color: '#101010', fontWeight: 600 }}>
              Statutory Details Saved!
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              {saveResult?.message || 'Statutory details have been added successfully.'}
            </Typography>
            
            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  resetForm();
                  setSuccess(false);
                }}
                startIcon={<AddIcon />}
              >
                Add Another
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default AddDetails;