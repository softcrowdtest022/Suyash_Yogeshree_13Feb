import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  
  // Feedback components
  Alert,  // Moved Alert from icons to here
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
  // Progress
  LinearProgress,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
} from '@mui/material';

// Icons - Removed Alert from here
import {
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  LocationOn as LocationIcon,
  Badge as BadgeIcon,
  Verified as VerifiedIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Close as CloseIcon,
  Visibility as VisibilityIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Share as ShareIcon,
  Description as DescriptionIcon,
  Assignment as AssignmentIcon,
  AccountBalance as AccountBalanceIcon,
  Security as SecurityIcon,
  Fingerprint as FingerprintIcon,
  Receipt as ReceiptIcon,
  BusinessCenter as BusinessCenterIcon,
  AttachMoney as MoneyIcon,
  DateRange as DateRangeIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  HourglassEmpty as HourglassIcon,
  PanoramaFishEye as PanoramaFishEyeIcon,
  RadioButtonChecked as RadioButtonCheckedIcon,
  RadioButtonUnchecked as RadioButtonUncheckedIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  TrendingFlat as TrendingFlatIcon,
  Timeline as TimelineIcon,
  History as HistoryIcon,
  Task as TaskIcon,
  TaskAlt as TaskAltIcon,
  Pending as PendingIcon,
  Cancel as CancelIcon,
  Schedule as ScheduleIcon,
  Event as EventIcon,
  Flag as FlagIcon,
  FlagCircle as FlagCircleIcon,
  ThumbUp as ThumbUpIcon,
  Celebration as CelebrationIcon,
  EmojiEvents as EmojiEventsIcon,
  Stars as StarsIcon,
  RocketLaunch as RocketLaunchIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    completed: { bg: '#E8F5E9', color: '#2E7D32' },
    in_progress: { bg: '#E3F2FD', color: '#1976D2' },
    pending: { bg: '#FFF3E0', color: '#E65100' },
    blocked: { bg: '#FFEBEE', color: '#C62828' },
    not_started: { bg: '#F5F5F5', color: '#9E9E9E' },
    verified: { bg: '#E8F5E9', color: '#2E7D32' },
    failed: { bg: '#FFEBEE', color: '#C62828' }
  };
  const color = colors[status] || colors.pending;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const CompletionCard = styled(Card)(({ theme }) => ({
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
  color: 'white',
  '& .MuiCardContent-root': {
    padding: '24px !important'
  }
}));

const StepCard = styled(Card)(({ theme, status }) => {
  const borderColors = {
    completed: '#4CAF50',
    in_progress: '#2196F3',
    pending: '#FF9800',
    blocked: '#F44336',
    not_started: '#9E9E9E'
  };
  
  return {
    borderRadius: 1,
    border: `1px solid ${borderColors[status] || '#E0E0E0'}`,
    borderLeft: `4px solid ${borderColors[status] || '#E0E0E0'}`,
    transition: 'all 0.2s',
    opacity: status === 'completed' ? 1 : 0.8,
    '&:hover': {
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      transform: 'translateY(-2px)'
    }
  };
});

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const MarkComplete = ({ open, onClose, onComplete, candidateId: propCandidateId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    candidateId: propCandidateId || '',
    confirmationChecked: false,
    comments: '',
    notifyCandidate: true,
    sendWelcomeKit: true,
    scheduleOrientation: true
  });

  // Candidates dropdown state
  const [candidates, setCandidates] = useState([]);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState('');
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [candidatePage, setCandidatePage] = useState(1);
  const [candidateTotalPages, setCandidateTotalPages] = useState(1);
  const [candidateInputValue, setCandidateInputValue] = useState('');

  // Onboarding status data
  const [statusData, setStatusData] = useState(null);
  const [statusLoading, setStatusLoading] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [completing, setCompleting] = useState(false);

  // Candidate details
  const [candidateDetails, setCandidateDetails] = useState(null);
  const [candidateDetailsLoading, setCandidateDetailsLoading] = useState(false);

  // Steps for onboarding
  const [onboardingSteps, setOnboardingSteps] = useState([]);
  const [overallProgress, setOverallProgress] = useState(0);
  const [pendingSteps, setPendingSteps] = useState([]);
  const [completedSteps, setCompletedSteps] = useState([]);

  // Eligibility check
  const [isEligible, setIsEligible] = useState(false);
  const [eligibilityChecks, setEligibilityChecks] = useState([]);

  // Steps definition
  const steps = ['Select Candidate', 'Verify Completion', 'Confirm & Complete'];

  // Fetch candidates for dropdown
  const fetchCandidates = async (search = '', page = 1) => {
    setCandidateLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/onboarding`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setCandidates(response.data.data || []);
        } else {
          setCandidates(prev => [...prev, ...(response.data.data || [])]);
        }
        setCandidateTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
    } finally {
      setCandidateLoading(false);
    }
  };

  // Fetch candidate details
  const fetchCandidateDetails = async (candidateId) => {
    if (!candidateId) return;
    
    setCandidateDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setCandidateDetails(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching candidate details:', err);
    } finally {
      setCandidateDetailsLoading(false);
    }
  };

  // Fetch onboarding status
  const fetchOnboardingStatus = async (candidateId) => {
    if (!candidateId) return;
    
    setStatusLoading(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/onboarding/status/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setStatusData(response.data.data);
        
        // Process steps
        if (response.data.data.steps && response.data.data.steps.length > 0) {
          processSteps(response.data.data.steps);
        } else {
          // Default onboarding steps
          const defaultSteps = getDefaultOnboardingSteps();
          setOnboardingSteps(defaultSteps);
          processSteps(defaultSteps);
        }
        
        // Check eligibility
        checkEligibility();
      } else {
        setError(response.data.message || 'Failed to fetch onboarding status');
      }
    } catch (err) {
      console.error('Error fetching onboarding status:', err);
      
      if (err.response && err.response.status === 404) {
        // No status found, use default steps
        const defaultSteps = getDefaultOnboardingSteps();
        setOnboardingSteps(defaultSteps);
        processSteps(defaultSteps);
        checkEligibility();
      } else {
        setError(err.response?.data?.message || 'Failed to fetch onboarding status');
      }
    } finally {
      setStatusLoading(false);
    }
  };

  // Load candidates when dropdown opens
  useEffect(() => {
    if (candidateOpen) {
      fetchCandidates(candidateSearch, 1);
    }
  }, [candidateOpen]);

  // Search candidates with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (candidateOpen) {
        setCandidatePage(1);
        fetchCandidates(candidateSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [candidateSearch, candidateOpen]);

  // Load candidate details and status when selected
  useEffect(() => {
    if (formData.candidateId) {
      fetchCandidateDetails(formData.candidateId);
      fetchOnboardingStatus(formData.candidateId);
    } else {
      setCandidateDetails(null);
      setStatusData(null);
      setOnboardingSteps([]);
      setPendingSteps([]);
      setCompletedSteps([]);
      setIsEligible(false);
    }
  }, [formData.candidateId]);

  // Handle candidate scroll load more
  const handleCandidateScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (candidatePage < candidateTotalPages && !candidateLoading) {
        const nextPage = candidatePage + 1;
        setCandidatePage(nextPage);
        fetchCandidates(candidateSearch, nextPage);
      }
    }
  };

  // Get default onboarding steps
  const getDefaultOnboardingSteps = () => {
    return [
      {
        id: 'offer_acceptance',
        name: 'Offer Acceptance',
        description: 'Candidate has accepted the offer letter',
        status: 'completed',
        required: true,
        icon: <TaskAltIcon />
      },
      {
        id: 'document_collection',
        name: 'Document Collection',
        description: 'Collect and verify all required documents',
        status: 'in_progress',
        required: true,
        icon: <DescriptionIcon />,
        subSteps: [
          { id: 'pan', name: 'PAN Card', status: 'completed', required: true },
          { id: 'aadhar', name: 'Aadhar Card', status: 'completed', required: true },
          { id: 'education', name: 'Educational Certificates', status: 'completed', required: true },
          { id: 'experience', name: 'Experience Letters', status: 'pending', required: true }
        ]
      },
      {
        id: 'background_verification',
        name: 'Background Verification',
        description: 'Complete background and reference checks',
        status: 'pending',
        required: true,
        icon: <SecurityIcon />
      },
      {
        id: 'statutory_details',
        name: 'Statutory Details',
        description: 'Collect PF, ESIC, and bank details',
        status: 'completed',
        required: true,
        icon: <AccountBalanceIcon />
      },
      {
        id: 'employee_creation',
        name: 'Employee Creation',
        description: 'Create employee record in system',
        status: 'completed',
        required: true,
        icon: <PersonIcon />
      },
      {
        id: 'orientation',
        name: 'Orientation & Training',
        description: 'Complete induction and training programs',
        status: 'pending',
        required: false,
        icon: <BusinessCenterIcon />
      }
    ];
  };

  // Process steps from API
  const processSteps = (steps) => {
    setOnboardingSteps(steps);
    
    // Calculate progress
    let completed = 0;
    let total = 0;
    const pending = [];
    const completedList = [];

    const countSteps = (stepList) => {
      stepList.forEach(step => {
        total++;
        if (step.status === 'completed') {
          completed++;
          completedList.push(step);
        } else if (step.status !== 'completed') {
          pending.push(step);
        }
        if (step.subSteps) countSteps(step.subSteps);
      });
    };

    countSteps(steps);
    setOverallProgress(total > 0 ? Math.round((completed / total) * 100) : 0);
    setPendingSteps(pending);
    setCompletedSteps(completedList);
  };

  // Check eligibility for completion
  const checkEligibility = () => {
    const checks = [];
    let eligible = true;

    // Check 1: All required steps completed
    const requiredPending = onboardingSteps.filter(step => 
      step.required && step.status !== 'completed'
    );
    
    if (requiredPending.length > 0) {
      eligible = false;
      checks.push({
        id: 'required_steps',
        status: 'failed',
        message: `${requiredPending.length} required step(s) not completed`,
        details: requiredPending.map(s => s.name).join(', ')
      });
    } else {
      checks.push({
        id: 'required_steps',
        status: 'passed',
        message: 'All required steps completed'
      });
    }

    // Check 2: Document verification
    const docStep = onboardingSteps.find(s => s.id === 'document_collection');
    if (docStep) {
      const pendingDocs = docStep.subSteps?.filter(s => s.required && s.status !== 'completed') || [];
      if (pendingDocs.length > 0) {
        eligible = false;
        checks.push({
          id: 'documents',
          status: 'failed',
          message: `${pendingDocs.length} required document(s) pending`,
          details: pendingDocs.map(d => d.name).join(', ')
        });
      } else {
        checks.push({
          id: 'documents',
          status: 'passed',
          message: 'All required documents verified'
        });
      }
    }

    // Check 3: Background verification
    const bgvStep = onboardingSteps.find(s => s.id === 'background_verification');
    if (bgvStep && bgvStep.required && bgvStep.status !== 'completed') {
      eligible = false;
      checks.push({
        id: 'background_check',
        status: 'failed',
        message: 'Background verification not completed'
      });
    } else if (bgvStep) {
      checks.push({
        id: 'background_check',
        status: 'passed',
        message: 'Background verification completed'
      });
    }

    // Check 4: Statutory details
    const statutoryStep = onboardingSteps.find(s => s.id === 'statutory_details');
    if (statutoryStep && statutoryStep.required && statutoryStep.status !== 'completed') {
      eligible = false;
      checks.push({
        id: 'statutory',
        status: 'failed',
        message: 'Statutory details not completed'
      });
    } else if (statutoryStep) {
      checks.push({
        id: 'statutory',
        status: 'passed',
        message: 'Statutory details completed'
      });
    }

    // Check 5: Employee creation
    const empStep = onboardingSteps.find(s => s.id === 'employee_creation');
    if (empStep && empStep.required && empStep.status !== 'completed') {
      eligible = false;
      checks.push({
        id: 'employee_creation',
        status: 'failed',
        message: 'Employee not created in system'
      });
    } else if (empStep) {
      checks.push({
        id: 'employee_creation',
        status: 'passed',
        message: 'Employee created successfully'
      });
    }

    setEligibilityChecks(checks);
    setIsEligible(eligible);
  };

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'confirmationChecked' ? checked : value
    }));

    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.candidateId) {
        errors.candidateId = 'Please select a candidate';
      }
    } else if (step === 1) {
      if (!isEligible) {
        errors.eligibility = 'Candidate is not eligible for onboarding completion';
      }
    } else if (step === 2) {
      if (!formData.confirmationChecked) {
        errors.confirmationChecked = 'You must confirm to mark onboarding as complete';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleSubmit = async () => {
    if (!validateStep(2)) {
      setError('Please confirm to mark onboarding as complete');
      return;
    }

    setCompleting(true);
    setError('');
    setValidationErrors({});

    try {
      const token = localStorage.getItem('token');

      console.log(`Completing onboarding for candidate: ${formData.candidateId}`);

      const response = await axios.post(
        `${BASE_URL}/api/onboarding/complete/${formData.candidateId}`,
        {}, // Empty body as per API spec
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.success) {
        setSuccess(true);
        
        if (onComplete) {
          onComplete(response.data);
        }
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 4000);
      } else {
        setError(response.data.message || 'Failed to complete onboarding');
      }
    } catch (err) {
      console.error('Error completing onboarding:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to complete onboarding';
        
        // Handle specific error cases
        if (err.response.status === 400) {
          if (err.response.data.errors) {
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setValidationErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 404) {
          setError('Candidate not found or no onboarding data available');
        } else if (err.response.status === 409) {
          setError('Onboarding already completed for this candidate');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setCompleting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      candidateId: propCandidateId || '',
      confirmationChecked: false,
      comments: '',
      notifyCandidate: true,
      sendWelcomeKit: true,
      scheduleOrientation: true
    });
    setCandidateDetails(null);
    setStatusData(null);
    setOnboardingSteps([]);
    setPendingSteps([]);
    setCompletedSteps([]);
    setEligibilityChecks([]);
    setIsEligible(false);
    setOverallProgress(0);
    setError('');
    setValidationErrors({});
    setSuccess(false);
    setActiveStep(0);
    setCandidateSearch('');
    setCandidateInputValue('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select Candidate */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Candidate to Complete Onboarding
              </Typography>

              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12 }}>
                  <Autocomplete
                    size="small"
                    id="candidate-autocomplete"
                    open={candidateOpen}
                    onOpen={() => setCandidateOpen(true)}
                    onClose={() => setCandidateOpen(false)}
                    options={candidates}
                    loading={candidateLoading}
                    value={formData.candidateId ? candidates.find(c => c._id === formData.candidateId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        candidateId: newValue?._id || null 
                      }));
                      if (validationErrors.candidateId) {
                        setValidationErrors(prev => ({ ...prev, candidateId: '' }));
                      }
                    }}
                    inputValue={candidateInputValue}
                    onInputChange={(event, newInputValue) => {
                      setCandidateInputValue(newInputValue);
                      setCandidateSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.name || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Candidate"
                        required
                        error={!!validationErrors.candidateId}
                        helperText={validationErrors.candidateId}
                        size="small"
                        placeholder="Search by name or email"
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {candidateLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.name}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.email} • {option.phone}
                          </Typography>
                          <Box sx={{ mt: 0.5 }}>
                            <StatusChip 
                              label={option.onboardingStatus || 'In Progress'} 
                              size="small"
                              status={option.onboardingStatus || 'in_progress'}
                            />
                          </Box>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleCandidateScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Candidate Quick Info */}
            {candidateDetails && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Candidate Information
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{candidateDetails.name}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                    <Typography variant="body2">{candidateDetails.email}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Position</Typography>
                    <Typography variant="body2">{candidateDetails.position || 'N/A'}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Progress</Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={overallProgress} 
                        sx={{ width: 100, mr: 1, height: 8, borderRadius: 4 }}
                      />
                      <Typography variant="body2">{overallProgress}%</Typography>
                    </Box>
                  </Grid>
                </Grid>
              </Paper>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Loading State */}
            {statusLoading && (
              <Box sx={{ py: 4, textAlign: 'center' }}>
                <CircularProgress size={40} />
              </Box>
            )}

            {/* Eligibility Checks */}
            {!statusLoading && candidateDetails && (
              <>
                {/* Progress Overview */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                    Onboarding Progress Overview
                  </Typography>

                  <Grid container spacing={2}>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <Card sx={{ backgroundColor: '#E8F5E9' }}>
                        <CardContent sx={{ textAlign: 'center' }}>
                          <CheckCircleIcon sx={{ fontSize: 32, color: '#4CAF50', mb: 1 }} />
                          <Typography variant="h5" sx={{ color: '#2E7D32' }}>
                            {completedSteps.length}
                          </Typography>
                          <Typography variant="caption">Completed Steps</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <Card sx={{ backgroundColor: '#FFF3E0' }}>
                        <CardContent sx={{ textAlign: 'center' }}>
                          <HourglassIcon sx={{ fontSize: 32, color: '#FF9800', mb: 1 }} />
                          <Typography variant="h5" sx={{ color: '#E65100' }}>
                            {pendingSteps.length}
                          </Typography>
                          <Typography variant="caption">Pending Steps</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid size={{ xs: 12, md: 4 }}>
                      <Card sx={{ backgroundColor: '#E3F2FD' }}>
                        <CardContent sx={{ textAlign: 'center' }}>
                          <TrendingUpIcon sx={{ fontSize: 32, color: '#2196F3', mb: 1 }} />
                          <Typography variant="h5" sx={{ color: '#1976D2' }}>
                            {overallProgress}%
                          </Typography>
                          <Typography variant="caption">Overall Progress</Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>

                  <LinearProgress 
                    variant="determinate" 
                    value={overallProgress} 
                    sx={{ mt: 2, height: 10, borderRadius: 5 }}
                  />
                </Paper>

                {/* Eligibility Checklist */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                    Completion Eligibility Checklist
                  </Typography>

                  <List dense>
                    {eligibilityChecks.map((check) => (
                      <ListItem key={check.id} sx={{ px: 0 }}>
                        <ListItemIcon sx={{ minWidth: 36 }}>
                          {check.status === 'passed' ? (
                            <CheckCircleIcon sx={{ color: '#4CAF50' }} />
                          ) : (
                            <ErrorIcon sx={{ color: '#F44336' }} />
                          )}
                        </ListItemIcon>
                        <ListItemText 
                          primary={check.message}
                          secondary={check.details}
                        />
                      </ListItem>
                    ))}
                  </List>

                  {isEligible ? (
                    <Alert severity="success" sx={{ mt: 2, borderRadius: 1 }}>
                      <Typography variant="body2">
                        <strong>Eligible for Completion!</strong> All requirements have been met.
                      </Typography>
                    </Alert>
                  ) : (
                    <Alert severity="warning" sx={{ mt: 2, borderRadius: 1 }}>
                      <Typography variant="body2">
                        <strong>Not Eligible</strong> Please complete all pending steps before marking onboarding as complete.
                      </Typography>
                    </Alert>
                  )}
                </Paper>

                {/* Pending Steps */}
                {pendingSteps.length > 0 && (
                  <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                      Pending Steps ({pendingSteps.length})
                    </Typography>

                    <Grid container spacing={1.5}>
                      {pendingSteps.map((step) => (
                        <Grid size={{ xs: 12 }} key={step.id}>
                          <StepCard status={step.status}>
                            <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <Box sx={{ mr: 1, color: getStatusColor(step.status) }}>
                                  {step.icon || <TaskIcon />}
                                </Box>
                                <Box sx={{ flex: 1 }}>
                                  <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                    {step.name}
                                  </Typography>
                                  <Typography variant="caption" color="textSecondary">
                                    {step.description}
                                  </Typography>
                                </Box>
                                <StatusChip 
                                  label={step.status.replace('_', ' ')} 
                                  size="small"
                                  status={step.status}
                                />
                              </Box>

                              {/* Sub-steps */}
                              {step.subSteps && step.subSteps.length > 0 && (
                                <Box sx={{ mt: 1, ml: 4 }}>
                                  {step.subSteps
                                    .filter(s => s.status !== 'completed')
                                    .map((subStep) => (
                                      <Box key={subStep.id} sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                                        <RadioButtonUncheckedIcon sx={{ fontSize: 12, color: '#FF9800', mr: 1 }} />
                                        <Typography variant="caption">{subStep.name}</Typography>
                                        {subStep.required && (
                                          <Chip 
                                            label="Required" 
                                            size="small" 
                                            sx={{ ml: 1, height: 18, fontSize: '0.65rem', backgroundColor: '#FFEBEE', color: '#C62828' }} 
                                          />
                                        )}
                                      </Box>
                                    ))}
                                </Box>
                              )}
                            </CardContent>
                          </StepCard>
                        </Grid>
                      ))}
                    </Grid>
                  </Paper>
                )}

                {/* Validation Error */}
                {validationErrors.eligibility && (
                  <Alert severity="error" sx={{ borderRadius: 1 }}>
                    {validationErrors.eligibility}
                  </Alert>
                )}
              </>
            )}
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Completion Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Completion Summary
              </Typography>

              <Grid container spacing={2}>
                {/* Candidate Info */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Candidate
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {candidateDetails?.name}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {candidateDetails?.email} • {candidateDetails?.phone}
                    </Typography>
                  </Paper>
                </Grid>

                {/* Completion Stats */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Completion Statistics
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid size={{ xs: 4 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Completed</Typography>
                        <Typography variant="body2" sx={{ color: '#4CAF50', fontWeight: 600 }}>
                          {completedSteps.length} steps
                        </Typography>
                      </Grid>
                      <Grid size={{ xs: 4 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Pending</Typography>
                        <Typography variant="body2" sx={{ color: '#FF9800', fontWeight: 600 }}>
                          {pendingSteps.length} steps
                        </Typography>
                      </Grid>
                      <Grid size={{ xs: 4 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Progress</Typography>
                        <Typography variant="body2" sx={{ color: '#1976D2', fontWeight: 600 }}>
                          {overallProgress}%
                        </Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>

                {/* Confirmation Checkbox */}
                <Grid size={{ xs: 12 }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="confirmationChecked"
                        checked={formData.confirmationChecked}
                        onChange={handleChange}
                        color="primary"
                      />
                    }
                    label={
                      <Typography variant="body2">
                        I confirm that all onboarding steps have been completed and verified. 
                        Marking this candidate as onboarded will complete the process and trigger 
                        welcome communications.
                      </Typography>
                    }
                  />
                  {validationErrors.confirmationChecked && (
                    <FormHelperText error>{validationErrors.confirmationChecked}</FormHelperText>
                  )}
                </Grid>

                {/* Additional Options */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1, mt: 1 }}>
                    Additional Actions
                  </Typography>
                  
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="notifyCandidate"
                        checked={formData.notifyCandidate}
                        onChange={handleChange}
                        size="small"
                      />
                    }
                    label="Send welcome email to candidate"
                  />
                  
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="sendWelcomeKit"
                        checked={formData.sendWelcomeKit}
                        onChange={handleChange}
                        size="small"
                      />
                    }
                    label="Send welcome kit (documents, ID card, etc.)"
                  />
                  
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="scheduleOrientation"
                        checked={formData.scheduleOrientation}
                        onChange={handleChange}
                        size="small"
                      />
                    }
                    label="Schedule orientation session"
                  />
                </Grid>

                {/* Comments */}
                <Grid size={{ xs: 12 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Additional Comments (Optional)"
                    name="comments"
                    value={formData.comments}
                    onChange={handleChange}
                    multiline
                    rows={2}
                    placeholder="Any final notes or comments..."
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Success/Error Messages */}
            {!isEligible && (
              <Alert severity="warning" sx={{ borderRadius: 1 }}>
                <Typography variant="body2">
                  <strong>Not Eligible:</strong> Please complete all required steps before marking onboarding as complete.
                </Typography>
              </Alert>
            )}

            {/* Validation Errors */}
            {Object.keys(validationErrors).length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  // Helper function to get status color
  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return '#4CAF50';
      case 'in_progress': return '#2196F3';
      case 'blocked': return '#F44336';
      case 'pending': return '#FF9800';
      default: return '#9E9E9E';
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Complete Onboarding
        </Typography>
        {!completing && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            <Stepper
              activeStep={activeStep}
              alternativeLabel
              connector={<ColorConnector />}
              sx={{ mb: 2, mt: 1 }}
            >
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>
                    <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || completing}
              size="small"
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={completing}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={completing || !formData.candidateId || !isEligible}
                  size="small"
                  startIcon={completing ? <CircularProgress size={16} color="inherit" /> : <CelebrationIcon />}
                  sx={{
                    backgroundColor: '#4CAF50',
                    '&:hover': { backgroundColor: '#388E3C' },
                    '&.Mui-disabled': {
                      backgroundColor: '#BDBDBD'
                    }
                  }}
                >
                  {completing ? 'Completing...' : 'Complete Onboarding'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={completing}
                  size="small"
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <CompletionCard>
              <CardContent>
                <EmojiEventsIcon sx={{ fontSize: 64, color: '#FFD700', mb: 2 }} />
                <Typography variant="h4" sx={{ mb: 2, color: 'white', fontWeight: 600 }}>
                  Onboarding Complete!
                </Typography>
                <Typography variant="body1" sx={{ mb: 3, color: 'rgba(255,255,255,0.9)' }}>
                  Candidate has been successfully onboarded. Welcome to the team!
                </Typography>
                
                <Paper sx={{ p: 2, backgroundColor: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)' }}>
                  <Typography variant="body2" sx={{ color: 'white' }}>
                    <strong>Candidate:</strong> {candidateDetails?.name}
                  </Typography>
                  <Typography variant="body2" sx={{ color: 'white' }}>
                    <strong>Position:</strong> {candidateDetails?.position || 'Employee'}
                  </Typography>
                  <Typography variant="body2" sx={{ color: 'white' }}>
                    <strong>Completed On:</strong> {formatDate(new Date())}
                  </Typography>
                </Paper>
              </CardContent>
            </CompletionCard>

            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, mt: 3 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  resetForm();
                  setSuccess(false);
                }}
                startIcon={<RocketLaunchIcon />}
              >
                Complete Another
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default MarkComplete;