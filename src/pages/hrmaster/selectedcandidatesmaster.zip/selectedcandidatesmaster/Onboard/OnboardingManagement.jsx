import React, { useState } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Button,
  TextField,
  InputAdornment,
  Tooltip,
  Typography,
  TablePagination,
  Checkbox,
  Stack,
  alpha,
  Avatar,
  Chip,
  LinearProgress,
  CircularProgress,
  Grid,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Stepper,
  Step,
  StepLabel
} from '@mui/material';
import {
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Download as DownloadIcon,
  HowToReg as HowToRegIcon,
  Person as PersonIcon,
  Schedule as ScheduleIcon,
  CheckCircle as CheckCircleIcon,
  MoreVert as MoreVertIcon,
  Warning as WarningIcon,
  Timeline as TimelineIcon
} from '@mui/icons-material';
import { PRIMARY_BLUE, TEXT_COLOR_MAIN, SUCCESS_COLOR, WARNING_COLOR, INFO_COLOR } from '../components/utils/constants';
import { formatDate, getAvatarInitials, getAvatarColor } from '../components/utils/helpers';
import StatusChip from '../components/shared/StatusChip';
import StatsCard from '../components/shared/StatsCard';

// Import onboarding modals
import CreateEmployee from './CreateEmployee';
import AddDetails from './AddDetails';
import GetStatus from './GetStatus';
import MarkComplete from './MarkComplete';

const OnboardingManagement = ({ 
  candidates, 
  loading, 
  onRefresh,
  onAction,
  selected,
  onSelect,
  onSelectAll,
  searchTerm,
  onSearchChange,
  page,
  rowsPerPage,
  onPageChange,
  onRowsPerPageChange,
  stats
}) => {
  const [actionMenuAnchor, setActionMenuAnchor] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const handleActionClick = (event, candidate) => {
    setActionMenuAnchor(event.currentTarget);
    setSelectedCandidate(candidate);
  };

  const handleActionClose = () => {
    setActionMenuAnchor(null);
    setSelectedCandidate(null);
  };

  const handleAction = (action) => {
    if (selectedCandidate) {
      onAction(selectedCandidate, action);
    }
    handleActionClose();
  };

  const getOnboardingSteps = (status) => {
    const steps = ['Employee Creation', 'Statutory Details', 'Document Verification', 'Orientation', 'Completion'];
    const activeStep = {
      'not_started': 0,
      'in_progress': 2,
      'completed': 5
    }[status] || 0;
    
    return { steps, activeStep };
  };

  const paginatedCandidates = candidates.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  return (
    <Box>
      {/* Onboarding Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Total Onboarding"
            value={stats.totalOnboarding || 0}
            icon={HowToRegIcon}
            color={PRIMARY_BLUE}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Not Started"
            value={stats.onboardingNotStarted || 0}
            icon={ScheduleIcon}
            color={WARNING_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="In Progress"
            value={stats.onboardingInProgress || 0}
            icon={TimelineIcon}
            color={INFO_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Completed"
            value={stats.onboardingCompleted || 0}
            icon={CheckCircleIcon}
            color={SUCCESS_COLOR}
          />
        </Grid>
      </Grid>

      {/* Action Bar */}
      <Paper sx={{ p: 2, mb: 3, borderRadius: 2, border: '1px solid #e2e8f0' }}>
        <Stack direction="row" spacing={2} alignItems="center" justifyContent="space-between">
          <TextField
            placeholder="Search onboarding..."
            size="small"
            value={searchTerm}
            onChange={onSearchChange}
            sx={{ width: 300 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#64748B' }} />
                </InputAdornment>
              ),
              sx: { height: 40, bgcolor: '#f8fafc' }
            }}
          />
          <Stack direction="row" spacing={1}>
            <Button variant="outlined" startIcon={<DownloadIcon />} sx={{ height: 40, textTransform: 'none' }}>
              Export
            </Button>
            <IconButton onClick={onRefresh} sx={{ height: 40, width: 40, border: '1px solid #cbd5e1' }}>
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Stack>
        </Stack>
      </Paper>

      {/* Onboarding Table */}
      <Paper sx={{ borderRadius: 2, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
        {loading && <LinearProgress sx={{ bgcolor: PRIMARY_BLUE }} />}
        
        <TableContainer>
          <Table stickyHeader>
            <TableHead>
              <TableRow sx={{ bgcolor: '#f8fafc' }}>
                <TableCell padding="checkbox">
                  <Checkbox onChange={onSelectAll} sx={{ color: PRIMARY_BLUE }} />
                </TableCell>
                <TableCell>Candidate</TableCell>
                <TableCell>Employee ID</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Progress</TableCell>
                <TableCell>Joining Date</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 8 }}><CircularProgress /></TableCell></TableRow>
              ) : paginatedCandidates.length === 0 ? (
                <TableRow><TableCell colSpan={7} align="center" sx={{ py: 8 }}>No onboarding records found</TableCell></TableRow>
              ) : (
                paginatedCandidates.map((candidate) => {
                  const { steps, activeStep } = getOnboardingSteps(candidate.onboarding?.status);
                  
                  return (
                    <TableRow key={candidate._id} hover>
                      <TableCell padding="checkbox">
                        <Checkbox checked={selected.includes(candidate._id)} onChange={() => onSelect(candidate._id)} />
                      </TableCell>
                      <TableCell>
                        <Stack direction="row" spacing={2} alignItems="center">
                          <Avatar sx={{ bgcolor: getAvatarColor(candidate.name) }}>
                            {getAvatarInitials(candidate.name)}
                          </Avatar>
                          <Box>
                            <Typography variant="body2" fontWeight={600}>{candidate.name}</Typography>
                            <Typography variant="caption" color="#64748B">{candidate.email}</Typography>
                          </Box>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{candidate.employee?.employeeId || '-'}</Typography>
                      </TableCell>
                      <TableCell>
                        <StatusChip status={candidate.onboarding?.status || 'not_started'} />
                      </TableCell>
                      <TableCell sx={{ maxWidth: 200 }}>
                        <Stepper activeStep={activeStep} alternativeLabel sx={{ mt: 1 }}>
                          {steps.map((label, index) => (
                            <Step key={label}>
                              <StepLabel
                                StepIconProps={{
                                  sx: {
                                    '& .MuiStepIcon-root': {
                                      fontSize: 16,
                                      color: index < activeStep ? SUCCESS_COLOR : 
                                             index === activeStep ? PRIMARY_BLUE : '#e2e8f0'
                                    }
                                  }
                                }}
                              >
                                <Typography variant="caption" sx={{ fontSize: '0.6rem' }}>
                                  {label}
                                </Typography>
                              </StepLabel>
                            </Step>
                          ))}
                        </Stepper>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">{formatDate(candidate.joiningDate)}</Typography>
                      </TableCell>
                      <TableCell>
                        <IconButton onClick={(e) => handleActionClick(e, candidate)}>
                          <MoreVertIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={candidates.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={onPageChange}
          onRowsPerPageChange={onRowsPerPageChange}
        />
      </Paper>

      {/* Action Menu */}
      <Menu anchorEl={actionMenuAnchor} open={Boolean(actionMenuAnchor)} onClose={handleActionClose}>
        <MenuItem onClick={() => handleAction('create_employee')}>
          <ListItemIcon><PersonIcon fontSize="small" /></ListItemIcon>
          <ListItemText>Create Employee</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handleAction('add_statutory')}>
          <ListItemIcon><HowToRegIcon fontSize="small" /></ListItemIcon>
          <ListItemText>Add Statutory Details</ListItemText>
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => handleAction('onboarding_status')}>
          <ListItemIcon><TimelineIcon fontSize="small" /></ListItemIcon>
          <ListItemText>Check Status</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handleAction('complete_onboarding')}>
          <ListItemIcon><CheckCircleIcon fontSize="small" /></ListItemIcon>
          <ListItemText>Mark Complete</ListItemText>
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default OnboardingManagement;