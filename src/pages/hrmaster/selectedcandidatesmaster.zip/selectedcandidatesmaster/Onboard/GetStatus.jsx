import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
  // Progress
  LinearProgress,
  
  // Tabs
  Tab,
  Tabs,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  
} from '@mui/material';

// Import Timeline components from @mui/lab
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineOppositeContent,
} from '@mui/lab';

// Icons
import {
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarIcon,
  Work as WorkIcon,
  Business as BusinessIcon,
  LocationOn as LocationIcon,
  Badge as BadgeIcon,
  Verified as VerifiedIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Close as CloseIcon,
  Visibility as VisibilityIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Share as ShareIcon,
  Description as DescriptionIcon,
  Assignment as AssignmentIcon,
  AccountBalance as AccountBalanceIcon,
  Security as SecurityIcon,
  Fingerprint as FingerprintIcon,
  Receipt as ReceiptIcon,
  BusinessCenter as BusinessCenterIcon,
  AttachMoney as MoneyIcon,
  DateRange as DateRangeIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  HourglassEmpty as HourglassIcon,
  PanoramaFishEye as PanoramaFishEyeIcon,
  RadioButtonChecked as RadioButtonCheckedIcon,
  RadioButtonUnchecked as RadioButtonUncheckedIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  TrendingFlat as TrendingFlatIcon,
  Timeline as TimelineIcon,
  History as HistoryIcon,
  Task as TaskIcon,
  TaskAlt as TaskAltIcon,
  Pending as PendingIcon,
  Cancel as CancelIcon,
  Schedule as ScheduleIcon,
  Event as EventIcon,
  Flag as FlagIcon,
  FlagCircle as FlagCircleIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    completed: { bg: '#E8F5E9', color: '#2E7D32' },
    in_progress: { bg: '#E3F2FD', color: '#1976D2' },
    pending: { bg: '#FFF3E0', color: '#E65100' },
    blocked: { bg: '#FFEBEE', color: '#C62828' },
    not_started: { bg: '#F5F5F5', color: '#9E9E9E' },
    approved: { bg: '#E8F5E9', color: '#2E7D32' },
    rejected: { bg: '#FFEBEE', color: '#C62828' },
    verified: { bg: '#E8F5E9', color: '#2E7D32' },
    failed: { bg: '#FFEBEE', color: '#C62828' }
  };
  const color = colors[status] || colors.pending;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const ProgressCard = styled(Card)(({ theme }) => ({
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const StepCard = styled(Card)(({ theme, status }) => {
  const borderColors = {
    completed: '#4CAF50',
    in_progress: '#2196F3',
    pending: '#FF9800',
    blocked: '#F44336',
    not_started: '#9E9E9E'
  };
  
  return {
    borderRadius: 1,
    border: `1px solid ${borderColors[status] || '#E0E0E0'}`,
    borderLeft: `4px solid ${borderColors[status] || '#E0E0E0'}`,
    transition: 'all 0.2s',
    '&:hover': {
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
    }
  };
});

const GetStatus = ({ open, onClose, candidateId: propCandidateId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState({
    candidateId: propCandidateId || '',
    viewMode: 'detailed' // 'summary', 'detailed', 'timeline'
  });

  // Candidates dropdown state
  const [candidates, setCandidates] = useState([]);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState('');
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [candidatePage, setCandidatePage] = useState(1);
  const [candidateTotalPages, setCandidateTotalPages] = useState(1);
  const [candidateInputValue, setCandidateInputValue] = useState('');

  // Onboarding status data
  const [statusData, setStatusData] = useState(null);
  const [statusLoading, setStatusLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  // Candidate details
  const [candidateDetails, setCandidateDetails] = useState(null);
  const [candidateDetailsLoading, setCandidateDetailsLoading] = useState(false);

  // Steps for onboarding
  const [onboardingSteps, setOnboardingSteps] = useState([]);
  const [overallProgress, setOverallProgress] = useState(0);

  // Timeline events
  const [timelineEvents, setTimelineEvents] = useState([]);

  // Fetch candidates for dropdown
  const fetchCandidates = async (search = '', page = 1) => {
    setCandidateLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setCandidates(response.data.data || []);
        } else {
          setCandidates(prev => [...prev, ...(response.data.data || [])]);
        }
        setCandidateTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
    } finally {
      setCandidateLoading(false);
    }
  };

  // Fetch candidate details
  const fetchCandidateDetails = async (candidateId) => {
    if (!candidateId) return;
    
    setCandidateDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setCandidateDetails(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching candidate details:', err);
    } finally {
      setCandidateDetailsLoading(false);
    }
  };

  // Fetch onboarding status
  const fetchOnboardingStatus = async (candidateId) => {
    if (!candidateId) return;
    
    setStatusLoading(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/onboarding/status/${candidateId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setStatusData(response.data.data);
        
        // Process steps if available
        if (response.data.data.steps && response.data.data.steps.length > 0) {
          processSteps(response.data.data.steps);
          generateTimeline(response.data.data.steps);
          calculateProgress(response.data.data.steps);
        } else {
          // Default onboarding steps if API returns empty
          const defaultSteps = getDefaultOnboardingSteps();
          setOnboardingSteps(defaultSteps);
          generateTimeline(defaultSteps);
          calculateProgress(defaultSteps);
        }
      } else {
        setError(response.data.message || 'Failed to fetch onboarding status');
      }
    } catch (err) {
      console.error('Error fetching onboarding status:', err);
      
      if (err.response) {
        if (err.response.status === 404) {
          setError('No onboarding data found for this candidate');
          // Set default steps for visualization
          const defaultSteps = getDefaultOnboardingSteps();
          setOnboardingSteps(defaultSteps);
          generateTimeline(defaultSteps);
          calculateProgress(defaultSteps);
        } else {
          setError(err.response.data?.message || 'Failed to fetch onboarding status');
        }
      } else {
        setError('Network error. Please check your connection.');
      }
    } finally {
      setStatusLoading(false);
    }
  };

  // Load candidates when dropdown opens
  useEffect(() => {
    if (candidateOpen) {
      fetchCandidates(candidateSearch, 1);
    }
  }, [candidateOpen]);

  // Search candidates with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (candidateOpen) {
        setCandidatePage(1);
        fetchCandidates(candidateSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [candidateSearch, candidateOpen]);

  // Load candidate details and status when selected
  useEffect(() => {
    if (formData.candidateId) {
      fetchCandidateDetails(formData.candidateId);
      fetchOnboardingStatus(formData.candidateId);
    } else {
      setCandidateDetails(null);
      setStatusData(null);
      setOnboardingSteps([]);
      setTimelineEvents([]);
      setOverallProgress(0);
    }
  }, [formData.candidateId]);

  // Handle candidate scroll load more
  const handleCandidateScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (candidatePage < candidateTotalPages && !candidateLoading) {
        const nextPage = candidatePage + 1;
        setCandidatePage(nextPage);
        fetchCandidates(candidateSearch, nextPage);
      }
    }
  };

  // Get default onboarding steps
  const getDefaultOnboardingSteps = () => {
    return [
      {
        id: 'offer_acceptance',
        name: 'Offer Acceptance',
        description: 'Candidate has accepted the offer letter',
        status: candidateDetails?.offerAccepted ? 'completed' : 'pending',
        completedDate: candidateDetails?.offerAcceptedDate,
        dueDate: null,
        owner: 'HR',
        icon: <TaskAltIcon />
      },
      {
        id: 'document_collection',
        name: 'Document Collection',
        description: 'Collect and verify all required documents',
        status: 'in_progress',
        completedDate: null,
        dueDate: '2024-03-01',
        owner: 'HR',
        icon: <DescriptionIcon />,
        subSteps: [
          { id: 'pan', name: 'PAN Card', status: 'completed' },
          { id: 'aadhar', name: 'Aadhar Card', status: 'completed' },
          { id: 'education', name: 'Educational Certificates', status: 'in_progress' },
          { id: 'experience', name: 'Experience Letters', status: 'pending' }
        ]
      },
      {
        id: 'background_verification',
        name: 'Background Verification',
        description: 'Complete background and reference checks',
        status: 'pending',
        completedDate: null,
        dueDate: '2024-03-15',
        owner: 'Vendor',
        icon: <SecurityIcon />
      },
      {
        id: 'statutory_details',
        name: 'Statutory Details',
        description: 'Collect PF, ESIC, and bank details',
        status: 'pending',
        completedDate: null,
        dueDate: '2024-02-28',
        owner: 'Employee',
        icon: <AccountBalanceIcon />
      },
      {
        id: 'employee_creation',
        name: 'Employee Creation',
        description: 'Create employee record in system',
        status: 'pending',
        completedDate: null,
        dueDate: '2024-03-10',
        owner: 'HR',
        icon: <PersonIcon />
      },
      {
        id: 'orientation',
        name: 'Orientation & Training',
        description: 'Complete induction and training programs',
        status: 'pending',
        completedDate: null,
        dueDate: '2024-03-20',
        owner: 'Training',
        icon: <BusinessCenterIcon />
      }
    ];
  };

  // Process steps from API
  const processSteps = (steps) => {
    if (!steps || steps.length === 0) {
      setOnboardingSteps(getDefaultOnboardingSteps());
      return;
    }

    // Map API steps to UI format
    const mappedSteps = steps.map(step => ({
      id: step.id,
      name: step.name,
      description: step.description || '',
      status: step.status || 'pending',
      completedDate: step.completedDate,
      dueDate: step.dueDate,
      owner: step.owner || 'HR',
      icon: getStepIcon(step.id),
      subSteps: step.subSteps || []
    }));

    setOnboardingSteps(mappedSteps);
  };

  // Generate timeline events from steps
  const generateTimeline = (steps) => {
    const events = [];
    
    steps.forEach(step => {
      if (step.completedDate) {
        events.push({
          id: `${step.id}_completed`,
          type: 'step_completed',
          title: `${step.name} Completed`,
          description: step.description,
          date: step.completedDate,
          status: 'completed',
          icon: <CheckCircleIcon />,
          color: '#4CAF50'
        });
      }
      
      if (step.subSteps) {
        step.subSteps.forEach(subStep => {
          if (subStep.completedDate) {
            events.push({
              id: `${subStep.id}_completed`,
              type: 'substep_completed',
              title: `${subStep.name} Completed`,
              description: `Sub-step of ${step.name}`,
              date: subStep.completedDate,
              status: 'completed',
              icon: <TaskAltIcon />,
              color: '#4CAF50'
            });
          }
        });
      }
    });

    // Sort by date (most recent first)
    events.sort((a, b) => new Date(b.date) - new Date(a.date));
    setTimelineEvents(events);
  };

  // Calculate overall progress
  const calculateProgress = (steps) => {
    let completed = 0;
    let total = 0;

    const countSteps = (stepList) => {
      stepList.forEach(step => {
        total++;
        if (step.status === 'completed') completed++;
        if (step.subSteps) countSteps(step.subSteps);
      });
    };

    countSteps(steps);
    setOverallProgress(total > 0 ? Math.round((completed / total) * 100) : 0);
  };

  // Get icon for step
  const getStepIcon = (stepId) => {
    const icons = {
      offer_acceptance: <TaskAltIcon />,
      document_collection: <DescriptionIcon />,
      background_verification: <SecurityIcon />,
      statutory_details: <AccountBalanceIcon />,
      employee_creation: <PersonIcon />,
      orientation: <BusinessCenterIcon />
    };
    return icons[stepId] || <TaskIcon />;
  };

  // Get status icon
  const getStatusIcon = (status) => {
    switch(status) {
      case 'completed':
        return <CheckCircleIcon sx={{ fontSize: 16, color: '#4CAF50' }} />;
      case 'in_progress':
        return <HourglassIcon sx={{ fontSize: 16, color: '#2196F3' }} />;
      case 'blocked':
        return <ErrorIcon sx={{ fontSize: 16, color: '#F44336' }} />;
      case 'pending':
        return <ScheduleIcon sx={{ fontSize: 16, color: '#FF9800' }} />;
      default:
        return <RadioButtonUncheckedIcon sx={{ fontSize: 16, color: '#9E9E9E' }} />;
    }
  };

  // Get status color
  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return '#4CAF50';
      case 'in_progress': return '#2196F3';
      case 'blocked': return '#F44336';
      case 'pending': return '#FF9800';
      default: return '#9E9E9E';
    }
  };

  const handleChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleRefresh = () => {
    if (formData.candidateId) {
      fetchOnboardingStatus(formData.candidateId);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    }
  };

  const resetForm = () => {
    setFormData({
      candidateId: propCandidateId || '',
      viewMode: 'detailed'
    });
    setCandidateDetails(null);
    setStatusData(null);
    setOnboardingSteps([]);
    setTimelineEvents([]);
    setOverallProgress(0);
    setError('');
    setActiveTab(0);
    setCandidateSearch('');
    setCandidateInputValue('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get days remaining until due date
  const getDaysRemaining = (dueDate) => {
    if (!dueDate) return null;
    
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays > 0) {
      return { days: diffDays, status: 'upcoming' };
    } else if (diffDays === 0) {
      return { days: 0, status: 'today' };
    } else {
      return { days: Math.abs(diffDays), status: 'overdue' };
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Onboarding Status
        </Typography>
        <Box>
          <IconButton size="small" onClick={handleRefresh} sx={{ mr: 1, color: '#666' }}>
            <RefreshIcon fontSize="small" />
          </IconButton>
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </Box>
      </DialogTitle>

      <DialogContent sx={{ p: 2, overflow: 'auto' }}>
        <Stack spacing={2}>
          {/* Candidate Selection */}
          <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
            <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
              Select Candidate
            </Typography>

            <Grid container spacing={1.5}>
              <Grid item xs={12}>
                <Autocomplete
                  size="small"
                  id="candidate-autocomplete"
                  open={candidateOpen}
                  onOpen={() => setCandidateOpen(true)}
                  onClose={() => setCandidateOpen(false)}
                  options={candidates}
                  loading={candidateLoading}
                  value={formData.candidateId ? candidates.find(c => c._id === formData.candidateId) || null : null}
                  onChange={(event, newValue) => {
                    handleChange('candidateId', newValue?._id || '');
                  }}
                  inputValue={candidateInputValue}
                  onInputChange={(event, newInputValue) => {
                    setCandidateInputValue(newInputValue);
                    setCandidateSearch(newInputValue);
                  }}
                  getOptionLabel={(option) => option?.name || ''}
                  fullWidth
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Search Candidate"
                      placeholder="Type to search candidates..."
                      size="small"
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {candidateLoading ? <CircularProgress size={16} /> : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                  renderOption={(props, option) => (
                    <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                      <Box>
                        <Typography variant="body2">{option.name}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          {option.email} • {option.phone}
                        </Typography>
                      </Box>
                    </MenuItem>
                  )}
                  ListboxProps={{ onScroll: handleCandidateScroll, style: { maxHeight: 200 } }}
                />
              </Grid>
            </Grid>
          </Paper>

          {/* Loading State */}
          {statusLoading && (
            <Box sx={{ py: 4, textAlign: 'center' }}>
              <CircularProgress size={40} />
              <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                Fetching onboarding status...
              </Typography>
            </Box>
          )}

          {/* Error State */}
          {error && !statusLoading && (
            <Alert severity="error" sx={{ borderRadius: 1 }}>
              {error}
            </Alert>
          )}

          {/* Status Display */}
          {formData.candidateId && !statusLoading && (
            <>
              {/* Candidate Info & Overall Progress */}
              <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Grid container spacing={2} alignItems="center">
                  <Grid item xs={12} md={8}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Avatar sx={{ bgcolor: '#1976D2', width: 56, height: 56, mr: 2 }}>
                        <PersonIcon />
                      </Avatar>
                      <Box>
                        <Typography variant="h6">{candidateDetails?.name || 'Candidate'}</Typography>
                        <Typography variant="body2" color="textSecondary">
                          {candidateDetails?.email} • {candidateDetails?.phone}
                        </Typography>
                        <Box sx={{ display: 'flex', gap: 2, mt: 1 }}>
                          <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center' }}>
                            <WorkIcon sx={{ fontSize: 14, mr: 0.5 }} />
                            {candidateDetails?.position || 'Position not specified'}
                          </Typography>
                          <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center' }}>
                            <BusinessIcon sx={{ fontSize: 14, mr: 0.5 }} />
                            {candidateDetails?.department || 'Department not specified'}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item xs={12} md={4}>
                    <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', textAlign: 'center' }}>
                      <Typography variant="h4" sx={{ color: '#1976D2', fontWeight: 600 }}>
                        {overallProgress}%
                      </Typography>
                      <Typography variant="caption" color="textSecondary">
                        Overall Progress
                      </Typography>
                      <LinearProgress 
                        variant="determinate" 
                        value={overallProgress} 
                        sx={{ mt: 1, height: 8, borderRadius: 4 }}
                      />
                    </Paper>
                  </Grid>
                </Grid>
              </Paper>

              {/* Status Tabs */}
              <Paper sx={{ backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Tabs
                  value={activeTab}
                  onChange={handleTabChange}
                  variant="fullWidth"
                  sx={{
                    borderBottom: '1px solid #E0E0E0',
                    '& .MuiTab-root': {
                      minHeight: 48,
                      fontWeight: 500
                    }
                  }}
                >
                  <Tab label="Overview" icon={<TimelineIcon />} iconPosition="start" />
                  <Tab label="Detailed Steps" icon={<TaskIcon />} iconPosition="start" />
                  <Tab label="Timeline" icon={<HistoryIcon />} iconPosition="start" />
                </Tabs>

                {/* Overview Tab */}
                {activeTab === 0 && (
                  <Box sx={{ p: 2 }}>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                      Current Status: <StatusChip 
                        label={statusData?.status || 'in_progress'} 
                        status={statusData?.status || 'in_progress'}
                        size="small"
                      />
                    </Typography>

                    <Grid container spacing={2}>
                      {/* Quick Stats */}
                      <Grid item xs={12} sm={6} md={3}>
                        <ProgressCard>
                          <CardContent>
                            <Typography variant="caption" color="textSecondary">Steps Completed</Typography>
                            <Typography variant="h5" sx={{ fontWeight: 600, color: '#4CAF50' }}>
                              {onboardingSteps.filter(s => s.status === 'completed').length}
                            </Typography>
                            <Typography variant="caption">out of {onboardingSteps.length}</Typography>
                          </CardContent>
                        </ProgressCard>
                      </Grid>
                      <Grid item xs={12} sm={6} md={3}>
                        <ProgressCard>
                          <CardContent>
                            <Typography variant="caption" color="textSecondary">In Progress</Typography>
                            <Typography variant="h5" sx={{ fontWeight: 600, color: '#2196F3' }}>
                              {onboardingSteps.filter(s => s.status === 'in_progress').length}
                            </Typography>
                          </CardContent>
                        </ProgressCard>
                      </Grid>
                      <Grid item xs={12} sm={6} md={3}>
                        <ProgressCard>
                          <CardContent>
                            <Typography variant="caption" color="textSecondary">Pending</Typography>
                            <Typography variant="h5" sx={{ fontWeight: 600, color: '#FF9800' }}>
                              {onboardingSteps.filter(s => s.status === 'pending').length}
                            </Typography>
                          </CardContent>
                        </ProgressCard>
                      </Grid>
                      <Grid item xs={12} sm={6} md={3}>
                        <ProgressCard>
                          <CardContent>
                            <Typography variant="caption" color="textSecondary">Overdue</Typography>
                            <Typography variant="h5" sx={{ fontWeight: 600, color: '#F44336' }}>
                              {onboardingSteps.filter(s => {
                                if (!s.dueDate || s.status === 'completed') return false;
                                const days = getDaysRemaining(s.dueDate);
                                return days && days.status === 'overdue';
                              }).length}
                            </Typography>
                          </CardContent>
                        </ProgressCard>
                      </Grid>

                      {/* Recent Activity */}
                      <Grid item xs={12}>
                        <Typography variant="subtitle2" sx={{ color: '#1976D2', mt: 2, mb: 1 }}>
                          Recent Activity
                        </Typography>
                        <List dense>
                          {timelineEvents.slice(0, 5).map((event) => (
                            <ListItem key={event.id} sx={{ px: 0 }}>
                              <ListItemIcon sx={{ minWidth: 36 }}>
                                <Avatar sx={{ bgcolor: event.color, width: 24, height: 24 }}>
                                  {event.icon}
                                </Avatar>
                              </ListItemIcon>
                              <ListItemText 
                                primary={event.title}
                                secondary={formatDateTime(event.date)}
                              />
                            </ListItem>
                          ))}
                          {timelineEvents.length === 0 && (
                            <ListItem>
                              <ListItemText primary="No recent activity" />
                            </ListItem>
                          )}
                        </List>
                      </Grid>
                    </Grid>
                  </Box>
                )}

                {/* Detailed Steps Tab */}
                {activeTab === 1 && (
                  <Box sx={{ p: 2 }}>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                      Onboarding Steps
                    </Typography>

                    <Stepper activeStep={onboardingSteps.findIndex(s => s.status === 'in_progress')} connector={<ColorConnector />} orientation="vertical" sx={{ ml: 1 }}>
                      {onboardingSteps.map((step, index) => (
                        <Step key={step.id} active={step.status === 'in_progress'} completed={step.status === 'completed'}>
                          <StepLabel
                            optional={
                              step.dueDate && (
                                <Typography variant="caption" color="textSecondary">
                                  Due: {formatDate(step.dueDate)}
                                  {step.dueDate && (() => {
                                    const days = getDaysRemaining(step.dueDate);
                                    if (days && days.status === 'overdue') {
                                      return <Chip label={`${days.days} days overdue`} size="small" sx={{ ml: 1, backgroundColor: '#FFEBEE', color: '#C62828', height: 20 }} />;
                                    } else if (days && days.status === 'today') {
                                      return <Chip label="Due today" size="small" sx={{ ml: 1, backgroundColor: '#FFF3E0', color: '#E65100', height: 20 }} />;
                                    } else if (days) {
                                      return <Chip label={`${days.days} days left`} size="small" sx={{ ml: 1, backgroundColor: '#E8F5E9', color: '#2E7D32', height: 20 }} />;
                                    }
                                  })()}
                                </Typography>
                              )
                            }
                          >
                            <Box>
                              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                {step.name}
                              </Typography>
                              <Typography variant="caption" color="textSecondary">
                                {step.description}
                              </Typography>
                              {step.owner && (
                                <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 0.5 }}>
                                  Owner: {step.owner}
                                </Typography>
                              )}
                              {step.completedDate && (
                                <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: '#4CAF50' }}>
                                  Completed: {formatDate(step.completedDate)}
                                </Typography>
                              )}
                            </Box>
                          </StepLabel>

                          {/* Sub-steps */}
                          {step.subSteps && step.subSteps.length > 0 && (
                            <Box sx={{ ml: 4, mt: 1, mb: 2 }}>
                              <List dense disablePadding>
                                {step.subSteps.map((subStep) => (
                                  <ListItem key={subStep.id} sx={{ py: 0 }}>
                                    <ListItemIcon sx={{ minWidth: 28 }}>
                                      {subStep.status === 'completed' ? (
                                        <CheckCircleIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                                      ) : subStep.status === 'in_progress' ? (
                                        <HourglassIcon sx={{ fontSize: 16, color: '#2196F3' }} />
                                      ) : (
                                        <RadioButtonUncheckedIcon sx={{ fontSize: 16, color: '#9E9E9E' }} />
                                      )}
                                    </ListItemIcon>
                                    <ListItemText 
                                      primary={subStep.name}
                                      secondary={subStep.completedDate ? formatDate(subStep.completedDate) : null}
                                    />
                                  </ListItem>
                                ))}
                              </List>
                            </Box>
                          )}
                        </Step>
                      ))}
                    </Stepper>
                  </Box>
                )}

                {/* Timeline Tab */}
                {activeTab === 2 && (
                  <Box sx={{ p: 2 }}>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                      Activity Timeline
                    </Typography>

                    {timelineEvents.length === 0 ? (
                      <Alert severity="info" sx={{ borderRadius: 1 }}>
                        No timeline events available
                      </Alert>
                    ) : (
                      <Timeline position="alternate" sx={{ p: 0, m: 0 }}>
                        {timelineEvents.map((event, index) => (
                          <TimelineItem key={event.id}>
                            <TimelineOppositeContent color="textSecondary" sx={{ flex: 0.2 }}>
                              <Typography variant="caption">{formatDateTime(event.date)}</Typography>
                            </TimelineOppositeContent>
                            <TimelineSeparator>
                              <TimelineDot sx={{ backgroundColor: event.color }}>
                                {event.icon}
                              </TimelineDot>
                              {index < timelineEvents.length - 1 && <TimelineConnector />}
                            </TimelineSeparator>
                            <TimelineContent sx={{ py: '12px', px: 2 }}>
                              <Typography variant="subtitle2">{event.title}</Typography>
                              <Typography variant="caption" color="textSecondary">
                                {event.description}
                              </Typography>
                            </TimelineContent>
                          </TimelineItem>
                        ))}
                      </Timeline>
                    )}
                  </Box>
                )}
              </Paper>
            </>
          )}
        </Stack>
      </DialogContent>

      <DialogActions sx={{
        px: 2,
        py: 1.5,
        borderTop: '1px solid #E0E0E0',
        backgroundColor: '#F8FAFC',
        justifyContent: 'flex-end'
      }}>
        <Button
          variant="contained"
          onClick={handleClose}
          size="small"
        >
          Close
        </Button>
      </DialogActions>

      {/* Success Snackbar */}
      <Snackbar
        open={success}
        autoHideDuration={3000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity="success" sx={{ width: '100%' }} onClose={() => setSuccess(false)}>
          Status refreshed successfully
        </Alert>
      </Snackbar>
    </Dialog>
  );
};

export default GetStatus;