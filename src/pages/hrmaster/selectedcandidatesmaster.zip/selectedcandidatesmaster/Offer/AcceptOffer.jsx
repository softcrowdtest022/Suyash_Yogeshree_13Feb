import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Checkbox,
  FormControlLabel,
  RadioGroup,
  Radio,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
 
  // Progress
  LinearProgress,
  
} from '@mui/material';
// Import Timeline components from @mui/lab
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineOppositeContent,
} from '@mui/lab';

import { 
  Close as CloseIcon,
  CheckCircle as CheckCircleIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Visibility as VisibilityIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Share as ShareIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  WhatsApp as WhatsAppIcon,
  LocationOn as LocationIcon,
  CalendarToday as CalendarIcon,
  Work as WorkIcon,
  Person as PersonIcon,
  Business as BusinessIcon,
  AttachMoney as MoneyIcon,
  Description as DescriptionIcon,
  Edit as EditIcon,
  Upload as UploadIcon,
  Draw as DrawIcon,
  Clear as ClearIcon,
  ThumbUp as ThumbUpIcon,
  ThumbDown as ThumbDownIcon,
  Event as EventIcon,
  Verified as VerifiedIcon,
  Gavel as GavelIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    pending: { bg: '#FFF3E0', color: '#E65100' },
    accepted: { bg: '#E8F5E9', color: '#2E7D32' },
    declined: { bg: '#FFEBEE', color: '#C62828' },
    expired: { bg: '#F5F5F5', color: '#9E9E9E' }
  };
  const color = colors[status] || colors.pending;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const InfoCard = styled(Card)(({ theme }) => ({
  backgroundColor: '#F8FAFC',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const SignatureCanvas = ({ onSave, onClear, disabled, value }) => {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [ctx, setCtx] = useState(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      const context = canvas.getContext('2d');
      context.lineWidth = 2;
      context.lineCap = 'round';
      context.strokeStyle = '#000';
      setCtx(context);
    }
  }, []);

  const startDrawing = (e) => {
    if (disabled) return;
    
    setIsDrawing(true);
    const { offsetX, offsetY } = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(offsetX, offsetY);
  };

  const draw = (e) => {
    if (!isDrawing || disabled) return;
    
    e.preventDefault();
    const { offsetX, offsetY } = getCoordinates(e);
    ctx.lineTo(offsetX, offsetY);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    ctx.closePath();
  };

  const getCoordinates = (e) => {
    if (e.touches) {
      // Touch event
      const rect = canvasRef.current.getBoundingClientRect();
      const touch = e.touches[0];
      return {
        offsetX: touch.clientX - rect.left,
        offsetY: touch.clientY - rect.top
      };
    } else {
      // Mouse event
      return {
        offsetX: e.nativeEvent.offsetX,
        offsetY: e.nativeEvent.offsetY
      };
    }
  };

  const handleClear = () => {
    if (disabled) return;
    
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    onClear();
  };

  const handleSave = () => {
    if (disabled) return;
    
    const dataUrl = canvasRef.current.toDataURL('image/png');
    onSave(dataUrl);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box
        sx={{
          border: '1px solid #E0E0E0',
          borderRadius: 1,
          backgroundColor: '#FFFFFF',
          position: 'relative',
          cursor: disabled ? 'not-allowed' : 'crosshair',
          opacity: disabled ? 0.7 : 1
        }}
      >
        <canvas
          ref={canvasRef}
          width={500}
          height={150}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          style={{
            width: '100%',
            height: '150px',
            touchAction: 'none'
          }}
        />
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1, mt: 1 }}>
        <Button
          size="small"
          variant="outlined"
          startIcon={<ClearIcon />}
          onClick={handleClear}
          disabled={disabled}
        >
          Clear
        </Button>
        <Button
          size="small"
          variant="contained"
          startIcon={<CheckCircleIcon />}
          onClick={handleSave}
          disabled={disabled}
        >
          Save Signature
        </Button>
      </Box>
    </Box>
  );
};

const AcceptOffer = ({ open, onClose, onAccept, offerToken: propOfferToken, offerId: propOfferId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    offerToken: propOfferToken || '',
    offerId: propOfferId || '',
    token: propOfferToken || '',
    signature: '',
    signatureType: 'text', // 'text', 'draw', 'upload'
    typedName: '',
    designation: '',
    acceptanceDate: new Date().toISOString().split('T')[0],
    confirmTerms: false,
    confirmAccuracy: false,
    additionalNotes: '',
    joiningConfirmation: true
  });

  // File upload state
  const [signatureFile, setSignatureFile] = useState(null);
  const [signaturePreview, setSignaturePreview] = useState('');

  // Offer data state
  const [offerData, setOfferData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [offerLoading, setOfferLoading] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [retryCount, setRetryCount] = useState(0);

  // Steps definition
  const steps = ['Review Offer', 'Signature', 'Confirm & Accept'];

  // Fetch offer data via token
  const fetchOfferByToken = async (token) => {
    if (!token) return;
    
    setOfferLoading(true);
    setError('');
    
    try {
      const response = await axios.get(`${BASE_URL}/api/offers/view/${token}`, {
        headers: {
          'Accept': 'application/json'
        }
      });

      if (response.data.success) {
        setOfferData(response.data.data);
        
        // Pre-fill typed name with candidate name
        if (response.data.data.candidateName) {
          setFormData(prev => ({
            ...prev,
            typedName: response.data.data.candidateName
          }));
        }
      } else {
        setError(response.data.message || 'Failed to fetch offer details');
      }
    } catch (err) {
      console.error('Error fetching offer by token:', err);
      
      if (err.response) {
        if (err.response.status === 404) {
          setError('Offer not found or invalid link');
        } else if (err.response.status === 410) {
          setError('This offer has expired');
        } else if (err.response.data && err.response.data.message) {
          setError(err.response.data.message);
        } else {
          setError('Failed to load offer. Please try again.');
        }
      } else {
        setError('Network error. Please check your connection.');
      }
    } finally {
      setOfferLoading(false);
    }
  };

  // Fetch offer data by ID (if authenticated)
  const fetchOfferById = async (offerId) => {
    if (!offerId) return;
    
    setOfferLoading(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/${offerId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setOfferData(response.data.data);
        
        // Pre-fill typed name with candidate name
        if (response.data.data.candidateName) {
          setFormData(prev => ({
            ...prev,
            typedName: response.data.data.candidateName
          }));
        }
      } else {
        setError(response.data.message || 'Failed to fetch offer details');
      }
    } catch (err) {
      console.error('Error fetching offer by ID:', err);
      
      if (err.response) {
        if (err.response.status === 404) {
          setError('Offer not found');
        } else if (err.response.status === 403) {
          setError('You do not have permission to view this offer');
        } else if (err.response.data && err.response.data.message) {
          setError(err.response.data.message);
        } else {
          setError('Failed to load offer. Please try again.');
        }
      } else {
        setError('Network error. Please check your connection.');
      }
    } finally {
      setOfferLoading(false);
    }
  };

  // Load offer when token or ID changes
  useEffect(() => {
    if (formData.offerToken) {
      fetchOfferByToken(formData.offerToken);
    } else if (formData.offerId) {
      fetchOfferById(formData.offerId);
    }
  }, [formData.offerToken, formData.offerId]);

  const handleChange = (e) => {
    const { name, value, checked, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear field error when user types
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Check file type
      if (!file.type.match('image.*')) {
        setError('Please upload an image file (PNG, JPG)');
        return;
      }
      
      // Check file size (max 2MB)
      if (file.size > 2 * 1024 * 1024) {
        setError('File size should be less than 2MB');
        return;
      }

      setSignatureFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setSignaturePreview(reader.result);
        setFormData(prev => ({
          ...prev,
          signature: reader.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.confirmTerms) {
        errors.confirmTerms = 'You must accept the terms and conditions';
      }
      if (!formData.confirmAccuracy) {
        errors.confirmAccuracy = 'You must confirm the accuracy of information';
      }
    } else if (step === 1) {
      if (formData.signatureType === 'text' && !formData.typedName.trim()) {
        errors.typedName = 'Please type your full name';
      } else if (formData.signatureType === 'draw' && !formData.signature) {
        errors.signature = 'Please provide your signature';
      } else if (formData.signatureType === 'upload' && !formData.signature) {
        errors.signature = 'Please upload your signature';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors({});
    // Small delay before retrying
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  const handleSubmit = async () => {
    if (!validateStep(1)) {
      setError('Please complete all required fields');
      return;
    }

    setLoading(true);
    setError('');
    setValidationErrors({});

    try {
      const token = localStorage.getItem('token');

      // Prepare signature based on type
      let signature = formData.signature;
      if (formData.signatureType === 'text') {
        signature = formData.typedName;
      }

      // Prepare data according to API expectations
      const submitData = {
        token: formData.offerToken || formData.token,
        signature: signature,
        signatureType: formData.signatureType
      };

      console.log('Submitting offer acceptance:', submitData);

      const endpoint = formData.offerId 
        ? `${BASE_URL}/api/offers/${formData.offerId}/accept`
        : `${BASE_URL}/api/offers/${formData.offerToken}/accept`;

      const response = await axios.post(endpoint, submitData, {
        headers: {
          'Authorization': token ? `Bearer ${token}` : undefined,
          'Content-Type': 'application/json'
        }
      });

      if (response.data.success) {
        setSuccess(true);
        setSuccessMessage('Offer accepted successfully!');
        
        if (onAccept) {
          onAccept(response.data.data);
        }
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to accept offer');
      }
    } catch (err) {
      console.error('Error accepting offer:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to accept offer';
        
        // Handle specific error cases
        if (errorMessage.includes('already accepted')) {
          setError(
            <Box>
              <Typography variant="body2" sx={{ mb: 1 }}>
                This offer has already been accepted.
              </Typography>
              <Button
                size="small"
                variant="outlined"
                startIcon={<VisibilityIcon />}
                onClick={() => {
                  // Navigate to view offer
                  window.location.href = `/offer/view/${formData.offerToken || formData.offerId}`;
                }}
                sx={{ mt: 1 }}
              >
                View Offer
              </Button>
            </Box>
          );
        } else if (errorMessage.includes('expired')) {
          setError(
            <Box>
              <Typography variant="body2" sx={{ mb: 1 }}>
                This offer has expired and cannot be accepted.
              </Typography>
              <Button
                size="small"
                variant="outlined"
                startIcon={<RefreshIcon />}
                onClick={handleRetry}
                sx={{ mt: 1 }}
              >
                Retry
              </Button>
            </Box>
          );
        } else if (err.response.status === 400) {
          if (err.response.data.errors) {
            // Handle field validation errors
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setValidationErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 404) {
          setError('Offer not found. Please check your link.');
        } else if (err.response.status === 410) {
          setError('This offer has expired and cannot be accepted.');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      offerToken: propOfferToken || '',
      offerId: propOfferId || '',
      token: propOfferToken || '',
      signature: '',
      signatureType: 'text',
      typedName: offerData?.candidateName || '',
      designation: '',
      acceptanceDate: new Date().toISOString().split('T')[0],
      confirmTerms: false,
      confirmAccuracy: false,
      additionalNotes: '',
      joiningConfirmation: true
    });
    setSignatureFile(null);
    setSignaturePreview('');
    setError('');
    setValidationErrors({});
    setSuccess(false);
    setActiveStep(0);
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format currency
  const formatCurrency = (value) => {
    if (value === undefined || value === null) return '₹0';
    return `₹${value.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  // Check if offer is expired
  const isOfferExpired = () => {
    if (!offerData?.expiryDate) return false;
    return new Date(offerData.expiryDate) < new Date();
  };

  // Check if offer is already accepted
  const isOfferAccepted = () => {
    return offerData?.status === 'accepted';
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Loading State */}
            {offerLoading && (
              <Box sx={{ py: 4, textAlign: 'center' }}>
                <CircularProgress size={40} />
                <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                  Loading offer details...
                </Typography>
              </Box>
            )}

            {/* Error State */}
            {error && !offerLoading && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                {error}
              </Alert>
            )}

            {/* Offer Details */}
            {offerData && !offerLoading && (
              <>
                {/* Offer Header */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Box>
                      <Typography variant="h6" sx={{ color: '#003366' }}>
                        Offer Letter
                      </Typography>
                      <Typography variant="body2" color="textSecondary">
                        {offerData.offerId}
                      </Typography>
                    </Box>
                    <StatusChip 
                      label={offerData.status?.replace(/_/g, ' ').toUpperCase()}
                      status={offerData.status}
                    />
                  </Box>

                  {isOfferExpired() && (
                    <Alert severity="error" sx={{ mb: 2, borderRadius: 1 }}>
                      This offer expired on {formatDate(offerData.expiryDate)} and cannot be accepted.
                    </Alert>
                  )}

                  {isOfferAccepted() && (
                    <Alert severity="success" sx={{ mb: 2, borderRadius: 1 }}>
                      You have already accepted this offer on {formatDate(offerData.acceptedDate)}.
                    </Alert>
                  )}

                  {!isOfferExpired() && !isOfferAccepted() && (
                    <Alert severity="info" sx={{ mb: 2, borderRadius: 1 }}>
                      Please review the offer details carefully before accepting.
                    </Alert>
                  )}
                </Paper>

                {/* Company Info */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Avatar sx={{ bgcolor: '#1976D2', mr: 2 }}>
                      <BusinessIcon />
                    </Avatar>
                    <Box>
                      <Typography variant="h6">{offerData.companyName || 'Suyash Enterprises'}</Typography>
                      <Typography variant="body2" color="textSecondary">{offerData.companyAddress}</Typography>
                    </Box>
                  </Box>
                </Paper>

                {/* Personal Info */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Typography variant="subtitle1" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                    Dear {offerData.candidateName},
                  </Typography>
                  <Typography variant="body1" paragraph>
                    We are pleased to offer you the position of <strong>{offerData.positionTitle}</strong> at Suyash Enterprises.
                    Please find the details of your offer below.
                  </Typography>
                </Paper>

                {/* Position Details */}
                <InfoCard>
                  <CardContent>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                      Position Details
                    </Typography>
                    <Grid container spacing={1}>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <DetailRow>
                          <DetailIcon><WorkIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Position</Typography>
                            <Typography variant="body2">{offerData.positionTitle}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <DetailRow>
                          <DetailIcon><BusinessIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Department</Typography>
                            <Typography variant="body2">{offerData.department}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <DetailRow>
                          <DetailIcon><LocationIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Location</Typography>
                            <Typography variant="body2">{offerData.location}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <DetailRow>
                          <DetailIcon><CalendarIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Joining Date</Typography>
                            <Typography variant="body2">{formatDate(offerData.joiningDate)}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <DetailRow>
                          <DetailIcon><PersonIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Reporting To</Typography>
                            <Typography variant="body2">{offerData.reportingTo}</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                      <Grid size={{ xs: 12, sm: 6 }}>
                        <DetailRow>
                          <DetailIcon><EventIcon /></DetailIcon>
                          <Box>
                            <Typography variant="caption" color="textSecondary">Probation Period</Typography>
                            <Typography variant="body2">{offerData.probationPeriod} months</Typography>
                          </Box>
                        </DetailRow>
                      </Grid>
                    </Grid>
                  </CardContent>
                </InfoCard>

                {/* CTC Breakdown */}
                <InfoCard>
                  <CardContent>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                      Compensation Details
                    </Typography>
                    
                    <TableContainer component={Paper} sx={{ boxShadow: 'none', border: '1px solid #E0E0E0' }}>
                      <Table size="small">
                        <TableHead>
                          <TableRow sx={{ backgroundColor: '#1976D2' }}>
                            <TableCell sx={{ color: 'white' }}>Component</TableCell>
                            <TableCell align="right" sx={{ color: 'white' }}>Monthly (₹)</TableCell>
                            <TableCell align="right" sx={{ color: 'white' }}>Annual (₹)</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {offerData.ctcBreakdown?.map((item, index) => (
                            <TableRow key={index}>
                              <TableCell>{item.component}</TableCell>
                              <TableCell align="right">{formatCurrency(item.monthly)}</TableCell>
                              <TableCell align="right">{formatCurrency(item.annual)}</TableCell>
                            </TableRow>
                          ))}
                          <TableRow sx={{ backgroundColor: '#E3F2FD' }}>
                            <TableCell><strong>Total CTC</strong></TableCell>
                            <TableCell align="right"></TableCell>
                            <TableCell align="right"><strong>{formatCurrency(offerData.totalCtc)}</strong></TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </CardContent>
                </InfoCard>

                {/* Benefits */}
                {offerData.benefits?.length > 0 && (
                  <InfoCard>
                    <CardContent>
                      <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                        Benefits
                      </Typography>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {offerData.benefits.map((benefit, index) => (
                          <Chip
                            key={index}
                            label={benefit}
                            size="small"
                            sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                          />
                        ))}
                      </Box>
                    </CardContent>
                  </InfoCard>
                )}

                {/* Terms & Conditions */}
                <InfoCard>
                  <CardContent>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                      Terms & Conditions
                    </Typography>
                    <Typography variant="body2" sx={{ whiteSpace: 'pre-line', mb: 2 }}>
                      {offerData.terms || 'Standard terms and conditions apply.'}
                    </Typography>
                    
                    <Divider sx={{ my: 2 }} />
                    
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="confirmTerms"
                          checked={formData.confirmTerms}
                          onChange={handleChange}
                          size="small"
                          disabled={isOfferExpired() || isOfferAccepted()}
                        />
                      }
                      label={
                        <Typography variant="body2">
                          I have read and agree to the terms and conditions *
                        </Typography>
                      }
                    />
                    {validationErrors.confirmTerms && (
                      <FormHelperText error>{validationErrors.confirmTerms}</FormHelperText>
                    )}
                    
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="confirmAccuracy"
                          checked={formData.confirmAccuracy}
                          onChange={handleChange}
                          size="small"
                          disabled={isOfferExpired() || isOfferAccepted()}
                        />
                      }
                      label={
                        <Typography variant="body2">
                          I confirm that all information provided is accurate *
                        </Typography>
                      }
                      sx={{ mt: 1 }}
                    />
                    {validationErrors.confirmAccuracy && (
                      <FormHelperText error>{validationErrors.confirmAccuracy}</FormHelperText>
                    )}
                  </CardContent>
                </InfoCard>

                {/* Additional Notes */}
                <InfoCard>
                  <CardContent>
                    <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2, fontWeight: 600 }}>
                      Additional Information (Optional)
                    </Typography>
                    
                    <TextField
                      fullWidth
                      size="small"
                      name="additionalNotes"
                      value={formData.additionalNotes}
                      onChange={handleChange}
                      multiline
                      rows={3}
                      placeholder="Any additional notes or questions for the HR team..."
                      disabled={isOfferExpired() || isOfferAccepted()}
                      sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                    />
                  </CardContent>
                </InfoCard>

                {/* Joining Confirmation */}
                <InfoCard>
                  <CardContent>
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="joiningConfirmation"
                          checked={formData.joiningConfirmation}
                          onChange={handleChange}
                          size="small"
                          disabled={isOfferExpired() || isOfferAccepted()}
                        />
                      }
                      label={
                        <Typography variant="body2">
                          I confirm that I will join on the specified date ({formatDate(offerData.joiningDate)})
                        </Typography>
                      }
                    />
                  </CardContent>
                </InfoCard>
              </>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Signature */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Signature *
              </Typography>

              <Box sx={{ mb: 2 }}>
                <RadioGroup
                  row
                  name="signatureType"
                  value={formData.signatureType}
                  onChange={handleChange}
                >
                  <FormControlLabel value="text" control={<Radio size="small" />} label="Type Name" />
                  <FormControlLabel value="draw" control={<Radio size="small" />} label="Draw Signature" />
                  <FormControlLabel value="upload" control={<Radio size="small" />} label="Upload Signature" />
                </RadioGroup>
              </Box>

              {formData.signatureType === 'text' && (
                <Grid container spacing={2}>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      size="small"
                      label="Full Name *"
                      name="typedName"
                      value={formData.typedName}
                      onChange={handleChange}
                      error={!!validationErrors.typedName}
                      helperText={validationErrors.typedName}
                      placeholder="Type your full name"
                      sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      size="small"
                      label="Designation (Optional)"
                      name="designation"
                      value={formData.designation}
                      onChange={handleChange}
                      placeholder="Your designation"
                      sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                    />
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" color="textSecondary">
                      By typing your name, you are providing an electronic signature.
                    </Typography>
                  </Grid>
                </Grid>
              )}

              {formData.signatureType === 'draw' && (
                <SignatureCanvas
                  onSave={(signature) => setFormData(prev => ({ ...prev, signature }))}
                  onClear={() => setFormData(prev => ({ ...prev, signature: '' }))}
                  disabled={loading}
                  value={formData.signature}
                />
              )}

              {formData.signatureType === 'upload' && (
                <Box>
                  <input
                    accept="image/*"
                    style={{ display: 'none' }}
                    id="signature-upload"
                    type="file"
                    onChange={handleFileUpload}
                    disabled={loading}
                  />
                  <label htmlFor="signature-upload">
                    <Button
                      variant="outlined"
                      component="span"
                      startIcon={<UploadIcon />}
                      disabled={loading}
                      fullWidth
                      sx={{ height: 100, borderRadius: 1 }}
                    >
                      Click to Upload Signature Image
                    </Button>
                  </label>
                  {signaturePreview && (
                    <Box sx={{ mt: 2, textAlign: 'center' }}>
                      <img 
                        src={signaturePreview} 
                        alt="Signature Preview" 
                        style={{ maxHeight: 100, maxWidth: '100%' }} 
                      />
                      <Button
                        size="small"
                        color="error"
                        onClick={() => {
                          setSignatureFile(null);
                          setSignaturePreview('');
                          setFormData(prev => ({ ...prev, signature: '' }));
                        }}
                        sx={{ mt: 1 }}
                      >
                        Remove
                      </Button>
                    </Box>
                  )}
                </Box>
              )}

              {validationErrors.signature && (
                <FormHelperText error sx={{ mt: 1 }}>
                  {validationErrors.signature}
                </FormHelperText>
              )}
            </Paper>

            {/* Acceptance Date */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Acceptance Date
              </Typography>
              
              <TextField
                fullWidth
                size="small"
                type="date"
                label="Date"
                name="acceptanceDate"
                value={formData.acceptanceDate}
                onChange={handleChange}
                InputLabelProps={{ shrink: true }}
                disabled
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
              />
              <Typography variant="caption" color="textSecondary" sx={{ mt: 1, display: 'block' }}>
                Today's date will be recorded as your acceptance date
              </Typography>
            </Paper>
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Review Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Review Your Acceptance
              </Typography>

              <Grid container spacing={2}>
                {/* Offer Information */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Offer Details
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Offer ID</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>{offerData?.offerId}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Candidate</Typography>
                        <Typography variant="body2">{offerData?.candidateName}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Position</Typography>
                        <Typography variant="body2">{offerData?.positionTitle}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Joining Date</Typography>
                        <Typography variant="body2">{formatDate(offerData?.joiningDate)}</Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>

                {/* Signature */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Signature
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    {formData.signatureType === 'text' && (
                      <Typography variant="body2">
                        {formData.typedName}
                        {formData.designation && `, ${formData.designation}`}
                      </Typography>
                    )}
                    {formData.signatureType === 'draw' && formData.signature && (
                      <Box sx={{ textAlign: 'center' }}>
                        <img 
                          src={formData.signature} 
                          alt="Signature" 
                          style={{ maxHeight: 60, maxWidth: '100%' }} 
                        />
                      </Box>
                    )}
                    {formData.signatureType === 'upload' && formData.signature && (
                      <Box sx={{ textAlign: 'center' }}>
                        <img 
                          src={formData.signature} 
                          alt="Signature" 
                          style={{ maxHeight: 60, maxWidth: '100%' }} 
                        />
                      </Box>
                    )}
                    <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1 }}>
                      Type: {formData.signatureType} • Date: {formatDate(formData.acceptanceDate)}
                    </Typography>
                  </Paper>
                </Grid>

                {/* Confirmation Status */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Confirmations
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                      <CheckCircleIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                      <Typography variant="body2">Terms and conditions accepted</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                      <CheckCircleIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                      <Typography variant="body2">Information accuracy confirmed</Typography>
                    </Box>
                    {formData.joiningConfirmation && (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <CheckCircleIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                        <Typography variant="body2">Joining date confirmed</Typography>
                      </Box>
                    )}
                  </Paper>
                </Grid>

                {/* Additional Notes */}
                {formData.additionalNotes && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Additional Notes
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.additionalNotes}</Typography>
                    </Paper>
                  </Grid>
                )}
              </Grid>
            </Paper>

            {/* Legal Notice */}
            <Alert severity="warning" sx={{ borderRadius: 1 }} icon={<GavelIcon />}>
              <Typography variant="body2">
                <strong>Legal Notice:</strong> By accepting this offer, you enter into a legally binding 
                employment agreement with Suyash Enterprises. Please ensure you have read and understood 
                all terms and conditions.
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {Object.keys(validationErrors).length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Accept Offer
        </Typography>
        {!loading && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            {offerData && !offerLoading && !isOfferExpired() && !isOfferAccepted() && (
              <Stepper
                activeStep={activeStep}
                alternativeLabel
                connector={<ColorConnector />}
                sx={{ mb: 2, mt: 1 }}
              >
                {steps.map((label) => (
                  <Step key={label}>
                    <StepLabel>
                      <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                    </StepLabel>
                  </Step>
                ))}
              </Stepper>
            )}

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || loading || !offerData || isOfferExpired() || isOfferAccepted()}
              size="small"
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={loading}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={loading || !offerData || isOfferExpired() || isOfferAccepted()}
                  size="small"
                  startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <ThumbUpIcon />}
                  sx={{
                    backgroundColor: '#2E7D32',
                    '&:hover': { backgroundColor: '#1B5E20' }
                  }}
                >
                  {loading ? 'Accepting...' : 'Accept Offer'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={loading || !offerData || isOfferExpired() || isOfferAccepted()}
                  size="small"
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <VerifiedIcon sx={{ fontSize: 64, color: '#4CAF50', mb: 2 }} />
            <Typography variant="h5" sx={{ mb: 2, color: '#101010', fontWeight: 600 }}>
              Offer Accepted Successfully!
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              Thank you for accepting the offer. You will receive a confirmation email shortly.
            </Typography>
            
            <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', mb: 3, maxWidth: 400, mx: 'auto' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1 }}>
                Acceptance Summary
              </Typography>
              <Typography variant="body2">
                <strong>Offer ID:</strong> {offerData?.offerId}
              </Typography>
              <Typography variant="body2">
                <strong>Candidate:</strong> {offerData?.candidateName}
              </Typography>
              <Typography variant="body2">
                <strong>Position:</strong> {offerData?.positionTitle}
              </Typography>
              <Typography variant="body2">
                <strong>Joining Date:</strong> {formatDate(offerData?.joiningDate)}
              </Typography>
              <Typography variant="body2">
                <strong>Accepted On:</strong> {formatDate(new Date())}
              </Typography>
            </Paper>

            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  // Download acceptance confirmation
                  window.open(`/api/offers/${offerData?._id}/acceptance-letter`, '_blank');
                }}
                startIcon={<DownloadIcon />}
              >
                Download Confirmation
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default AcceptOffer;