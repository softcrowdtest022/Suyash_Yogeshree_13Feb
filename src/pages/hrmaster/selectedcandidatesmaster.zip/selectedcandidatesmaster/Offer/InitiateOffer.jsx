import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  Box,
  Typography,
  CircularProgress,
  Alert,
  Grid,
  Divider,
  IconButton,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Stack,
  Paper,
  Tooltip,
  Stepper,
  Step,
  StepLabel
} from '@mui/material';
import { alpha } from '@mui/material/styles';
import {
  Close as CloseIcon,
  Calculate as CalculateIcon,
  Info as InfoIcon,
  Save as SaveIcon,
  Send as SendIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  AttachMoney as MoneyIcon,
  Percent as PercentIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

const PRIMARY_BLUE = '#00B4D8';
const SUCCESS_COLOR = '#10B981';
const WARNING_COLOR = '#F59E0B';

const InitiateOffer = ({ open, onClose, onInitiate, candidateId, applicationId }) => {
  const [loading, setLoading] = useState(false);
  const [calculating, setCalculating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [calculatedCTC, setCalculatedCTC] = useState(null);
  const [fetchingAppId, setFetchingAppId] = useState(false);
  
  // Benefits list
  const [newBenefit, setNewBenefit] = useState('');
  const [benefits, setBenefits] = useState([
    'Medical Insurance',
    'Annual Bonus',
    'Leave Travel Allowance'
  ]);

  // Form state
  const [formData, setFormData] = useState({
    candidateId: candidateId || '',
    applicationId: applicationId || '',
    ctcComponents: {
      basic: 15000,
      hraPercent: 40,
      conveyanceAllowance: 1600,
      medicalAllowance: 1250,
      specialAllowance: 0,
      bonusPercent: 8.33,
      employerPfPercent: 12,
      employerEsiPercent: 3.25,
      gratuityPercent: 4.81,
      otherAllowances: 0
    },
    offerDetails: {
      reportingTo: '',
      probationPeriod: 6,
      noticePeriod: 30,
      benefits: benefits
    },
    joiningDate: null
  });

  // Steps for the stepper
  const steps = ['CTC Details', 'Offer Details', 'Review & Initiate'];

  // Update candidateId when prop changes
  useEffect(() => {
    if (candidateId) {
      setFormData(prev => ({
        ...prev,
        candidateId: candidateId
      }));
    }
  }, [candidateId]);

  useEffect(() => {
    if (applicationId) {
      setFormData(prev => ({
        ...prev,
        applicationId: applicationId
      }));
    }
  }, [applicationId]);

  // Auto-calculate CTC when basic salary changes
  useEffect(() => {
    if (formData.ctcComponents.basic > 0) {
      calculateCTC();
    }
  }, [formData.ctcComponents.basic, formData.ctcComponents.hraPercent, 
      formData.ctcComponents.conveyanceAllowance, formData.ctcComponents.medicalAllowance,
      formData.ctcComponents.specialAllowance, formData.ctcComponents.otherAllowances]);

  // Fetch application ID when component opens and candidateId is available
  useEffect(() => {
    if (open && candidateId && !formData.applicationId && !applicationId) {
      fetchApplicationId();
    }
  }, [open, candidateId, formData.applicationId, applicationId]);

  const fetchApplicationId = async () => {
    if (!candidateId) return;
    
    setFetchingAppId(true);
    try {
      const token = localStorage.getItem('token');
      
      // Fetch candidates with status=selected
      const response = await axios.get(`${BASE_URL}/api/candidates`, {
        headers: { 'Authorization': `Bearer ${token}` },
        params: { status: 'selected' }
      });
      
      if (response.data.success && response.data.data) {
        // Find the specific candidate by _id
        const candidate = response.data.data.find(c => c._id === candidateId);
        
        if (candidate && candidate.latestApplication) {
          const appId = candidate.latestApplication._id || candidate.latestApplication.id;
          setFormData(prev => ({
            ...prev,
            applicationId: appId
          }));
          console.log('Application ID fetched:', appId);
        } else {
          setError('No application found for this candidate. Please create an application first.');
        }
      }
    } catch (err) {
      console.error('Error fetching application ID:', err);
      setError('Failed to fetch application details. Please try again.');
    } finally {
      setFetchingAppId(false);
    }
  };

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  // Handle CTC component changes
  const handleCTCChange = (field, value) => {
    // Remove any non-numeric characters except decimal
    const numericValue = value.toString().replace(/[^0-9.]/g, '');
    
    setFormData(prev => ({
      ...prev,
      ctcComponents: {
        ...prev.ctcComponents,
        [field]: numericValue === '' ? 0 : parseFloat(numericValue)
      }
    }));
  };

  // Handle offer details changes
  const handleOfferDetailChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      offerDetails: {
        ...prev.offerDetails,
        [field]: value
      }
    }));
  };

  // Add benefit
  const handleAddBenefit = () => {
    if (newBenefit.trim()) {
      setBenefits([...benefits, newBenefit.trim()]);
      setFormData(prev => ({
        ...prev,
        offerDetails: {
          ...prev.offerDetails,
          benefits: [...benefits, newBenefit.trim()]
        }
      }));
      setNewBenefit('');
    }
  };

  // Remove benefit
  const handleRemoveBenefit = (index) => {
    const updatedBenefits = benefits.filter((_, i) => i !== index);
    setBenefits(updatedBenefits);
    setFormData(prev => ({
      ...prev,
      offerDetails: {
        ...prev.offerDetails,
        benefits: updatedBenefits
      }
    }));
  };

  // Calculate CTC
  const calculateCTC = () => {
    setCalculating(true);
    
    // Parse all values as numbers
    const {
      basic = 0,
      hraPercent = 40,
      conveyanceAllowance = 1600,
      medicalAllowance = 1250,
      specialAllowance = 0,
      bonusPercent = 8.33,
      employerPfPercent = 12,
      employerEsiPercent = 3.25,
      gratuityPercent = 4.81,
      otherAllowances = 0
    } = formData.ctcComponents;

    // Ensure all values are numbers
    const basicNum = Number(basic);
    const hraPercentNum = Number(hraPercent);
    const conveyanceNum = Number(conveyanceAllowance);
    const medicalNum = Number(medicalAllowance);
    const specialNum = Number(specialAllowance);
    const otherNum = Number(otherAllowances);
    const bonusPercentNum = Number(bonusPercent);
    const pfPercentNum = Number(employerPfPercent);
    const esiPercentNum = Number(employerEsiPercent);
    const gratuityPercentNum = Number(gratuityPercent);

    // Calculate components
    const hra = (basicNum * hraPercentNum) / 100;
    const gross = basicNum + hra + conveyanceNum + medicalNum + specialNum + otherNum;
    
    // Annual calculations
    const annualBasic = basicNum * 12;
    const bonus = (annualBasic * bonusPercentNum) / 100;
    const employerPf = (annualBasic * pfPercentNum) / 100;
    // ESI applicable only if monthly gross <= 21000
    const employerEsi = gross > 21000 ? 0 : (annualBasic * esiPercentNum) / 100;
    const gratuity = (annualBasic * gratuityPercentNum) / 100;
    
    const totalCtc = (gross * 12) + bonus + employerPf + employerEsi + gratuity;

    const calculated = {
      basic: basicNum,
      hra,
      conveyanceAllowance: conveyanceNum,
      medicalAllowance: medicalNum,
      specialAllowance: specialNum,
      otherAllowances: otherNum,
      gross,
      bonus,
      employerPf,
      employerEsi,
      gratuity,
      totalCtc,
      monthlyGross: gross,
      annualCtc: totalCtc,
      currency: 'INR'
    };

    setCalculatedCTC(calculated);
    setCalculating(false);
  };

  // Handle next step
  const handleNext = () => {
    if (activeStep === 0) {
      // Validate CTC components
      if (formData.ctcComponents.basic <= 0) {
        setError('Basic salary is required');
        return;
      }
      calculateCTC();
    } else if (activeStep === 1) {
      // Validate offer details
      if (!formData.offerDetails.reportingTo) {
        setError('Reporting To is required');
        return;
      }
      if (!formData.joiningDate) {
        setError('Joining date is required');
        return;
      }
    }
    
    setError('');
    setActiveStep((prev) => prev + 1);
  };

  // Handle back step
  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    setError('');
  };

  // Handle form submit
  const handleSubmit = async () => {
    if (!formData.candidateId) {
      setError('Candidate ID is missing');
      return;
    }

    // Check if applicationId is present
    if (!formData.applicationId) {
      setError('Application ID is required. Please make sure this candidate has an application.');
      return;
    }

    if (!calculatedCTC) {
      calculateCTC();
    }

    try {
      setLoading(true);
      setError('');
      
      const token = localStorage.getItem('token');
      
      // Format joining date properly
      const joiningDateStr = formData.joiningDate ? 
        new Date(formData.joiningDate).toISOString().split('T')[0] : null;

      if (!joiningDateStr) {
        setError('Joining date is required');
        setLoading(false);
        return;
      }

      // Prepare the request body with exact format from API spec
      const requestBody = {
        candidateId: formData.candidateId,
        applicationId: formData.applicationId, // Now this will have the actual application ID
        ctcComponents: {
          basic: Number(formData.ctcComponents.basic),
          hraPercent: Number(formData.ctcComponents.hraPercent),
          conveyanceAllowance: Number(formData.ctcComponents.conveyanceAllowance),
          medicalAllowance: Number(formData.ctcComponents.medicalAllowance),
          specialAllowance: Number(formData.ctcComponents.specialAllowance),
          bonusPercent: Number(formData.ctcComponents.bonusPercent),
          employerPfPercent: Number(formData.ctcComponents.employerPfPercent),
          employerEsiPercent: Number(formData.ctcComponents.employerEsiPercent),
          gratuityPercent: Number(formData.ctcComponents.gratuityPercent)
        },
        offerDetails: {
          reportingTo: formData.offerDetails.reportingTo,
          probationPeriod: parseInt(formData.offerDetails.probationPeriod),
          noticePeriod: parseInt(formData.offerDetails.noticePeriod),
          benefits: formData.offerDetails.benefits
        },
        joiningDate: joiningDateStr
      };

      console.log('Request Payload:', JSON.stringify(requestBody, null, 2));

      const response = await axios.post(
        `${BASE_URL}/api/offers/initiate`,
        requestBody,
        {
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.success) {
        setSuccess(true);
        setCalculatedCTC(response.data.data.ctcDetails);
        setTimeout(() => {
          onInitiate(response.data.data);
          handleClose();
        }, 1500);
      } else {
        setError(response.data.message || 'Failed to initiate offer');
      }
    } catch (err) {
      console.error('Error initiating offer:', err);
      
      if (err.response) {
        console.error('Error Response Data:', err.response.data);
        
        let errorMessage = 'Failed to initiate offer. ';
        
        // Better error message extraction
        if (err.response.data) {
          if (err.response.data.errors) {
            if (Array.isArray(err.response.data.errors)) {
              // Handle array of error objects
              const errorMessages = err.response.data.errors.map(e => 
                e.message || (typeof e === 'string' ? e : JSON.stringify(e))
              );
              errorMessage += errorMessages.join('. ');
            } else if (typeof err.response.data.errors === 'object') {
              // Handle object format errors
              const errorValues = Object.values(err.response.data.errors);
              errorMessage += errorValues.join('. ');
            } else {
              errorMessage += String(err.response.data.errors);
            }
          } else if (err.response.data.message) {
            errorMessage += err.response.data.message;
          } else if (err.response.data.error) {
            errorMessage += err.response.data.error;
          } else {
            // Try to stringify the error object
            try {
              errorMessage += JSON.stringify(err.response.data);
            } catch (e) {
              errorMessage += 'Unknown error occurred';
            }
          }
        } else {
          errorMessage += 'Please check the form data and try again.';
        }
        
        setError(errorMessage);
      } else if (err.request) {
        setError('No response from server. Please check your connection.');
      } else {
        setError('Error: ' + err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    if (!loading) {
      setActiveStep(0);
      setError('');
      setSuccess(false);
      setCalculatedCTC(null);
      setBenefits(['Medical Insurance', 'Annual Bonus', 'Leave Travel Allowance']);
      setFormData({
        candidateId: candidateId || '',
        applicationId: applicationId || '',
        ctcComponents: {
          basic: 0,
          hraPercent: 40,
          conveyanceAllowance: 1600,
          medicalAllowance: 1250,
          specialAllowance: 0,
          bonusPercent: 8.33,
          employerPfPercent: 12,
          employerEsiPercent: 3.25,
          gratuityPercent: 4.81,
          otherAllowances: 0
        },
        offerDetails: {
          reportingTo: '',
          probationPeriod: 6,
          noticePeriod: 30,
          benefits: benefits
        },
        joiningDate: null
      });
      onClose();
    }
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Validate form data before submission
  const validateFormData = () => {
    const errors = [];
    
    if (formData.ctcComponents.basic < 1000) {
      errors.push('Basic salary seems too low');
    }
    
    if (formData.ctcComponents.hraPercent < 0 || formData.ctcComponents.hraPercent > 100) {
      errors.push('HRA percentage must be between 0 and 100');
    }
    
    if (formData.ctcComponents.bonusPercent < 0 || formData.ctcComponents.bonusPercent > 100) {
      errors.push('Bonus percentage must be between 0 and 100');
    }
    
    if (formData.ctcComponents.employerPfPercent < 0 || formData.ctcComponents.employerPfPercent > 100) {
      errors.push('PF percentage must be between 0 and 100');
    }
    
    if (formData.joiningDate && new Date(formData.joiningDate) < new Date()) {
      errors.push('Joining date must be in the future');
    }
    
    return errors;
  };

  // Render CTC step
  const renderCTCStep = () => (
    <Box>
      <Typography variant="subtitle2" color="textSecondary" gutterBottom>
        Enter CTC Components (Monthly)
      </Typography>
      
      <Grid container spacing={2} sx={{ mt: 1 }}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Basic Salary *"
            type="number"
            value={formData.ctcComponents.basic || ''}
            onChange={(e) => handleCTCChange('basic', e.target.value)}
            InputProps={{
              startAdornment: <InputAdornment position="start">₹</InputAdornment>,
              endAdornment: <InputAdornment position="end">/month</InputAdornment>
            }}
            helperText="Monthly basic salary"
            size="small"
          />
        </Grid>
        
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="HRA Percentage"
            type="number"
            value={formData.ctcComponents.hraPercent}
            onChange={(e) => handleCTCChange('hraPercent', e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
            helperText="Percentage of basic"
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Conveyance Allowance"
            type="number"
            value={formData.ctcComponents.conveyanceAllowance}
            onChange={(e) => handleCTCChange('conveyanceAllowance', e.target.value)}
            InputProps={{
              startAdornment: <InputAdornment position="start">₹</InputAdornment>,
              endAdornment: <InputAdornment position="end">/month</InputAdornment>
            }}
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Medical Allowance"
            type="number"
            value={formData.ctcComponents.medicalAllowance}
            onChange={(e) => handleCTCChange('medicalAllowance', e.target.value)}
            InputProps={{
              startAdornment: <InputAdornment position="start">₹</InputAdornment>,
              endAdornment: <InputAdornment position="end">/month</InputAdornment>
            }}
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Special Allowance"
            type="number"
            value={formData.ctcComponents.specialAllowance}
            onChange={(e) => handleCTCChange('specialAllowance', e.target.value)}
            InputProps={{
              startAdornment: <InputAdornment position="start">₹</InputAdornment>,
              endAdornment: <InputAdornment position="end">/month</InputAdornment>
            }}
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Other Allowances"
            type="number"
            value={formData.ctcComponents.otherAllowances}
            onChange={(e) => handleCTCChange('otherAllowances', e.target.value)}
            InputProps={{
              startAdornment: <InputAdornment position="start">₹</InputAdornment>,
              endAdornment: <InputAdornment position="end">/month</InputAdornment>
            }}
            size="small"
          />
        </Grid>

        <Grid item xs={12}>
          <Divider sx={{ my: 2 }} />
          <Typography variant="subtitle2" color="textSecondary" gutterBottom>
            Annual Components
          </Typography>
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="Bonus Percentage"
            type="number"
            value={formData.ctcComponents.bonusPercent}
            onChange={(e) => handleCTCChange('bonusPercent', e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
            helperText="Of annual basic"
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="Employer PF"
            type="number"
            value={formData.ctcComponents.employerPfPercent}
            onChange={(e) => handleCTCChange('employerPfPercent', e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
            helperText="Of annual basic"
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="Employer ESI"
            type="number"
            value={formData.ctcComponents.employerEsiPercent}
            onChange={(e) => handleCTCChange('employerEsiPercent', e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
            helperText="If applicable"
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            label="Gratuity"
            type="number"
            value={formData.ctcComponents.gratuityPercent}
            onChange={(e) => handleCTCChange('gratuityPercent', e.target.value)}
            InputProps={{
              endAdornment: <InputAdornment position="end">%</InputAdornment>
            }}
            helperText="Of annual basic"
            size="small"
          />
        </Grid>
      </Grid>

      {calculatedCTC && (
        <Paper sx={{ p: 2, mt: 3, bgcolor: alpha(PRIMARY_BLUE, 0.04), borderRadius: 2 }}>
          <Typography variant="subtitle2" gutterBottom color={PRIMARY_BLUE}>
            CTC Calculation Preview
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Typography variant="caption" color="textSecondary">Monthly Gross</Typography>
              <Typography variant="body2" fontWeight={600}>
                {formatCurrency(calculatedCTC.monthlyGross)}
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="caption" color="textSecondary">Annual CTC</Typography>
              <Typography variant="body2" fontWeight={600} color={SUCCESS_COLOR}>
                {formatCurrency(calculatedCTC.annualCtc)}
              </Typography>
            </Grid>
          </Grid>
        </Paper>
      )}
    </Box>
  );

  // Render offer details step
  const renderOfferDetailsStep = () => (
    <Box>
      <Typography variant="subtitle2" color="textSecondary" gutterBottom>
        Offer Details
      </Typography>

      {/* Application ID Warning */}
      {!formData.applicationId && !fetchingAppId && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Application ID is required to initiate an offer. 
          {candidateId ? ' Fetching application details...' : ' Please make sure this candidate has an application.'}
        </Alert>
      )}

      {fetchingAppId && (
        <Alert severity="info" sx={{ mb: 2 }} icon={<CircularProgress size={20} />}>
          Fetching application details...
        </Alert>
      )}

      {formData.applicationId && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Application ID: {formData.applicationId}
        </Alert>
      )}

      <Grid container spacing={2} sx={{ mt: 1 }}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Reporting To *"
            name="offerDetails.reportingTo"
            value={formData.offerDetails.reportingTo}
            onChange={handleChange}
            placeholder="e.g., Production Manager"
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="Probation Period"
            type="number"
            name="offerDetails.probationPeriod"
            value={formData.offerDetails.probationPeriod}
            onChange={handleChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">months</InputAdornment>
            }}
            size="small"
          />
        </Grid>

        <Grid item xs={12} md={3}>
          <TextField
            fullWidth
            label="Notice Period"
            type="number"
            name="offerDetails.noticePeriod"
            value={formData.offerDetails.noticePeriod}
            onChange={handleChange}
            InputProps={{
              endAdornment: <InputAdornment position="end">days</InputAdornment>
            }}
            size="small"
          />
        </Grid>

        <Grid item xs={12}>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <DatePicker
              label="Joining Date *"
              value={formData.joiningDate}
              onChange={(newValue) => setFormData(prev => ({ ...prev, joiningDate: newValue }))}
              slotProps={{
                textField: {
                  fullWidth: true,
                  size: "small",
                  helperText: "Expected date of joining",
                  required: true
                }
              }}
              minDate={new Date()}
            />
          </LocalizationProvider>
        </Grid>

        <Grid item xs={12}>
          <Typography variant="subtitle2" color="textSecondary" gutterBottom sx={{ mt: 2 }}>
            Benefits & Perks
          </Typography>
          
          <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
            <TextField
              size="small"
              value={newBenefit}
              onChange={(e) => setNewBenefit(e.target.value)}
              placeholder="Add a benefit"
              sx={{ flex: 1 }}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  handleAddBenefit();
                }
              }}
            />
            <Button
              variant="outlined"
              onClick={handleAddBenefit}
              startIcon={<AddIcon />}
              sx={{ textTransform: 'none' }}
            >
              Add
            </Button>
          </Stack>

          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {benefits.map((benefit, index) => (
              <Chip
                key={index}
                label={benefit}
                onDelete={() => handleRemoveBenefit(index)}
                deleteIcon={<DeleteIcon />}
                sx={{
                  bgcolor: alpha(PRIMARY_BLUE, 0.1),
                  color: PRIMARY_BLUE,
                  '& .MuiChip-deleteIcon': {
                    color: PRIMARY_BLUE,
                    '&:hover': {
                      color: '#ef4444'
                    }
                  }
                }}
              />
            ))}
          </Box>
        </Grid>
      </Grid>
    </Box>
  );

  // Render review step
  const renderReviewStep = () => (
    <Box>
      <Typography variant="subtitle2" color="textSecondary" gutterBottom>
        Review Offer Details
      </Typography>

      <Paper sx={{ p: 2, mt: 2, bgcolor: '#f8fafc', borderRadius: 2 }}>
        <Typography variant="subtitle2" gutterBottom color={PRIMARY_BLUE}>
          CTC Summary
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography variant="caption" color="textSecondary">Monthly Gross</Typography>
            <Typography variant="body2" fontWeight={600}>
              {formatCurrency(calculatedCTC?.monthlyGross || 0)}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="caption" color="textSecondary">Annual CTC</Typography>
            <Typography variant="body2" fontWeight={600} color={SUCCESS_COLOR}>
              {formatCurrency(calculatedCTC?.annualCtc || 0)}
            </Typography>
          </Grid>
        </Grid>

        <Divider sx={{ my: 2 }} />

        <Typography variant="subtitle2" gutterBottom color={PRIMARY_BLUE}>
          Offer Details
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography variant="caption" color="textSecondary">Reporting To</Typography>
            <Typography variant="body2">{formData.offerDetails.reportingTo}</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="caption" color="textSecondary">Joining Date</Typography>
            <Typography variant="body2">
              {formData.joiningDate?.toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
              })}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="caption" color="textSecondary">Probation</Typography>
            <Typography variant="body2">{formData.offerDetails.probationPeriod} months</Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="caption" color="textSecondary">Notice Period</Typography>
            <Typography variant="body2">{formData.offerDetails.noticePeriod} days</Typography>
          </Grid>
        </Grid>

        {formData.applicationId && (
          <>
            <Divider sx={{ my: 2 }} />
            <Typography variant="subtitle2" gutterBottom color={PRIMARY_BLUE}>
              Application Details
            </Typography>
            <Typography variant="body2">Application ID: {formData.applicationId}</Typography>
          </>
        )}

        {benefits.length > 0 && (
          <>
            <Divider sx={{ my: 2 }} />
            <Typography variant="subtitle2" gutterBottom color={PRIMARY_BLUE}>
              Benefits
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {benefits.map((benefit, index) => (
                <Chip
                  key={index}
                  label={benefit}
                  size="small"
                  sx={{ bgcolor: alpha(PRIMARY_BLUE, 0.1), color: PRIMARY_BLUE }}
                />
              ))}
            </Box>
          </>
        )}
      </Paper>

      {/* Debug info - remove in production */}
      {process.env.NODE_ENV === 'development' && (
        <Paper sx={{ p: 2, mt: 2, bgcolor: alpha(WARNING_COLOR, 0.05), borderRadius: 2 }}>
          <Typography variant="caption" color="textSecondary">Debug Info:</Typography>
          <Typography variant="caption" display="block">
            applicationId: {formData.applicationId || '✗ Missing'}
          </Typography>
          <Typography variant="caption" display="block">
            calculatedCTC: {calculatedCTC ? '✓ Set' : '✗ Not set'}
          </Typography>
          <Typography variant="caption" display="block">
            reportingTo: {formData.offerDetails.reportingTo || '✗ Missing'}
          </Typography>
          <Typography variant="caption" display="block">
            joiningDate: {formData.joiningDate ? '✓ Set' : '✗ Missing'}
          </Typography>
        </Paper>
      )}
    </Box>
  );

  return (
    <Dialog 
      open={open} 
      onClose={handleClose} 
      maxWidth="md" 
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
          maxHeight: '90vh'
        }
      }}
    >
      <DialogTitle sx={{ 
        m: 0, 
        p: 2, 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        borderBottom: '1px solid #e2e8f0'
      }}>
        <Box>
          <Typography variant="h6" component="span" fontWeight={600}>
            Initiate Offer
          </Typography>
          {candidateId && (
            <Typography variant="caption" display="block" color="textSecondary">
              Candidate ID: {candidateId}
            </Typography>
          )}
        </Box>
        <IconButton onClick={handleClose} disabled={loading}>
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ p: 3 }}>
        {/* Stepper */}
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {/* Error Alert */}
        {error && (
          <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError('')}>
            {error}
          </Alert>
        )}

        {/* Success Alert */}
        {success && (
          <Alert severity="success" sx={{ mb: 3 }}>
            Offer initiated successfully! Redirecting...
          </Alert>
        )}

        {/* Form Steps */}
        {!success && (
          <Box>
            {activeStep === 0 && renderCTCStep()}
            {activeStep === 1 && renderOfferDetailsStep()}
            {activeStep === 2 && renderReviewStep()}
          </Box>
        )}

        {/* Loading Overlay */}
        {loading && (
          <Box sx={{ 
            position: 'absolute', 
            top: 0, 
            left: 0, 
            right: 0, 
            bottom: 0, 
            bgcolor: 'rgba(255,255,255,0.7)', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            zIndex: 10,
            borderRadius: 2
          }}>
            <CircularProgress />
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{ p: 2, borderTop: '1px solid #e2e8f0' }}>
        <Button 
          onClick={handleClose}
          disabled={loading}
          sx={{ textTransform: 'none' }}
        >
          Cancel
        </Button>
        
        {activeStep > 0 && (
          <Button
            onClick={handleBack}
            disabled={loading}
            sx={{ textTransform: 'none' }}
          >
            Back
          </Button>
        )}
        
        {activeStep < steps.length - 1 ? (
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={loading || calculating || fetchingAppId}
            sx={{
              bgcolor: PRIMARY_BLUE,
              '&:hover': { bgcolor: '#0e7490' },
              textTransform: 'none'
            }}
          >
            {calculating ? <CircularProgress size={24} /> : 'Next'}
          </Button>
        ) : (
          <Button
            variant="contained"
            onClick={handleSubmit}
            disabled={loading || !calculatedCTC || !formData.offerDetails.reportingTo || !formData.joiningDate || !formData.applicationId}
            startIcon={loading ? <CircularProgress size={20} /> : <SendIcon />}
            sx={{
              bgcolor: SUCCESS_COLOR,
              '&:hover': { bgcolor: '#059669' },
              textTransform: 'none'
            }}
          >
            {loading ? 'Initiating...' : 'Initiate Offer'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default InitiateOffer;