import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Snackbar,
  Alert,
  CircularProgress,
} from "@mui/material";
import axios from "axios";
import BASE_URL from "../../../../config/Config";


export default function SendOffer({ open, onClose, candidateId }) {
  const [loading, setLoading] = useState(false);
  const [snack, setSnack] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const handleSend = async () => {
    try {
      setLoading(true);

      // 🔹 Step 1: fetch offers for candidate
      const offersRes = await axios.get(
        `${BASE_URL}/api/offers?candidateId=${candidateId}`
      );

      const offers = offersRes.data.data || [];

      // 🔹 Step 2: find latest approved offer
      const approvedOffer = offers
        .filter((o) => o.status === "approved")
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];

      if (!approvedOffer) {
        throw new Error("No approved offer found for this candidate");
      }

      const offerId = approvedOffer._id;

      // 🔹 Step 3: send offer
      const res = await axios.post(
        `${BASE_URL}/api/offers/${offerId}/send`
      );

      setSnack({
        open: true,
        message: res.data.message || "Offer sent successfully",
        severity: "success",
      });

      onClose(true);
    } catch (err) {
      setSnack({
        open: true,
        message: err?.response?.data?.message || err.message,
        severity: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Dialog open={open} onClose={() => onClose(false)}>
        <DialogTitle>Send Offer to Candidate</DialogTitle>

        <DialogContent>
          <Typography>
            This will send the latest approved offer to the candidate via email.
          </Typography>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => onClose(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleSend}
            disabled={loading}
            startIcon={loading && <CircularProgress size={18} />}
          >
            Send Offer
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snack.open}
        autoHideDuration={4000}
        onClose={() => setSnack({ ...snack, open: false })}
      >
        <Alert severity={snack.severity}>{snack.message}</Alert>
      </Snackbar>
    </>
  );
}