import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Snackbar,
  Alert,
  CircularProgress,
} from "@mui/material";
import axios from "axios";
import BASE_URL from "../../../../config/Config";


export default function GenerateOfferLetter({ open, onClose, candidateId }) {
  const [loading, setLoading] = useState(false);
  const [snack, setSnack] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const handleGenerate = async () => {
    try {
      setLoading(true);

      // 🔹 Step 1: Get offers of candidate
      const offersRes = await axios.get(
        `${BASE_URL}/api/offers?candidateId=${candidateId}`
      );

      const offers = offersRes.data.data || [];

      // 🔹 Step 2: find latest approved offer
      const approvedOffer = offers
        .filter((o) => o.status === "approved")
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];

      if (!approvedOffer) {
        throw new Error("No approved offer found for this candidate");
      }

      const offerId = approvedOffer._id;

      // 🔹 Step 3: call generate letter API
      const res = await axios.get(
        `${BASE_URL}/api/offers/${offerId}/generate-letter`,
        { responseType: "text" } // important for HTML
      );

      const htmlContent = res.data;

      // 🔹 Step 4: open in new tab
      const newWindow = window.open("", "_blank");
      newWindow.document.write(htmlContent);
      newWindow.document.close();

      setSnack({
        open: true,
        message: "Offer letter generated successfully",
        severity: "success",
      });

      onClose(false);
    } catch (err) {
      setSnack({
        open: true,
        message: err?.response?.data?.message || err.message,
        severity: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Dialog open={open} onClose={() => onClose(false)}>
        <DialogTitle>Generate Offer Letter</DialogTitle>

        <DialogContent>
          <Typography>
            This will generate the offer letter for the latest approved offer.
          </Typography>
        </DialogContent>

        <DialogActions>
          <Button onClick={() => onClose(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleGenerate}
            disabled={loading}
            startIcon={loading && <CircularProgress size={18} />}
          >
            Generate
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snack.open}
        autoHideDuration={4000}
        onClose={() => setSnack({ ...snack, open: false })}
      >
        <Alert severity={snack.severity}>{snack.message}</Alert>
      </Snackbar>
    </>
  );
}