import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
} from '@mui/material';
// Import Timeline components from @mui/lab
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineOppositeContent,
} from '@mui/lab';

import { 
  Close as CloseIcon,
  Send as SendIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Visibility as VisibilityIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  WhatsApp as WhatsAppIcon,
  ContentCopy as CopyIcon,
  OpenInNew as OpenInNewIcon,
  History as HistoryIcon,
  Schedule as ScheduleIcon,
  CheckCircleOutline as CheckCircleOutlineIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    sent: { bg: '#E8F5E9', color: '#2E7D32' },
    pending: { bg: '#FFF3E0', color: '#E65100' },
    viewed: { bg: '#E3F2FD', color: '#1976D2' },
    accepted: { bg: '#E8F5E9', color: '#2E7D32' },
    rejected: { bg: '#FFEBEE', color: '#C62828' },
    failed: { bg: '#FFEBEE', color: '#C62828' }
  };
  const color = colors[status] || colors.pending;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const NotificationMethodCard = styled(Card)(({ theme, selected }) => ({
  cursor: 'pointer',
  border: selected ? '2px solid #1976D2' : '1px solid #E0E0E0',
  borderRadius: 1,
  transition: 'all 0.2s',
  '&:hover': {
    borderColor: '#1976D2',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  }
}));

const SendToCandidate = ({ open, onClose, onSend, offerId: propOfferId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    offerId: propOfferId || '',
    notificationMethods: ['email'], // 'email', 'sms', 'whatsapp'
    additionalMessage: '',
    sendCopy: true,
    ccEmails: [],
    scheduleLater: false,
    scheduledDate: '',
    scheduledTime: ''
  });

  // Dropdown states
  const [offers, setOffers] = useState([]);
  const [offerLoading, setOfferLoading] = useState(false);
  const [offerSearch, setOfferSearch] = useState('');
  const [offerOpen, setOfferOpen] = useState(false);
  const [offerPage, setOfferPage] = useState(1);
  const [offerTotalPages, setOfferTotalPages] = useState(1);
  const [offerInputValue, setOfferInputValue] = useState('');

  // CC Email state
  const [ccInput, setCcInput] = useState('');
  const [ccOpen, setCcOpen] = useState(false);

  // Offer details state
  const [offerDetails, setOfferDetails] = useState(null);
  const [offerDetailsLoading, setOfferDetailsLoading] = useState(false);
  
  // Notification history
  const [notificationHistory, setNotificationHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  
  // Send status
  const [sending, setSending] = useState(false);
  const [sendResult, setSendResult] = useState(null);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState([]);
  const [success, setSuccess] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // Steps definition
  const steps = ['Select Offer', 'Configure Notification', 'Review & Send'];

  // Notification methods
  const notificationMethods = [
    { id: 'email', label: 'Email', icon: <EmailIcon />, description: 'Send offer via email with secure link' },
    { id: 'sms', label: 'SMS', icon: <PhoneIcon />, description: 'Send SMS with offer link' },
    { id: 'whatsapp', label: 'WhatsApp', icon: <WhatsAppIcon />, description: 'Send WhatsApp message with offer link' }
  ];

  // Fetch eligible offers for sending
  const fetchOffers = async (search = '', page = 1) => {
    setOfferLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/ready-to-send`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search,
          status: 'approved' // Only approved offers can be sent to candidates
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setOffers(response.data.data || []);
        } else {
          setOffers(prev => [...prev, ...(response.data.data || [])]);
        }
        setOfferTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching offers:', err);
    } finally {
      setOfferLoading(false);
    }
  };

  // Fetch offer details
  const fetchOfferDetails = async (offerId) => {
    if (!offerId) return;
    
    setOfferDetailsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/${offerId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setOfferDetails(response.data.data);
        
        // Auto-populate CC with HR email if available
        const hrEmail = localStorage.getItem('userEmail');
        if (hrEmail && formData.sendCopy) {
          setFormData(prev => ({
            ...prev,
            ccEmails: [hrEmail]
          }));
        }
      }
    } catch (err) {
      console.error('Error fetching offer details:', err);
    } finally {
      setOfferDetailsLoading(false);
    }
  };

  // Fetch notification history
  const fetchNotificationHistory = async (offerId) => {
    if (!offerId) return;
    
    setHistoryLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/offers/${offerId}/notifications`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setNotificationHistory(response.data.data || []);
      }
    } catch (err) {
      console.error('Error fetching notification history:', err);
    } finally {
      setHistoryLoading(false);
    }
  };

  // Load offers when dropdown opens
  useEffect(() => {
    if (offerOpen) {
      fetchOffers(offerSearch, 1);
    }
  }, [offerOpen]);

  // Search offers with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (offerOpen) {
        setOfferPage(1);
        fetchOffers(offerSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [offerSearch, offerOpen]);

  // Load offer details when offer is selected
  useEffect(() => {
    if (formData.offerId) {
      fetchOfferDetails(formData.offerId);
      fetchNotificationHistory(formData.offerId);
    } else {
      setOfferDetails(null);
      setNotificationHistory([]);
      setSendResult(null);
    }
  }, [formData.offerId]);

  // Handle offer scroll load more
  const handleOfferScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (offerPage < offerTotalPages && !offerLoading) {
        const nextPage = offerPage + 1;
        setOfferPage(nextPage);
        fetchOffers(offerSearch, nextPage);
      }
    }
  };

  const handleChange = (e) => {
    const { name, value, checked, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleMethodToggle = (methodId) => {
    setFormData(prev => {
      const methods = prev.notificationMethods.includes(methodId)
        ? prev.notificationMethods.filter(m => m !== methodId)
        : [...prev.notificationMethods, methodId];
      return { ...prev, notificationMethods: methods };
    });
  };

  const handleAddCc = () => {
    if (ccInput.trim() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ccInput.trim())) {
      if (!formData.ccEmails.includes(ccInput.trim())) {
        setFormData(prev => ({
          ...prev,
          ccEmails: [...prev.ccEmails, ccInput.trim()]
        }));
      }
      setCcInput('');
    }
  };

  const handleRemoveCc = (email) => {
    setFormData(prev => ({
      ...prev,
      ccEmails: prev.ccEmails.filter(e => e !== email)
    }));
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && ccInput.trim()) {
      e.preventDefault();
      handleAddCc();
    }
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.offerId) {
        errors.offerId = 'Please select an offer to send';
      }
    } else if (step === 1) {
      if (formData.notificationMethods.length === 0) {
        errors.notificationMethods = 'Select at least one notification method';
      }
      
      if (formData.scheduleLater) {
        if (!formData.scheduledDate) {
          errors.scheduledDate = 'Please select a date';
        }
        if (!formData.scheduledTime) {
          errors.scheduledTime = 'Please select a time';
        }
        
        // Validate scheduled datetime is in future
        if (formData.scheduledDate && formData.scheduledTime) {
          const scheduled = new Date(`${formData.scheduledDate}T${formData.scheduledTime}`);
          if (scheduled <= new Date()) {
            errors.scheduledTime = 'Scheduled time must be in the future';
          }
        }
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors([]);
    // Small delay before retrying
    setTimeout(() => {
      handleSend();
    }, 500);
  };

  const handleSend = async () => {
    if (!validateStep(1)) {
      setError('Please complete all required fields');
      return;
    }

    setSending(true);
    setError('');
    setSendResult(null);

    try {
      const token = localStorage.getItem('token');

      console.log(`Sending offer ${formData.offerId} to candidate`);

      // Prepare notification preferences
      const notificationPrefs = {
        methods: formData.notificationMethods,
        additionalMessage: formData.additionalMessage,
        ccEmails: formData.sendCopy ? formData.ccEmails : [],
        schedule: formData.scheduleLater ? {
          date: formData.scheduledDate,
          time: formData.scheduledTime
        } : null
      };

      // Add notification preferences as query params or headers if needed
      // API spec says body is none, so we'll just make the POST request

      const response = await axios.post(
        `${BASE_URL}/api/offers/${formData.offerId}/send`,
        {}, // Empty body as per API spec
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'X-Notification-Prefs': JSON.stringify(notificationPrefs) // Custom header for preferences
          }
        }
      );

      if (response.data.success) {
        setSendResult(response.data);
        setSuccess(true);
        
        // Refresh notification history
        fetchNotificationHistory(formData.offerId);
        
        // Callback
        if (onSend) {
          onSend(response.data);
        }
        
        // Auto close after success if not showing warning
        if (!response.data.warning) {
          setTimeout(() => {
            resetForm();
            onClose();
          }, 3000);
        }
      } else {
        setError(response.data.message || 'Failed to send offer to candidate');
      }
    } catch (err) {
      console.error('Error sending offer:', err);
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to send offer';
        
        // Handle specific error cases
        if (errorMessage.includes('already sent')) {
          setError(
            <Box>
              <Typography variant="body2" sx={{ mb: 1 }}>
                This offer has already been sent to the candidate.
              </Typography>
              <Button
                size="small"
                variant="outlined"
                startIcon={<VisibilityIcon />}
                onClick={() => {
                  // Show history or resend option
                  setActiveStep(2); // Go to review step to see history
                }}
                sx={{ mt: 1, mr: 1 }}
              >
                View History
              </Button>
              <Button
                size="small"
                variant="outlined"
                startIcon={<RefreshIcon />}
                onClick={handleRetry}
                sx={{ mt: 1 }}
              >
                Resend
              </Button>
            </Box>
          );
        } else if (err.response.status === 400) {
          setError('Invalid request. Please check the offer status.');
        } else if (err.response.status === 404) {
          setError('Offer not found. Please select a valid offer.');
        } else if (err.response.data.errors) {
          setValidationErrors(err.response.data.errors);
          setError('Please fix the validation errors and try again');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Failed to send offer. Please check your network connection.');
      }
    } finally {
      setSending(false);
    }
  };

  const resetForm = () => {
    setFormData({
      offerId: propOfferId || '',
      notificationMethods: ['email'],
      additionalMessage: '',
      sendCopy: true,
      ccEmails: [],
      scheduleLater: false,
      scheduledDate: '',
      scheduledTime: ''
    });
    setCcInput('');
    setError('');
    setValidationErrors([]);
    setSendResult(null);
    setSuccess(false);
    setOfferDetails(null);
    setNotificationHistory([]);
    setActiveStep(0);
    setOfferSearch('');
    setOfferInputValue('');
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select Offer */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Offer to Send
              </Typography>

              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12 }}>
                  <Autocomplete
                    size="small"
                    id="offer-autocomplete"
                    open={offerOpen}
                    onOpen={() => setOfferOpen(true)}
                    onClose={() => setOfferOpen(false)}
                    options={offers}
                    loading={offerLoading}
                    value={formData.offerId ? offers.find(o => o._id === formData.offerId) || 
                          (offerDetails ? { 
                            _id: offerDetails._id, 
                            offerId: offerDetails.offerId, 
                            candidateName: offerDetails.candidateName,
                            positionTitle: offerDetails.positionTitle,
                            status: offerDetails.status
                          } : null) : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        offerId: newValue?._id || null 
                      }));
                    }}
                    inputValue={offerInputValue}
                    onInputChange={(event, newInputValue) => {
                      setOfferInputValue(newInputValue);
                      setOfferSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.offerId || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Offer"
                        required
                        error={!!validationErrors.offerId}
                        helperText={validationErrors.offerId}
                        size="small"
                        placeholder="Search by Offer ID or Candidate Name"
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            borderRadius: 1
                          }
                        }}
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {offerLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.offerId}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.candidateName} • {option.positionTitle}
                          </Typography>
                          <Box sx={{ mt: 0.5 }}>
                            <StatusChip 
                              label={option.status} 
                              size="small"
                              status={option.status}
                            />
                          </Box>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleOfferScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Offer Summary */}
            {offerDetailsLoading && (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}>
                <CircularProgress size={24} />
              </Box>
            )}

            {offerDetails && !offerDetailsLoading && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Offer Summary
                </Typography>

                <Grid container spacing={1.5}>
                  <Grid size={{ xs: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Offer ID</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{offerDetails.offerId}</Typography>
                  </Grid>
                  <Grid size={{ xs: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Status</Typography>
                    <StatusChip 
                      label={offerDetails.status} 
                      size="small"
                      status={offerDetails.status}
                    />
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Candidate</Typography>
                    <Typography variant="body2">{offerDetails.candidateName}</Typography>
                  </Grid>
                  <Grid size={{ xs: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                    <Typography variant="body2">{offerDetails.candidateEmail || 'N/A'}</Typography>
                  </Grid>
                  <Grid size={{ xs: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Phone</Typography>
                    <Typography variant="body2">{offerDetails.candidatePhone || 'N/A'}</Typography>
                  </Grid>
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Position</Typography>
                    <Typography variant="body2">{offerDetails.positionTitle}</Typography>
                  </Grid>
                </Grid>
              </Paper>
            )}

            {/* Notification History */}
            {notificationHistory.length > 0 && (
              <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Previous Notifications
                </Typography>
                
                <Timeline sx={{ p: 0, m: 0 }}>
                  {notificationHistory.map((item, index) => (
                    <TimelineItem key={index}>
                      <TimelineSeparator>
                        <TimelineDot sx={{ 
                          backgroundColor: 
                            item.status === 'sent' ? '#E8F5E9' : 
                            item.status === 'viewed' ? '#E3F2FD' : '#FFEBEE',
                          color: 
                            item.status === 'sent' ? '#2E7D32' : 
                            item.status === 'viewed' ? '#1976D2' : '#C62828'
                        }}>
                          {item.method === 'email' ? <EmailIcon fontSize="small" /> :
                           item.method === 'sms' ? <PhoneIcon fontSize="small" /> :
                           <WhatsAppIcon fontSize="small" />}
                        </TimelineDot>
                        {index < notificationHistory.length - 1 && <TimelineConnector />}
                      </TimelineSeparator>
                      <TimelineContent sx={{ py: '12px', px: 2 }}>
                        <Typography variant="body2">{item.method.toUpperCase()}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          {formatDate(item.sentAt)}
                        </Typography>
                        {item.viewedAt && (
                          <Typography variant="caption" sx={{ display: 'block', color: '#1976D2' }}>
                            Viewed: {formatDate(item.viewedAt)}
                          </Typography>
                        )}
                      </TimelineContent>
                    </TimelineItem>
                  ))}
                </Timeline>
              </Paper>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Notification Methods */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Notification Methods *
              </Typography>

              <Grid container spacing={1.5}>
                {notificationMethods.map(method => (
                  <Grid size={{ xs: 12, sm: 4 }} key={method.id}>
                    <NotificationMethodCard 
                      selected={formData.notificationMethods.includes(method.id)}
                      onClick={() => handleMethodToggle(method.id)}
                    >
                      <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <Box sx={{ color: formData.notificationMethods.includes(method.id) ? '#1976D2' : '#666', mr: 1 }}>
                            {method.icon}
                          </Box>
                          <Typography variant="subtitle2">{method.label}</Typography>
                          {formData.notificationMethods.includes(method.id) && (
                            <CheckCircleIcon sx={{ ml: 'auto', fontSize: 16, color: '#1976D2' }} />
                          )}
                        </Box>
                        <Typography variant="caption" color="textSecondary">
                          {method.description}
                        </Typography>
                      </CardContent>
                    </NotificationMethodCard>
                  </Grid>
                ))}
              </Grid>

              {validationErrors.notificationMethods && (
                <FormHelperText error sx={{ mt: 1 }}>
                  {validationErrors.notificationMethods}
                </FormHelperText>
              )}
            </Paper>

            {/* Additional Message */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Additional Message (Optional)
              </Typography>

              <TextField
                fullWidth
                size="small"
                name="additionalMessage"
                value={formData.additionalMessage}
                onChange={handleChange}
                multiline
                rows={3}
                placeholder="Add a personal message to the candidate..."
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
              />
            </Paper>

            {/* CC Options */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="sendCopy"
                    checked={formData.sendCopy}
                    onChange={handleChange}
                    size="small"
                  />
                }
                label="Send a copy to myself/HR"
              />

              {formData.sendCopy && (
                <Box sx={{ mt: 2 }}>
                  <Typography variant="caption" sx={{ color: '#666', mb: 1, display: 'block' }}>
                    CC Email Addresses
                  </Typography>
                  
                  <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                    <TextField
                      size="small"
                      value={ccInput}
                      onChange={(e) => setCcInput(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Enter email and press Enter"
                      sx={{ flex: 1 }}
                    />
                    <Button
                      variant="outlined"
                      onClick={handleAddCc}
                      disabled={!ccInput.trim()}
                      size="small"
                    >
                      Add
                    </Button>
                  </Box>

                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {formData.ccEmails.map((email) => (
                      <Chip
                        key={email}
                        label={email}
                        onDelete={() => handleRemoveCc(email)}
                        size="small"
                        sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                      />
                    ))}
                  </Box>
                </Box>
              )}
            </Paper>

            {/* Schedule Options */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="scheduleLater"
                    checked={formData.scheduleLater}
                    onChange={handleChange}
                    size="small"
                  />
                }
                label="Schedule for later"
              />

              {formData.scheduleLater && (
                <Grid container spacing={1.5} sx={{ mt: 1 }}>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      size="small"
                      type="date"
                      label="Date"
                      name="scheduledDate"
                      value={formData.scheduledDate}
                      onChange={handleChange}
                      InputLabelProps={{ shrink: true }}
                      error={!!validationErrors.scheduledDate}
                      helperText={validationErrors.scheduledDate}
                      inputProps={{ min: new Date().toISOString().split('T')[0] }}
                    />
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <TextField
                      fullWidth
                      size="small"
                      type="time"
                      label="Time"
                      name="scheduledTime"
                      value={formData.scheduledTime}
                      onChange={handleChange}
                      InputLabelProps={{ shrink: true }}
                      error={!!validationErrors.scheduledTime}
                      helperText={validationErrors.scheduledTime}
                    />
                  </Grid>
                </Grid>
              )}
            </Paper>
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Review Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Review & Confirm
              </Typography>

              <Grid container spacing={2}>
                {/* Offer Information */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Offer Details
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Offer ID</Typography>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>{offerDetails?.offerId}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Candidate</Typography>
                        <Typography variant="body2">{offerDetails?.candidateName}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                        <Typography variant="body2">{offerDetails?.candidateEmail || 'N/A'}</Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Phone</Typography>
                        <Typography variant="body2">{offerDetails?.candidatePhone || 'N/A'}</Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>

                {/* Notification Methods */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Notification Methods
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                    {formData.notificationMethods.map(method => {
                      const methodInfo = notificationMethods.find(m => m.id === method);
                      return (
                        <Chip
                          key={method}
                          icon={methodInfo?.icon}
                          label={methodInfo?.label}
                          size="small"
                          sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                        />
                      );
                    })}
                  </Box>
                </Grid>

                {/* Additional Message */}
                {formData.additionalMessage && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Additional Message
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.additionalMessage}</Typography>
                    </Paper>
                  </Grid>
                )}

                {/* CC Recipients */}
                {formData.sendCopy && formData.ccEmails.length > 0 && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      CC Recipients
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {formData.ccEmails.map(email => (
                        <Chip
                          key={email}
                          label={email}
                          size="small"
                          sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                        />
                      ))}
                    </Box>
                  </Grid>
                )}

                {/* Schedule */}
                {formData.scheduleLater && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Scheduled For
                    </Typography>
                    <Chip
                      icon={<ScheduleIcon />}
                      label={`${formData.scheduledDate} ${formData.scheduledTime}`}
                      size="small"
                      sx={{ backgroundColor: '#FFF3E0', color: '#E65100' }}
                    />
                  </Grid>
                )}
              </Grid>
            </Paper>

            {/* Send Result */}
            {sendResult && (
              <Alert 
                severity={sendResult.warning ? 'warning' : 'success'}
                sx={{ borderRadius: 1 }}
                icon={sendResult.warning ? <WarningIcon /> : <CheckCircleIcon />}
              >
                <Typography variant="body2" fontWeight={600}>
                  {sendResult.message}
                </Typography>
                {sendResult.warning && (
                  <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>
                    {sendResult.warning}
                  </Typography>
                )}
              </Alert>
            )}

            {/* Warning about PDF generation */}
            <Alert severity="info" sx={{ borderRadius: 1 }} icon={<InfoIcon />}>
              <Typography variant="body2">
                <strong>Note:</strong> Due to server limitations, PDF may not be generated. 
                Candidate will be able to view the offer in their browser with a secure link.
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {validationErrors.length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Send Offer to Candidate
        </Typography>
        {!sending && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      <DialogContent sx={{ p: 2, overflow: 'auto' }}>
        {/* Stepper */}
        <Stepper
          activeStep={activeStep}
          alternativeLabel
          connector={<ColorConnector />}
          sx={{ mb: 2, mt: 1 }}
        >
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>
                <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
              </StepLabel>
            </Step>
          ))}
        </Stepper>

        {renderStepContent(activeStep)}
      </DialogContent>

      <DialogActions sx={{
        px: 2,
        py: 1.5,
        borderTop: '1px solid #E0E0E0',
        backgroundColor: '#F8FAFC',
        justifyContent: 'space-between'
      }}>
        <Button
          onClick={handleBack}
          disabled={activeStep === 0 || sending}
          size="small"
          sx={{ color: '#666' }}
        >
          Back
        </Button>
        <Box>
          <Button
            onClick={handleClose}
            disabled={sending}
            size="small"
            sx={{ mr: 1, color: '#666' }}
          >
            Cancel
          </Button>
          {activeStep === steps.length - 1 ? (
            <Button
              variant="contained"
              onClick={handleSend}
              disabled={sending || !formData.offerId}
              size="small"
              startIcon={sending ? <CircularProgress size={16} color="inherit" /> : <SendIcon />}
              sx={{
                backgroundColor: '#1976D2',
                '&:hover': { backgroundColor: '#1565C0' }
              }}
            >
              {sending ? 'Sending...' : 'Send to Candidate'}
            </Button>
          ) : (
            <Button
              variant="contained"
              onClick={handleNext}
              disabled={sending}
              size="small"
              sx={{
                backgroundColor: '#1976D2',
                '&:hover': { backgroundColor: '#1565C0' }
              }}
            >
              Next
            </Button>
          )}
        </Box>
      </DialogActions>

      {/* Success Snackbar */}
      <Snackbar
        open={success}
        autoHideDuration={5000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          severity={sendResult?.warning ? 'warning' : 'success'} 
          sx={{ width: '100%' }} 
          onClose={() => setSuccess(false)}
        >
          {sendResult?.message || 'Offer sent successfully!'}
        </Alert>
      </Snackbar>
    </Dialog>
  );
};

export default SendToCandidate;