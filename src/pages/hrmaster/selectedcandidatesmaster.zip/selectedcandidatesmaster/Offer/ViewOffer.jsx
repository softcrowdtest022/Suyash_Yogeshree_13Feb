import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import {
  Box,
  CircularProgress,
  Typography,
  Alert,
  Button,
  Paper,
} from "@mui/material";
import axios from "axios";

const baseURL = "http://localhost:5000";

export default function ViewOfferPublic() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");

  const [loading, setLoading] = useState(true);
  const [htmlContent, setHtmlContent] = useState("");
  const [error, setError] = useState("");

  // 🔹 Fetch Offer Letter
  useEffect(() => {
    if (!token) {
      setError("Invalid or missing offer link.");
      setLoading(false);
      return;
    }

    const fetchOffer = async () => {
      try {
        const res = await axios.get(
          `${baseURL}/api/offers/public/view?token=${token}`,
          {
            responseType: "text", // important: API returns HTML
          }
        );

        setHtmlContent(res.data);
      } catch (err) {
        setError(
          err?.response?.data?.message ||
            "Unable to load the offer letter. The link may be expired."
        );
      } finally {
        setLoading(false);
      }
    };

    fetchOffer();
  }, [token]);

  // 🔹 Print / Save as PDF
  const handlePrint = () => {
    const printWindow = window.open("", "_blank");
    printWindow.document.write(htmlContent);
    printWindow.document.close();
    printWindow.print();
  };

  // 🔹 Loading State
  if (loading) {
    return (
      <Box sx={{ textAlign: "center", mt: 10 }}>
        <CircularProgress />
        <Typography mt={2}>Loading your offer letter...</Typography>
      </Box>
    );
  }

  // 🔹 Error State
  if (error) {
    return (
      <Box sx={{ maxWidth: 600, margin: "40px auto" }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  // 🔹 Success View
  return (
    <Box sx={{ maxWidth: 900, margin: "20px auto", p: 2 }}>
      {/* Actions */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          mb: 2,
          gap: 1,
        }}
      >
        <Button variant="outlined" onClick={handlePrint}>
          Print / Save PDF
        </Button>
      </Box>

      {/* Offer Letter */}
      <Paper elevation={3} sx={{ p: 2 }}>
        <div dangerouslySetInnerHTML={{ __html: htmlContent }} />
      </Paper>
    </Box>
  );
}