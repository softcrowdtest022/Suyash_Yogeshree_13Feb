// // OfferManagement.jsx

// import React, { useState } from "react";
// import {
//   Box,
//   Paper,
//   Typography,
//   Button,
//   Grid,
//   Snackbar,
//   Alert,
//   Divider,
//   Chip,
// } from "@mui/material";

// import InitiateOffer from "./InitiateOffer";
// import ApproveOffer from "./ApproveOffer";
// import SendOffer from "./SubmitOffer";
// import ViewOfferPublic from "./ViewOffer";

// const OfferManagement = ({ candidate, baseUrl }) => {
//   const [selectedOffer, setSelectedOffer] = useState(null);
//   const [publicToken, setPublicToken] = useState(null);

//   const [snackbar, setSnackbar] = useState({
//     open: false,
//     message: "",
//     severity: "success",
//   });

//   const showMessage = (message, severity = "success") => {
//     setSnackbar({ open: true, message, severity });
//   };

//   const handleOfferInitiated = (offer) => {
//     setSelectedOffer(offer); // ✅ auto-select initiated offer
//     showMessage("Offer initiated and selected automatically");
//   };

//   const handleOfferApproved = (data) => {
//     showMessage("Offer approved successfully");
//   };

//   const handleOfferSent = (data) => {
//     showMessage("Offer sent to candidate");
//     if (data?.publicToken) {
//       setPublicToken(data.publicToken);
//     }
//   };

//   if (!candidate) {
//     return (
//       <Alert severity="info">Select a candidate to manage offers.</Alert>
//     );
//   }

//   return (
//     <Box>
//       <Typography variant="h5" fontWeight={600} mb={2}>
//         Offer Management
//       </Typography>

//       <Paper sx={{ p: 2, mb: 3 }}>
//         <Typography variant="subtitle1" fontWeight={600}>
//           Candidate Details
//         </Typography>
//         <Typography>Name: {candidate.name}</Typography>
//         <Typography>Email: {candidate.email}</Typography>
//         <Typography>Position: {candidate.position}</Typography>
//       </Paper>

//       {/* INITIATE OFFER */}
//       <Paper sx={{ p: 2, mb: 3 }}>
//         <Typography variant="h6">1️⃣ Initiate Offer</Typography>
//         <Divider sx={{ my: 1 }} />

//         <InitiateOffer
//           candidateId={candidate._id}
//           baseUrl={baseUrl}
//           onSuccess={handleOfferInitiated}
//         />

//         {selectedOffer && (
//           <Chip
//             label={`Selected Offer: ${selectedOffer.offerId}`}
//             color="primary"
//             sx={{ mt: 2 }}
//           />
//         )}
//       </Paper>

//       {/* APPROVE OFFER */}
//       {selectedOffer && (
//         <Paper sx={{ p: 2, mb: 3 }}>
//           <Typography variant="h6">2️⃣ Approve Offer</Typography>
//           <Divider sx={{ my: 1 }} />

//           <ApproveOffer
//             offerId={selectedOffer._id}
//             baseUrl={baseUrl}
//             onSuccess={handleOfferApproved}
//           />
//         </Paper>
//       )}

//       {/* SEND OFFER */}
//       {selectedOffer && (
//         <Paper sx={{ p: 2, mb: 3 }}>
//           <Typography variant="h6">3️⃣ Send Offer to Candidate</Typography>
//           <Divider sx={{ my: 1 }} />

//           <SendOffer
//             offerId={selectedOffer._id}
//             baseUrl={baseUrl}
//             onSuccess={handleOfferSent}
//           />
//         </Paper>
//       )}

//       {/* VIEW PUBLIC OFFER */}
//       {publicToken && (
//         <Paper sx={{ p: 2 }}>
//           <Typography variant="h6">4️⃣ Public Offer View</Typography>
//           <Divider sx={{ my: 1 }} />

//           <ViewOfferPublic token={publicToken} baseUrl={baseUrl} />
//         </Paper>
//       )}

//       {/* SNACKBAR */}
//       <Snackbar
//         open={snackbar.open}
//         autoHideDuration={3500}
//         onClose={() => setSnackbar({ ...snackbar, open: false })}
//       >
//         <Alert severity={snackbar.severity}>{snackbar.message}</Alert>
//       </Snackbar>
//     </Box>
//   );
// };

// export default OfferManagement;

// OfferManagement.jsx


// import React from "react";
// import {
//   Box,
//   Paper,
//   Typography,
//   Table,
//   TableHead,
//   TableRow,
//   TableCell,
//   TableBody,
//   Chip,
//   Button,
//   Stack,
//   TextField,
//   TablePagination,
//   Checkbox,
//   CircularProgress,
// } from "@mui/material";

// const OfferManagement = ({
//   candidates = [],
//   loading,
//   onAction,
//   selected = [],
//   onSelect,
//   onSelectAll,
//   searchTerm,
//   onSearchChange,
//   page,
//   rowsPerPage,
//   onPageChange,
//   onRowsPerPageChange,
// }) => {
//   const getStatusColor = (status) => {
//     switch (status) {
//       case "accepted":
//         return "success";
//       case "approved":
//         return "primary";
//       case "pending_approval":
//         return "warning";
//       case "draft":
//         return "default";
//       default:
//         return "default";
//     }
//   };

//   const paginated = candidates.slice(
//     page * rowsPerPage,
//     page * rowsPerPage + rowsPerPage
//   );

//   return (
//     <Box>
//       <Typography variant="h6" fontWeight={600} mb={2}>
//         Offer Management
//       </Typography>

//       <Paper sx={{ p: 2, mb: 2 }}>
//         <Stack direction="row" justifyContent="space-between">
//           <TextField
//             placeholder="Search candidate / offer ID"
//             value={searchTerm}
//             onChange={onSearchChange}
//             size="small"
//           />
//         </Stack>
//       </Paper>

//       <Paper>
//         {loading ? (
//           <Box sx={{ textAlign: "center", py: 5 }}>
//             <CircularProgress />
//           </Box>
//         ) : (
//           <>
//             <Table>
//               <TableHead>
//                 <TableRow>
//                   <TableCell padding="checkbox">
//                     <Checkbox
//                       checked={
//                         candidates.length > 0 &&
//                         selected.length === candidates.length
//                       }
//                       onChange={onSelectAll}
//                     />
//                   </TableCell>
//                   <TableCell>Candidate</TableCell>
//                   <TableCell>Position</TableCell>
//                   <TableCell>Offer ID</TableCell>
//                   <TableCell>Status</TableCell>
//                   <TableCell align="right">Actions</TableCell>
//                 </TableRow>
//               </TableHead>

//               <TableBody>
//                 {paginated.map((candidate) => (
//                   <TableRow key={candidate._id} hover>
//                     <TableCell padding="checkbox">
//                       <Checkbox
//                         checked={selected.includes(candidate._id)}
//                         onChange={() => onSelect(candidate._id)}
//                       />
//                     </TableCell>

//                     <TableCell>
//                       <Typography fontWeight={500}>
//                         {candidate.name}
//                       </Typography>
//                       <Typography variant="caption" color="text.secondary">
//                         {candidate.email}
//                       </Typography>
//                     </TableCell>

//                     <TableCell>{candidate.position || "—"}</TableCell>

//                     <TableCell>
//                       {candidate.offer?.offerId || "No Offer"}
//                     </TableCell>

//                     <TableCell>
//                       <Chip
//                         label={candidate.offer?.status || "Not Initiated"}
//                         color={getStatusColor(candidate.offer?.status)}
//                         size="small"
//                       />
//                     </TableCell>

//                     <TableCell align="right">
//                       <Stack direction="row" spacing={1} justifyContent="flex-end">
//                         {!candidate.offer && (
//                           <Button
//                             size="small"
//                             variant="contained"
//                             onClick={() => onAction(candidate, "initiate_offer")}
//                           >
//                             Initiate
//                           </Button>
//                         )}

//                         {candidate.offer && (
//                           <>
//                             <Button
//                               size="small"
//                               onClick={() => onAction(candidate, "submit_offer")}
//                             >
//                               Submit
//                             </Button>

//                             <Button
//                               size="small"
//                               onClick={() => onAction(candidate, "approve_offer")}
//                             >
//                               Approve
//                             </Button>

//                             <Button
//                               size="small"
//                               onClick={() =>
//                                 onAction(candidate, "send_to_candidate")
//                               }
//                             >
//                               Send
//                             </Button>

//                             <Button
//                               size="small"
//                               onClick={() => onAction(candidate, "view_offer")}
//                             >
//                               View
//                             </Button>
//                           </>
//                         )}
//                       </Stack>
//                     </TableCell>
//                   </TableRow>
//                 ))}

//                 {paginated.length === 0 && (
//                   <TableRow>
//                     <TableCell colSpan={6} align="center">
//                       No candidates found
//                     </TableCell>
//                   </TableRow>
//                 )}
//               </TableBody>
//             </Table>

//             <TablePagination
//               component="div"
//               count={candidates.length}
//               page={page}
//               onPageChange={onPageChange}
//               rowsPerPage={rowsPerPage}
//               onRowsPerPageChange={onRowsPerPageChange}
//             />
//           </>
//         )}
//       </Paper>
//     </Box>
//   );
// };

// export default OfferManagement;

import React from "react";
import {
  Box,
  Paper,
  Typography,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Chip,
  Button,
  Stack,
  TextField,
  TablePagination,
  Checkbox,
  CircularProgress,
} from "@mui/material";

const OfferManagement = ({
  candidates = [],
  loading = false,
  onAction = () => {},
  selected = [],
  onSelect = () => {},
  onSelectAll = () => {},
  searchTerm = "",
  onSearchChange = () => {},
  page = 0,
  rowsPerPage = 10,
  onPageChange = () => {},
  onRowsPerPageChange = () => {},
}) => {
  // 🎯 Status color helper
const getStatusColor = (status) => {
  switch (status) {
    case "accepted": return "success";
    case "approved": return "primary";
    case "pending_approval": return "warning";
    case "sent": return "info";
    case "draft": return "default";
    default: return "default";
  }
};

  // 🎯 Pagination
  const paginatedCandidates = candidates.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  const isAllSelected =
    paginatedCandidates.length > 0 &&
    paginatedCandidates.every((c) => selected.includes(c._id));

  return (
    <Box>
      {/* Header */}
      <Typography variant="h6" fontWeight={600} mb={2}>
        Offer Management
      </Typography>

      {/* Search */}
      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" justifyContent="space-between">
          <TextField
            placeholder="Search candidate / offer ID"
            value={searchTerm}
            onChange={onSearchChange}
            size="small"
            fullWidth
          />
        </Stack>
      </Paper>

      {/* Table */}
      <Paper>
        {loading ? (
          <Box sx={{ textAlign: "center", py: 5 }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={isAllSelected}
                      onChange={(e) => onSelectAll(e)}
                    />
                  </TableCell>
                  <TableCell>Candidate</TableCell>
                  <TableCell>Position</TableCell>
                  <TableCell>Offer ID</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>

              <TableBody>
                {paginatedCandidates.map((candidate) => (
                  <TableRow key={candidate._id} hover>
                    {/* Checkbox */}
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selected.includes(candidate._id)}
                        onChange={() => onSelect(candidate._id)}
                      />
                    </TableCell>

                    {/* Candidate Info */}
                    <TableCell>
                      <Typography fontWeight={500}>
                        {candidate.name || "—"}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {candidate.email || "—"}
                      </Typography>
                    </TableCell>

                    {/* Position */}
                    <TableCell>{candidate.position || "—"}</TableCell>

                    {/* Offer ID */}
                    <TableCell>
                      {candidate.offer?.offerId || "No Offer"}
                    </TableCell>

                    {/* Status */}
                    <TableCell>
                      <Chip
                        label={candidate.offer?.status || "Not Initiated"}
                        color={getStatusColor(candidate.offer?.status)}
                        size="small"
                      />
                    </TableCell>

                    {/* Actions */}
                    <TableCell align="right">
                      <Stack direction="row" spacing={1} justifyContent="flex-end">
  {!candidate.offer && (
    <Button
      size="small"
      variant="contained"
      onClick={() => onAction(candidate, "initiate_offer")}
    >
      Initiate
    </Button>
  )}

  {candidate.offer?.status === "draft" && (
    <Button size="small" onClick={() => onAction(candidate, "submit_offer")}>
      Submit
    </Button>
  )}

  {candidate.offer?.status === "pending_approval" && (
    <Button size="small" onClick={() => onAction(candidate, "approve_offer")}>
      Approve
    </Button>
  )}

  {candidate.offer?.status === "approved" && (
    <Button size="small" onClick={() => onAction(candidate, "send_to_candidate")}>
      Send
    </Button>
  )}

  {candidate.offer && (
    <Button size="small" onClick={() => onAction(candidate, "view_offer")}>
      View
    </Button>
  )}
</Stack>
                    </TableCell>
                  </TableRow>
                ))}

                {/* Empty State */}
                {paginatedCandidates.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} align="center">
                      No candidates found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>

            {/* Pagination */}
            <TablePagination
              component="div"
              count={candidates.length}
              page={page}
              onPageChange={onPageChange}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={onRowsPerPageChange}
              rowsPerPageOptions={[5, 10, 25, 50]}
            />
          </>
        )}
      </Paper>
    </Box>
  );
};

export default OfferManagement;