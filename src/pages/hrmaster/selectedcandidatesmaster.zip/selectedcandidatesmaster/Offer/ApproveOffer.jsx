import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  TextField,
  Snackbar,
  Alert,
  CircularProgress,
} from "@mui/material";
import axios from "axios";
import BASE_URL from "../../../../config/Config";



export default function ApproveOffer({ open, onClose, candidateId }) {
  const [loading, setLoading] = useState(false);
  const [comments, setComments] = useState("");
  const [signature, setSignature] = useState("");
  const [snack, setSnack] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  // 🔹 Convert uploaded signature image → Base64
  const handleSignatureUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setSignature(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleApprove = async () => {
    try {
      setLoading(true);

      // 🔹 Step 1: fetch offers for candidate
      const offersRes = await axios.get(
        `${BASE_URL}/api/offers?candidateId=${candidateId}`
      );

      const offers = offersRes.data.data || [];

      // 🔹 Step 2: find pending approval offer
      const pendingOffer = offers
        .filter((o) => o.status === "pending_approval")
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];

      if (!pendingOffer) {
        throw new Error("No offer pending approval for this candidate");
      }

      const offerId = pendingOffer._id;

      // 🔹 Step 3: approve offer
      const res = await axios.post(
        `${BASE_URL}/api/offers/${offerId}/approve`,
        {
          comments,
          signature,
        }
      );

      setSnack({
        open: true,
        message: res.data.message,
        severity: "success",
      });

      onClose(true);
    } catch (err) {
      setSnack({
        open: true,
        message: err?.response?.data?.message || err.message,
        severity: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Dialog open={open} onClose={() => onClose(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Approve Offer</DialogTitle>

        <DialogContent>
          <Typography gutterBottom>
            This will approve the latest pending offer for this candidate.
          </Typography>

          {/* Comments */}
          <TextField
            fullWidth
            multiline
            rows={3}
            label="Approval Comments"
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            sx={{ mt: 2 }}
          />

          {/* Signature Upload */}
          <Button variant="outlined" component="label" sx={{ mt: 2 }}>
            Upload Signature
            <input hidden type="file" accept="image/*" onChange={handleSignatureUpload} />
          </Button>

          {signature && (
            <Typography variant="caption" display="block" sx={{ mt: 1 }}>
              Signature uploaded ✔
            </Typography>
          )}
        </DialogContent>

        <DialogActions>
          <Button onClick={() => onClose(false)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={handleApprove}
            disabled={loading}
            startIcon={loading && <CircularProgress size={18} />}
          >
            Approve
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snack.open}
        autoHideDuration={4000}
        onClose={() => setSnack({ ...snack, open: false })}
      >
        <Alert severity={snack.severity}>{snack.message}</Alert>
      </Snackbar>
    </>
  );
}