// import React, { useState } from 'react';
// import {
//   Box,
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   IconButton,
//   Button,
//   TextField,
//   InputAdornment,
//   Tooltip,
//   Typography,
//   TablePagination,
//   Checkbox,
//   Stack,
//   alpha,
//   Avatar,
//   Chip,
//   LinearProgress,
//   CircularProgress,
//   Grid,
//   Menu,
//   MenuItem,
//   ListItemIcon,
//   ListItemText,
//   Divider
// } from '@mui/material';
// import {
//   Search as SearchIcon,
//   Refresh as RefreshIcon,
//   Download as DownloadIcon,
//   Description as DescriptionIcon,
//   CloudUpload as CloudUploadIcon,
//   Verified as VerifiedIcon,
//   Visibility as VisibilityIcon,
//   MoreVert as MoreVertIcon,
//   Warning as WarningIcon,
//   CheckCircle as CheckCircleIcon
// } from '@mui/icons-material';

// import { PRIMARY_BLUE, TEXT_COLOR_MAIN, SUCCESS_COLOR, WARNING_COLOR, DANGER_COLOR } from '../components/utils/constants';
// import { formatDate, getAvatarInitials, getAvatarColor } from '../components/utils/helpers';
// import StatusChip from '../components/shared/StatusChip';
// import StatsCard from '../components/shared/StatsCard';

// // Import document modals
// import UploadDoc from './UploadDoc';
// import VerifyDoc from './VerifyDoc';
// import ViewAllDoc from './ViewAllDoc';

// const DocumentManagement = ({ 
//   candidates, 
//   loading, 
//   onRefresh,
//   onAction,
//   selected,
//   onSelect,
//   onSelectAll,
//   searchTerm,
//   onSearchChange,
//   page,
//   rowsPerPage,
//   onPageChange,
//   onRowsPerPageChange,
//   stats
// }) => {
//   const [actionMenuAnchor, setActionMenuAnchor] = useState(null);
//   const [selectedCandidate, setSelectedCandidate] = useState(null);

//   const handleActionClick = (event, candidate) => {
//     setActionMenuAnchor(event.currentTarget);
//     setSelectedCandidate(candidate);
//   };

//   const handleActionClose = () => {
//     setActionMenuAnchor(null);
//     setSelectedCandidate(null);
//   };

//   const handleAction = (action) => {
//     if (selectedCandidate) {
//       onAction(selectedCandidate, action);
//     }
//     handleActionClose();
//   };

//   const getDocumentProgressColor = (verified, total) => {
//     if (total === 0) return WARNING_COLOR;
//     const percentage = (verified / total) * 100;
//     return percentage >= 75 ? SUCCESS_COLOR : percentage >= 50 ? WARNING_COLOR : DANGER_COLOR;
//   };

//   const paginatedCandidates = candidates.slice(
//     page * rowsPerPage,
//     page * rowsPerPage + rowsPerPage
//   );

//   return (
//     <Box>
//       {/* Document Stats */}
//       <Grid container spacing={2} sx={{ mb: 3 }}>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Total Documents"
//             value={stats.totalDocuments || 0}
//             icon={DescriptionIcon}
//             color={PRIMARY_BLUE}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Verified"
//             value={stats.verifiedDocuments || 0}
//             icon={VerifiedIcon}
//             color={SUCCESS_COLOR}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Pending"
//             value={stats.pendingDocuments || 0}
//             icon={WarningIcon}
//             color={WARNING_COLOR}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <StatsCard
//             title="Pending Verification"
//             value={stats.pendingVerification || 0}
//             icon={CloudUploadIcon}
//             color={DANGER_COLOR}
//           />
//         </Grid>
//       </Grid>

//       {/* Action Bar */}
//       <Paper sx={{ 
//         p: 2, 
//         mb: 3, 
//         borderRadius: 2,
//         bgcolor: '#FFFFFF',
//         boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
//         border: '1px solid #e2e8f0'
//       }}>
//         <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems="center" justifyContent="space-between">
//           <TextField
//             placeholder="Search documents..."
//             size="small"
//             value={searchTerm}
//             onChange={onSearchChange}
//             sx={{ 
//               width: { xs: '100%', sm: 300 },
//               '& .MuiOutlinedInput-root': {
//                 borderRadius: 1.5,
//                 '&:hover fieldset': {
//                   borderColor: PRIMARY_BLUE,
//                 },
//               }
//             }}
//             InputProps={{
//               startAdornment: (
//                 <InputAdornment position="start">
//                   <SearchIcon sx={{ color: '#64748B' }} />
//                 </InputAdornment>
//               ),
//               sx: { height: 40, bgcolor: '#f8fafc' }
//             }}
//           />

//           <Stack direction="row" spacing={1}>
//             <Button
//               variant="outlined"
//               startIcon={<DownloadIcon />}
//               sx={{ 
//                 height: 40,
//                 borderRadius: 1.5,
//                 borderColor: '#cbd5e1',
//                 color: '#475569',
//                 textTransform: 'none'
//               }}
//             >
//               Export
//             </Button>
//             <IconButton
//               onClick={onRefresh}
//               sx={{
//                 height: 40,
//                 width: 40,
//                 borderRadius: 1.5,
//                 border: '1px solid #cbd5e1',
//                 color: '#475569'
//               }}
//             >
//               <RefreshIcon fontSize="small" />
//             </IconButton>
//           </Stack>
//         </Stack>
//       </Paper>

//       {/* Documents Table */}
//       <Paper sx={{ 
//         width: '100%', 
//         borderRadius: 2, 
//         overflow: 'hidden',
//         boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
//         border: '1px solid #e2e8f0'
//       }}>
//         {loading && <LinearProgress sx={{ bgcolor: PRIMARY_BLUE }} />}
        
//         <TableContainer>
//           <Table stickyHeader>
//             <TableHead>
//               <TableRow sx={{ 
//                 bgcolor: '#f8fafc',
//                 '& .MuiTableCell-root': {
//                   fontWeight: 600,
//                   fontSize: '0.875rem',
//                   color: TEXT_COLOR_MAIN,
//                   borderBottom: '2px solid #e2e8f0'
//                 }
//               }}>
//                 <TableCell padding="checkbox" sx={{ width: 50 }}>
//                   <Checkbox
//                     indeterminate={selected.length > 0 && selected.length < candidates.length}
//                     checked={candidates.length > 0 && selected.length === candidates.length}
//                     onChange={onSelectAll}
//                     sx={{ color: PRIMARY_BLUE }}
//                   />
//                 </TableCell>
//                 <TableCell>Candidate</TableCell>
//                 <TableCell>Total Docs</TableCell>
//                 <TableCell>Verified</TableCell>
//                 <TableCell>Pending</TableCell>
//                 <TableCell>Last Upload</TableCell>
//                 <TableCell>Status</TableCell>
//                 <TableCell>Actions</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {loading ? (
//                 <TableRow>
//                   <TableCell colSpan={8} align="center" sx={{ py: 8 }}>
//                     <CircularProgress size={32} sx={{ color: PRIMARY_BLUE }} />
//                   </TableCell>
//                 </TableRow>
//               ) : paginatedCandidates.length === 0 ? (
//                 <TableRow>
//                   <TableCell colSpan={8} align="center" sx={{ py: 8 }}>
//                     <Typography color="#64748B">No documents found</Typography>
//                   </TableCell>
//                 </TableRow>
//               ) : (
//                 paginatedCandidates.map((candidate, index) => {
//                   const isSelected = selected.includes(candidate._id);
//                   const avatarColor = getAvatarColor(candidate.name);
//                   const verified = candidate.documents?.verified || 0;
//                   const total = candidate.documents?.total || 0;
//                   const pending = candidate.documents?.pending || 0;

//                   return (
//                     <TableRow
//                       key={candidate._id}
//                       hover
//                       selected={isSelected}
//                       sx={{ 
//                         '&:hover': { bgcolor: alpha(PRIMARY_BLUE, 0.04) },
//                         '&.Mui-selected': { bgcolor: alpha(PRIMARY_BLUE, 0.08) }
//                       }}
//                     >
//                       <TableCell padding="checkbox">
//                         <Checkbox
//                           checked={isSelected}
//                           onChange={() => onSelect(candidate._id)}
//                           sx={{ color: PRIMARY_BLUE }}
//                         />
//                       </TableCell>
//                       <TableCell>
//                         <Stack direction="row" spacing={2} alignItems="center">
//                           <Avatar sx={{ width: 40, height: 40, bgcolor: avatarColor }}>
//                             {getAvatarInitials(candidate.name)}
//                           </Avatar>
//                           <Box>
//                             <Typography variant="body2" fontWeight={600}>
//                               {candidate.name}
//                             </Typography>
//                             <Typography variant="caption" color="#64748B">
//                               {candidate.email}
//                             </Typography>
//                           </Box>
//                         </Stack>
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2" fontWeight={600}>
//                           {total}
//                         </Typography>
//                       </TableCell>
//                       <TableCell>
//                         <Chip
//                           label={verified}
//                           size="small"
//                           sx={{
//                             bgcolor: alpha(SUCCESS_COLOR, 0.1),
//                             color: SUCCESS_COLOR,
//                             fontWeight: 500
//                           }}
//                         />
//                       </TableCell>
//                       <TableCell>
//                         <Chip
//                           label={pending}
//                           size="small"
//                           sx={{
//                             bgcolor: alpha(pending > 0 ? WARNING_COLOR : SUCCESS_COLOR, 0.1),
//                             color: pending > 0 ? WARNING_COLOR : SUCCESS_COLOR,
//                             fontWeight: 500
//                           }}
//                         />
//                       </TableCell>
//                       <TableCell>
//                         <Typography variant="body2">
//                           {candidate.documents?.lastUpload ? formatDate(candidate.documents.lastUpload) : '-'}
//                         </Typography>
//                       </TableCell>
//                       <TableCell>
//                         {pending === 0 ? (
//                           <Chip
//                             icon={<CheckCircleIcon />}
//                             label="Complete"
//                             size="small"
//                             sx={{ bgcolor: alpha(SUCCESS_COLOR, 0.1), color: SUCCESS_COLOR }}
//                           />
//                         ) : (
//                           <Chip
//                             icon={<WarningIcon />}
//                             label="Pending"
//                             size="small"
//                             sx={{ bgcolor: alpha(WARNING_COLOR, 0.1), color: WARNING_COLOR }}
//                           />
//                         )}
//                       </TableCell>
//                       <TableCell>
//                         <Tooltip title="Document Actions">
//                           <IconButton
//                             size="small"
//                             onClick={(e) => handleActionClick(e, candidate)}
//                             sx={{ color: '#64748b' }}
//                           >
//                             <MoreVertIcon fontSize="small" />
//                           </IconButton>
//                         </Tooltip>
//                       </TableCell>
//                     </TableRow>
//                   );
//                 })
//               )}
//             </TableBody>
//           </Table>
//         </TableContainer>

//         <TablePagination
//           rowsPerPageOptions={[5, 10, 25, 50]}
//           component="div"
//           count={candidates.length}
//           rowsPerPage={rowsPerPage}
//           page={page}
//           onPageChange={onPageChange}
//           onRowsPerPageChange={onRowsPerPageChange}
//           sx={{ borderTop: '1px solid #e2e8f0' }}
//         />
//       </Paper>

//       {/* Action Menu */}
//       <Menu
//         anchorEl={actionMenuAnchor}
//         open={Boolean(actionMenuAnchor)}
//         onClose={handleActionClose}
//         PaperProps={{ sx: { minWidth: 200, borderRadius: 2 } }}
//       >
//         <MenuItem onClick={() => handleAction('upload_doc')}>
//           <ListItemIcon><CloudUploadIcon fontSize="small" /></ListItemIcon>
//           <ListItemText>Upload Document</ListItemText>
//         </MenuItem>
//         <MenuItem onClick={() => handleAction('verify_doc')}>
//           <ListItemIcon><VerifiedIcon fontSize="small" /></ListItemIcon>
//           <ListItemText>Verify Document</ListItemText>
//         </MenuItem>
//         <Divider />
//         <MenuItem onClick={() => handleAction('view_docs')}>
//           <ListItemIcon><VisibilityIcon fontSize="small" /></ListItemIcon>
//           <ListItemText>View All Documents</ListItemText>
//         </MenuItem>
//       </Menu>
//     </Box>
//   );
// };

// export default DocumentManagement;


import React, { useState } from 'react';
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Button,
  TextField,
  InputAdornment,
  Tooltip,
  Typography,
  TablePagination,
  Checkbox,
  Stack,
  alpha,
  Avatar,
  Chip,
  LinearProgress,
  CircularProgress,
  Grid,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Divider
} from '@mui/material';
import {
  Search as SearchIcon,
  Refresh as RefreshIcon,
  Download as DownloadIcon,
  Description as DescriptionIcon,
  CloudUpload as CloudUploadIcon,
  Verified as VerifiedIcon,
  Visibility as VisibilityIcon,
  MoreVert as MoreVertIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';
import { formatDate, getAvatarInitials, getAvatarColor } from '../components/utils/helpers'
import StatusChip from '../components/shared/StatusChip';
import StatsCard from '../components/shared/StatsCard';


const PRIMARY_BLUE = '#00B4D8';
const TEXT_COLOR_MAIN = '#0f172a';
const SUCCESS_COLOR = '#10B981';
const WARNING_COLOR = '#F59E0B';
const DANGER_COLOR = '#EF4444';

const DocumentManagement = ({ 
  candidates, 
  loading, 
  onRefresh,
  onAction,
  selected,
  onSelect,
  onSelectAll,
  searchTerm,
  onSearchChange,
  page,
  rowsPerPage,
  onPageChange,
  onRowsPerPageChange,
  stats
}) => {
  const [actionMenuAnchor, setActionMenuAnchor] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleActionClick = (event, candidate) => {
    setActionMenuAnchor(event.currentTarget);
    setSelectedCandidate(candidate);
  };

  const handleActionClose = () => {
    setActionMenuAnchor(null);
    setSelectedCandidate(null);
  };

  const handleAction = (action) => {
    if (selectedCandidate) {
      onAction(selectedCandidate, action);
    }
    handleActionClose();
  };

  const handleUploadDocument = async (candidateId, file) => {
    try {
      setUploading(true);
      const token = localStorage.getItem('token');
      const formData = new FormData();
      formData.append('file', file);
      formData.append('candidateId', candidateId);

      const response = await axios.post(`${BASE_URL}/api/documents`, formData, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data.success) {
        onRefresh();
        return true;
      }
    } catch (err) {
      console.error('Error uploading document:', err);
      return false;
    } finally {
      setUploading(false);
    }
  };

  const getDocumentStatusColor = (verified, total) => {
    if (total === 0) return WARNING_COLOR;
    const percentage = (verified / total) * 100;
    return percentage >= 75 ? SUCCESS_COLOR : percentage >= 50 ? WARNING_COLOR : DANGER_COLOR;
  };

  const paginatedCandidates = candidates.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  return (
    <Box>
      {/* Document Stats */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Total Documents"
            value={stats.totalDocuments || 0}
            icon={DescriptionIcon}
            color={PRIMARY_BLUE}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Verified"
            value={stats.verifiedDocuments || 0}
            icon={VerifiedIcon}
            color={SUCCESS_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Pending"
            value={stats.pendingDocuments || 0}
            icon={WarningIcon}
            color={WARNING_COLOR}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatsCard
            title="Need Verification"
            value={stats.pendingVerification || 0}
            icon={CloudUploadIcon}
            color={DANGER_COLOR}
          />
        </Grid>
      </Grid>

      {/* Action Bar */}
      <Paper sx={{ 
        p: 2, 
        mb: 3, 
        borderRadius: 2,
        bgcolor: '#FFFFFF',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
        border: '1px solid #e2e8f0'
      }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems="center" justifyContent="space-between">
          <TextField
            placeholder="Search documents..."
            size="small"
            value={searchTerm}
            onChange={onSearchChange}
            sx={{ 
              width: { xs: '100%', sm: 300 },
              '& .MuiOutlinedInput-root': {
                borderRadius: 1.5,
                '&:hover fieldset': {
                  borderColor: PRIMARY_BLUE,
                },
              }
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#64748B' }} />
                </InputAdornment>
              ),
              sx: { height: 40, bgcolor: '#f8fafc' }
            }}
          />

          <Stack direction="row" spacing={1}>
            <Button
              variant="outlined"
              startIcon={<DownloadIcon />}
              sx={{ 
                height: 40,
                borderRadius: 1.5,
                borderColor: '#cbd5e1',
                color: '#475569',
                textTransform: 'none'
              }}
            >
              Export
            </Button>
            <IconButton
              onClick={onRefresh}
              disabled={loading}
              sx={{
                height: 40,
                width: 40,
                borderRadius: 1.5,
                border: '1px solid #cbd5e1',
                color: '#475569'
              }}
            >
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Stack>
        </Stack>
      </Paper>

      {/* Documents Table */}
      <Paper sx={{ 
        width: '100%', 
        borderRadius: 2, 
        overflow: 'hidden',
        boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)',
        border: '1px solid #e2e8f0'
      }}>
        {loading && <LinearProgress sx={{ bgcolor: PRIMARY_BLUE }} />}
        
        <TableContainer>
          <Table stickyHeader>
            <TableHead>
              <TableRow sx={{ 
                bgcolor: '#f8fafc',
                '& .MuiTableCell-root': {
                  fontWeight: 600,
                  fontSize: '0.875rem',
                  color: TEXT_COLOR_MAIN,
                  borderBottom: '2px solid #e2e8f0'
                }
              }}>
                <TableCell padding="checkbox" sx={{ width: 50 }}>
                  <Checkbox
                    indeterminate={selected.length > 0 && selected.length < candidates.length}
                    checked={candidates.length > 0 && selected.length === candidates.length}
                    onChange={onSelectAll}
                    sx={{ color: PRIMARY_BLUE }}
                  />
                </TableCell>
                <TableCell>Candidate</TableCell>
                <TableCell>Total Docs</TableCell>
                <TableCell>Verified</TableCell>
                <TableCell>Pending</TableCell>
                <TableCell>Rejected</TableCell>
                <TableCell>Last Upload</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 8 }}>
                    <CircularProgress size={32} sx={{ color: PRIMARY_BLUE }} />
                  </TableCell>
                </TableRow>
              ) : paginatedCandidates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 8 }}>
                    <Box sx={{ textAlign: 'center' }}>
                      <DescriptionIcon sx={{ fontSize: 48, color: '#D1D5DB', mb: 2 }} />
                      <Typography variant="body1" color="#64748B" fontWeight={500}>
                        No documents found
                      </Typography>
                      <Typography variant="body2" color="#94A3B8" sx={{ mt: 1 }}>
                        {searchTerm ? 'Try adjusting your search terms' : 'Upload documents to get started'}
                      </Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              ) : (
                paginatedCandidates.map((candidate) => {
                  const isSelected = selected.includes(candidate._id);
                  const avatarColor = getAvatarColor(candidate.name);
                  const verified = candidate.documents?.verified || 0;
                  const total = candidate.documents?.total || 0;
                  const pending = candidate.documents?.pending || 0;
                  const rejected = candidate.documents?.rejected || 0;

                  return (
                    <TableRow
                      key={candidate._id}
                      hover
                      selected={isSelected}
                      sx={{ 
                        '&:hover': { bgcolor: alpha(PRIMARY_BLUE, 0.04) },
                        '&.Mui-selected': { bgcolor: alpha(PRIMARY_BLUE, 0.08) }
                      }}
                    >
                      <TableCell padding="checkbox">
                        <Checkbox
                          checked={isSelected}
                          onChange={() => onSelect(candidate._id)}
                          sx={{ color: PRIMARY_BLUE }}
                        />
                      </TableCell>
                      <TableCell>
                        <Stack direction="row" spacing={2} alignItems="center">
                          <Avatar sx={{ width: 40, height: 40, bgcolor: avatarColor }}>
                            {getAvatarInitials(candidate.name)}
                          </Avatar>
                          <Box>
                            <Typography variant="body2" fontWeight={600}>
                              {candidate.name}
                            </Typography>
                            <Typography variant="caption" color="#64748B">
                              {candidate.email}
                            </Typography>
                          </Box>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600}>
                          {total}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={verified}
                          size="small"
                          sx={{
                            bgcolor: alpha(SUCCESS_COLOR, 0.1),
                            color: SUCCESS_COLOR,
                            fontWeight: 500,
                            minWidth: 40
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip
                          label={pending}
                          size="small"
                          sx={{
                            bgcolor: alpha(pending > 0 ? WARNING_COLOR : SUCCESS_COLOR, 0.1),
                            color: pending > 0 ? WARNING_COLOR : SUCCESS_COLOR,
                            fontWeight: 500,
                            minWidth: 40
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        {rejected > 0 ? (
                          <Chip
                            label={rejected}
                            size="small"
                            sx={{
                              bgcolor: alpha(DANGER_COLOR, 0.1),
                              color: DANGER_COLOR,
                              fontWeight: 500,
                              minWidth: 40
                            }}
                          />
                        ) : (
                          <Typography variant="body2" color="#94A3B8">-</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2">
                          {candidate.documents?.lastUpload ? formatDate(candidate.documents.lastUpload) : '-'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        {pending === 0 && rejected === 0 ? (
                          <Chip
                            icon={<CheckCircleIcon sx={{ fontSize: 16 }} />}
                            label="Complete"
                            size="small"
                            sx={{ 
                              bgcolor: alpha(SUCCESS_COLOR, 0.1), 
                              color: SUCCESS_COLOR,
                              '& .MuiChip-icon': { color: SUCCESS_COLOR }
                            }}
                          />
                        ) : pending > 0 ? (
                          <Chip
                            icon={<WarningIcon sx={{ fontSize: 16 }} />}
                            label="Pending"
                            size="small"
                            sx={{ 
                              bgcolor: alpha(WARNING_COLOR, 0.1), 
                              color: WARNING_COLOR,
                              '& .MuiChip-icon': { color: WARNING_COLOR }
                            }}
                          />
                        ) : rejected > 0 ? (
                          <Chip
                            label="Issues"
                            size="small"
                            sx={{ 
                              bgcolor: alpha(DANGER_COLOR, 0.1), 
                              color: DANGER_COLOR
                            }}
                          />
                        ) : null}
                      </TableCell>
                      <TableCell align="center">
                        <Tooltip title="Document Actions">
                          <IconButton
                            size="small"
                            onClick={(e) => handleActionClick(e, candidate)}
                            sx={{ 
                              color: '#64748b',
                              '&:hover': {
                                bgcolor: alpha(PRIMARY_BLUE, 0.1)
                              }
                            }}
                          >
                            <MoreVertIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={candidates.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={onPageChange}
          onRowsPerPageChange={onRowsPerPageChange}
          sx={{ 
            borderTop: '1px solid #e2e8f0',
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
              fontSize: '0.875rem',
              color: '#64748B'
            }
          }}
        />
      </Paper>

      {/* Action Menu */}
      <Menu
        anchorEl={actionMenuAnchor}
        open={Boolean(actionMenuAnchor)}
        onClose={handleActionClose}
        PaperProps={{
          elevation: 3,
          sx: {
            minWidth: 200,
            borderRadius: 2,
            border: '1px solid #e2e8f0'
          }
        }}
      >
        <MenuItem disabled sx={{ opacity: 0.7 }}>
          <Typography variant="caption" color="textSecondary">
            Document Actions
          </Typography>
        </MenuItem>
        <Divider />
        
        <MenuItem onClick={() => handleAction('upload_doc')}>
          <ListItemIcon>
            <CloudUploadIcon fontSize="small" sx={{ color: '#0e7490' }} />
          </ListItemIcon>
          <ListItemText primary="Upload Document" />
        </MenuItem>
        
        <MenuItem 
          onClick={() => handleAction('verify_doc')}
          disabled={!selectedCandidate?.documents?.documents?.length}
        >
          <ListItemIcon>
            <VerifiedIcon fontSize="small" sx={{ color: '#8B5CF6' }} />
          </ListItemIcon>
          <ListItemText primary="Verify Document" />
        </MenuItem>
        
        <Divider />
        
        <MenuItem onClick={() => handleAction('view_docs')}>
          <ListItemIcon>
            <VisibilityIcon fontSize="small" sx={{ color: '#64748B' }} />
          </ListItemIcon>
          <ListItemText primary="View All Documents" />
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default DocumentManagement;