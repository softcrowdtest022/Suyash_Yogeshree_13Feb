import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  RadioGroup,
  Radio,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  
  // Stepper
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,

  // Progress
  LinearProgress,
  
  // Tabs
  Tab,
  Tabs,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  
} from '@mui/material';
// Import Timeline components from @mui/lab
import {
  Timeline,
  TimelineItem,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineOppositeContent,
} from '@mui/lab';

import { 
  Close as CloseIcon,
  CheckCircle as CheckCircleIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Visibility as VisibilityIcon,
  Delete as DeleteIcon,
  Description as DescriptionIcon,
  PictureAsPdf as PdfIcon,
  Image as ImageIcon,
  InsertDriveFile as FileIcon,
  Verified as VerifiedIcon,
  VerifiedUser as VerifiedUserIcon,
  GppGood as GppGoodIcon,
  GppMaybe as GppMaybeIcon,
  GppBad as GppBadIcon,
  ThumbUp as ThumbUpIcon,
  ThumbDown as ThumbDownIcon,
  History as HistoryIcon,
  Person as PersonIcon,
  DateRange as DateRangeIcon,
  Comment as CommentIcon,
  Flag as FlagIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Share as ShareIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Cancel as CancelIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    VERIFIED: { bg: '#E8F5E9', color: '#2E7D32' },
    PENDING: { bg: '#FFF3E0', color: '#E65100' },
    REJECTED: { bg: '#FFEBEE', color: '#C62828' },
    EXPIRED: { bg: '#F5F5F5', color: '#9E9E9E' }
  };
  const color = colors[status] || colors.PENDING;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const DocumentCard = styled(Card)(({ theme, selected }) => ({
  cursor: 'pointer',
  border: selected ? '2px solid #1976D2' : '1px solid #E0E0E0',
  borderRadius: 1,
  transition: 'all 0.2s',
  '&:hover': {
    borderColor: '#1976D2',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  position: 'relative',
  overflow: 'visible'
}));

const VerifiedBadge = styled(Box)(({ theme }) => ({
  position: 'absolute',
  top: -10,
  right: -10,
  backgroundColor: '#4CAF50',
  color: 'white',
  borderRadius: '50%',
  width: 24,
  height: 24,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1
}));

const InfoCard = styled(Card)(({ theme }) => ({
  backgroundColor: '#F8FAFC',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  height: '100%',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const DetailRow = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '8px 0',
  borderBottom: '1px solid #F0F0F0',
  '&:last-child': {
    borderBottom: 'none'
  }
}));

const DetailIcon = styled(Box)(({ theme }) => ({
  width: 32,
  height: 32,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  backgroundColor: '#E3F2FD',
  color: '#1976D2',
  marginRight: 12,
  '& svg': {
    fontSize: 18
  }
}));

const VerifyDoc = ({ open, onClose, onVerify, documentId: propDocumentId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState({
    documentId: propDocumentId || '',
    verified: true,
    comments: '',
    verificationType: 'full', // 'full', 'partial', 'reject'
    rejectionReason: '',
    confidenceScore: 100,
    verifiedFields: [],
    flags: [],
    requiresSecondReview: false,
    notifyCandidate: true
  });

  // Document data state
  const [documents, setDocuments] = useState([]);
  const [documentLoading, setDocumentLoading] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [documentDetails, setDocumentDetails] = useState(null);
  const [documentHistory, setDocumentHistory] = useState([]);
  
  // Search/filter states
  const [documentSearch, setDocumentSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('PENDING');
  const [filterType, setFilterType] = useState('all');
  
  // Verification state
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [verifyResult, setVerifyResult] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // Document preview
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewUrl, setPreviewUrl] = useState('');

  // Steps definition
  const steps = ['Select Document', 'Review Document', 'Verify', 'Confirm'];

  // Document types for filtering
  const documentTypes = [
    { id: 'aadhar', label: 'Aadhar Card' },
    { id: 'pan', label: 'PAN Card' },
    { id: 'voter', label: 'Voter ID' },
    { id: 'passport', label: 'Passport' },
    { id: 'driving', label: 'Driving License' },
    { id: 'ssc', label: 'SSC Certificate' },
    { id: 'hsc', label: 'HSC Certificate' },
    { id: 'graduation', label: 'Graduation Degree' },
    { id: 'experience', label: 'Experience Certificate' },
    { id: 'relieving', label: 'Relieving Letter' },
    { id: 'salary', label: 'Salary Slips' }
  ];

  // Verification fields based on document type
  const getVerificationFields = (docType) => {
    const commonFields = [
      { id: 'documentNumber', label: 'Document Number' },
      { id: 'candidateName', label: 'Candidate Name' },
      { id: 'issueDate', label: 'Issue Date' },
      { id: 'expiryDate', label: 'Expiry Date' }
    ];

    const typeSpecificFields = {
      aadhar: [
        { id: 'aadharNumber', label: 'Aadhar Number' },
        { id: 'name', label: 'Name on Aadhar' },
        { id: 'dob', label: 'Date of Birth' },
        { id: 'gender', label: 'Gender' },
        { id: 'address', label: 'Address' }
      ],
      pan: [
        { id: 'panNumber', label: 'PAN Number' },
        { id: 'name', label: 'Name on PAN' },
        { id: 'dob', label: 'Date of Birth' }
      ],
      passport: [
        { id: 'passportNumber', label: 'Passport Number' },
        { id: 'name', label: 'Name on Passport' },
        { id: 'dob', label: 'Date of Birth' },
        { id: 'nationality', label: 'Nationality' },
        { id: 'issuePlace', label: 'Place of Issue' }
      ],
      ssc: [
        { id: 'rollNumber', label: 'Roll Number' },
        { id: 'board', label: 'Board' },
        { id: 'percentage', label: 'Percentage' },
        { id: 'yearOfPassing', label: 'Year of Passing' }
      ]
    };

    return typeSpecificFields[docType] || commonFields;
  };

  // Fetch pending documents for verification
  const fetchDocuments = async (status = 'PENDING', type = 'all', search = '') => {
    setDocumentLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          status: status,
          type: type !== 'all' ? type : undefined,
          search: search,
          limit: 50
        }
      });

      if (response.data.success) {
        setDocuments(response.data.data || []);
      }
    } catch (err) {
      console.error('Error fetching documents:', err);
      setError('Failed to load documents');
    } finally {
      setDocumentLoading(false);
    }
  };

  // Fetch document details
  const fetchDocumentDetails = async (docId) => {
    if (!docId) return;
    
    setDocumentLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents/${docId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setDocumentDetails(response.data.data);
        fetchDocumentHistory(docId);
        
        // Fetch document preview
        fetchDocumentPreview(docId);
      }
    } catch (err) {
      console.error('Error fetching document details:', err);
      setError('Failed to load document details');
    } finally {
      setDocumentLoading(false);
    }
  };

  // Fetch document history
  const fetchDocumentHistory = async (docId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents/${docId}/history`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setDocumentHistory(response.data.data || []);
      }
    } catch (err) {
      console.error('Error fetching document history:', err);
    }
  };

  // Fetch document preview
  const fetchDocumentPreview = async (docId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents/${docId}/preview`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      setPreviewUrl(url);
    } catch (err) {
      console.error('Error fetching document preview:', err);
    }
  };

  // Load documents on mount or when filters change
  useEffect(() => {
    if (open) {
      fetchDocuments(filterStatus, filterType, documentSearch);
    }
  }, [open, filterStatus, filterType, documentSearch]);

  // Load document details when selected
  useEffect(() => {
    if (formData.documentId) {
      fetchDocumentDetails(formData.documentId);
    } else {
      setDocumentDetails(null);
      setDocumentHistory([]);
      setPreviewUrl('');
    }
  }, [formData.documentId]);

  const handleChange = (e) => {
    const { name, value, checked, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear field error when user types
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleVerificationTypeChange = (type) => {
    setFormData(prev => ({
      ...prev,
      verificationType: type,
      verified: type === 'full' ? true : (type === 'reject' ? false : prev.verified),
      confidenceScore: type === 'full' ? 100 : (type === 'partial' ? 75 : 0)
    }));
  };

  const handleFieldToggle = (fieldId) => {
    setFormData(prev => {
      const fields = prev.verifiedFields.includes(fieldId)
        ? prev.verifiedFields.filter(f => f !== fieldId)
        : [...prev.verifiedFields, fieldId];
      
      // Update confidence score based on verified fields
      const totalFields = getVerificationFields(documentDetails?.type).length;
      const confidence = Math.round((fields.length / totalFields) * 100);
      
      return {
        ...prev,
        verifiedFields: fields,
        confidenceScore: confidence
      };
    });
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.documentId) {
        errors.documentId = 'Please select a document to verify';
      }
    } else if (step === 2) {
      if (formData.verificationType === 'reject' && !formData.rejectionReason.trim()) {
        errors.rejectionReason = 'Please provide a reason for rejection';
      }
      if (formData.verificationType === 'partial' && formData.verifiedFields.length === 0) {
        errors.verifiedFields = 'Please select at least one verified field';
      }
      if (!formData.comments.trim() && formData.verificationType !== 'full') {
        errors.comments = 'Comments are required for partial verification or rejection';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors({});
    // Small delay before retrying
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  const handleSubmit = async () => {
    if (!validateStep(2)) {
      setError('Please complete all required fields');
      return;
    }

    setVerifying(true);
    setError('');
    setValidationErrors({});

    try {
      const token = localStorage.getItem('token');

      // Prepare data according to API expectations
      const submitData = {
        verified: formData.verificationType === 'full' || formData.verificationType === 'partial',
        comments: formData.comments || (formData.verificationType === 'reject' ? formData.rejectionReason : 'Document verified successfully')
      };

      // Add additional metadata for tracking
      const metadata = {
        verificationType: formData.verificationType,
        confidenceScore: formData.confidenceScore,
        verifiedFields: formData.verifiedFields,
        flags: formData.flags,
        requiresSecondReview: formData.requiresSecondReview,
        rejectionReason: formData.rejectionReason
      };

      console.log('Submitting document verification:', {
        documentId: formData.documentId,
        ...submitData,
        metadata
      });

      const response = await axios.put(
        `${BASE_URL}/api/documents/${formData.documentId}/verify`,
        submitData,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'X-Verification-Metadata': JSON.stringify(metadata)
          }
        }
      );

      if (response.data.success) {
        setVerifyResult(response.data.data);
        setSuccess(true);
        
        if (onVerify) {
          onVerify(response.data.data);
        }
        
        // Refresh document list
        fetchDocuments(filterStatus, filterType, documentSearch);
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to verify document');
      }
    } catch (err) {
      console.error('Error verifying document:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to verify document';
        
        // Handle specific error cases
        if (err.response.status === 400) {
          if (err.response.data.errors) {
            // Handle field validation errors
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setValidationErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 404) {
          setError('Document not found. It may have been deleted.');
        } else if (err.response.status === 409) {
          setError('Document has already been verified by another user.');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setVerifying(false);
    }
  };

  const resetForm = () => {
    setFormData({
      documentId: propDocumentId || '',
      verified: true,
      comments: '',
      verificationType: 'full',
      rejectionReason: '',
      confidenceScore: 100,
      verifiedFields: [],
      flags: [],
      requiresSecondReview: false,
      notifyCandidate: true
    });
    setSelectedDocument(null);
    setDocumentDetails(null);
    setDocumentHistory([]);
    setPreviewUrl('');
    setError('');
    setValidationErrors({});
    setVerifyResult(null);
    setSuccess(false);
    setActiveStep(0);
    setActiveTab(0);
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleDocumentSelect = (doc) => {
    setSelectedDocument(doc);
    setFormData(prev => ({
      ...prev,
      documentId: doc._id
    }));
  };

  const handleViewDocument = () => {
    if (previewUrl) {
      window.open(previewUrl, '_blank');
    }
  };

  const handleDownloadDocument = () => {
    if (previewUrl) {
      const link = document.createElement('a');
      link.href = previewUrl;
      link.download = documentDetails?.filename || 'document.pdf';
      document.body.appendChild(link);
      link.click();
      link.remove();
    }
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get file icon based on type
  const getFileIcon = (fileType) => {
    if (fileType === 'pdf') return <PdfIcon sx={{ fontSize: 40, color: '#C62828' }} />;
    if (fileType === 'image') return <ImageIcon sx={{ fontSize: 40, color: '#2E7D32' }} />;
    return <FileIcon sx={{ fontSize: 40, color: '#1976D2' }} />;
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Filters */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Filter Documents
              </Typography>

              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12, sm: 4 }}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Status</InputLabel>
                    <Select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      label="Status"
                    >
                      <MenuItem value="PENDING">Pending Verification</MenuItem>
                      <MenuItem value="VERIFIED">Verified</MenuItem>
                      <MenuItem value="REJECTED">Rejected</MenuItem>
                      <MenuItem value="all">All Status</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid size={{ xs: 12, sm: 4 }}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Document Type</InputLabel>
                    <Select
                      value={filterType}
                      onChange={(e) => setFilterType(e.target.value)}
                      label="Document Type"
                    >
                      <MenuItem value="all">All Types</MenuItem>
                      {documentTypes.map(type => (
                        <MenuItem key={type.id} value={type.id}>{type.label}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid size={{ xs: 12, sm: 4 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Search"
                    value={documentSearch}
                    onChange={(e) => setDocumentSearch(e.target.value)}
                    placeholder="Search by candidate name or document ID"
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Document List */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Document to Verify
              </Typography>

              {documentLoading ? (
                <Box sx={{ py: 4, textAlign: 'center' }}>
                  <CircularProgress size={30} />
                </Box>
              ) : documents.length === 0 ? (
                <Box sx={{ py: 4, textAlign: 'center' }}>
                  <DescriptionIcon sx={{ fontSize: 48, color: '#BDBDBD', mb: 2 }} />
                  <Typography variant="body2" color="textSecondary">
                    No documents found matching your criteria
                  </Typography>
                </Box>
              ) : (
                <Grid container spacing={1.5}>
                  {documents.map((doc) => (
                    <Grid size={{ xs: 12, sm: 6, md: 4 }} key={doc._id}>
                      <DocumentCard
                        selected={selectedDocument?._id === doc._id}
                        onClick={() => handleDocumentSelect(doc)}
                      >
                        {doc.verified && (
                          <VerifiedBadge>
                            <VerifiedIcon sx={{ fontSize: 16 }} />
                          </VerifiedBadge>
                        )}
                        <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                            {getFileIcon(doc.fileType)}
                            <Box sx={{ ml: 1, flex: 1, minWidth: 0 }}>
                              <Typography variant="subtitle2" noWrap>
                                {doc.candidateName}
                              </Typography>
                              <Typography variant="caption" color="textSecondary" noWrap>
                                {doc.documentType}
                              </Typography>
                            </Box>
                          </Box>
                          
                          <Box sx={{ mt: 1 }}>
                            <StatusChip 
                              label={doc.status} 
                              size="small"
                              status={doc.status}
                              sx={{ mr: 0.5 }}
                            />
                            <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 0.5 }}>
                              Uploaded: {formatDate(doc.uploadedAt)}
                            </Typography>
                          </Box>
                        </CardContent>
                      </DocumentCard>
                    </Grid>
                  ))}
                </Grid>
              )}
            </Paper>

            {validationErrors.documentId && (
              <FormHelperText error sx={{ mt: 1 }}>
                {validationErrors.documentId}
              </FormHelperText>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* Document Preview and Details */}
            {documentLoading ? (
              <Box sx={{ py: 4, textAlign: 'center' }}>
                <CircularProgress size={40} />
              </Box>
            ) : documentDetails ? (
              <>
                {/* Document Preview Header */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      {getFileIcon(documentDetails.fileType)}
                      <Box sx={{ ml: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 500 }}>
                          {documentDetails.filename}
                        </Typography>
                        <Typography variant="caption" color="textSecondary">
                          Uploaded by {documentDetails.uploadedBy} on {formatDate(documentDetails.uploadedAt)}
                        </Typography>
                      </Box>
                    </Box>
                    <Box>
                      <Button
                        size="small"
                        variant="outlined"
                        startIcon={<VisibilityIcon />}
                        onClick={handleViewDocument}
                        sx={{ mr: 1 }}
                      >
                        View
                      </Button>
                      <Button
                        size="small"
                        variant="outlined"
                        startIcon={<DownloadIcon />}
                        onClick={handleDownloadDocument}
                      >
                        Download
                      </Button>
                    </Box>
                  </Box>
                </Paper>

                {/* Tabs for different views */}
                <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Tabs
                    value={activeTab}
                    onChange={(e, v) => setActiveTab(v)}
                    sx={{ borderBottom: '1px solid #E0E0E0', mb: 2 }}
                  >
                    <Tab label="Document Info" icon={<DescriptionIcon />} iconPosition="start" />
                    <Tab label="Candidate Info" icon={<PersonIcon />} iconPosition="start" />
                    <Tab label="Verification History" icon={<HistoryIcon />} iconPosition="start" />
                  </Tabs>

                  {/* Document Info Tab */}
                  {activeTab === 0 && (
                    <Grid container spacing={2}>
                      <Grid size={{ xs: 12, md: 6 }}>
                        <InfoCard>
                          <CardContent>
                            <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                              Document Details
                            </Typography>
                            <DetailRow>
                              <DetailIcon><DescriptionIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Type</Typography>
                                <Typography variant="body2">{documentDetails.documentType}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><BadgeIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Document Number</Typography>
                                <Typography variant="body2">{documentDetails.documentNumber || 'N/A'}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><DateRangeIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Issue Date</Typography>
                                <Typography variant="body2">{formatDate(documentDetails.issueDate)}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><DateRangeIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Expiry Date</Typography>
                                <Typography variant="body2">{formatDate(documentDetails.expiryDate)}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><VerifiedIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Status</Typography>
                                <StatusChip 
                                  label={documentDetails.status} 
                                  size="small"
                                  status={documentDetails.status}
                                />
                              </Box>
                            </DetailRow>
                          </CardContent>
                        </InfoCard>
                      </Grid>

                      <Grid size={{ xs: 12, md: 6 }}>
                        <InfoCard>
                          <CardContent>
                            <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                              Additional Information
                            </Typography>
                            <DetailRow>
                              <DetailIcon><PersonIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Issuing Authority</Typography>
                                <Typography variant="body2">{documentDetails.issuingAuthority || 'N/A'}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><CommentIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Description</Typography>
                                <Typography variant="body2">{documentDetails.description || 'N/A'}</Typography>
                              </Box>
                            </DetailRow>
                            {documentDetails.tags && documentDetails.tags.length > 0 && (
                              <DetailRow>
                                <DetailIcon><FlagIcon /></DetailIcon>
                                <Box>
                                  <Typography variant="caption" color="textSecondary">Tags</Typography>
                                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                                    {documentDetails.tags.map(tag => (
                                      <Chip
                                        key={tag}
                                        label={tag}
                                        size="small"
                                        sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                                      />
                                    ))}
                                  </Box>
                                </Box>
                              </DetailRow>
                            )}
                            {documentDetails.remarks && (
                              <DetailRow>
                                <DetailIcon><CommentIcon /></DetailIcon>
                                <Box>
                                  <Typography variant="caption" color="textSecondary">Remarks</Typography>
                                  <Typography variant="body2">{documentDetails.remarks}</Typography>
                                </Box>
                              </DetailRow>
                            )}
                          </CardContent>
                        </InfoCard>
                      </Grid>
                    </Grid>
                  )}

                  {/* Candidate Info Tab */}
                  {activeTab === 1 && documentDetails.candidate && (
                    <Grid container spacing={2}>
                      <Grid size={{ xs: 12, md: 6 }}>
                        <InfoCard>
                          <CardContent>
                            <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                              Personal Information
                            </Typography>
                            <DetailRow>
                              <DetailIcon><PersonIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Name</Typography>
                                <Typography variant="body2">{documentDetails.candidate.name}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><EmailIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Email</Typography>
                                <Typography variant="body2">{documentDetails.candidate.email}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><PhoneIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Phone</Typography>
                                <Typography variant="body2">{documentDetails.candidate.phone}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><DateRangeIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Date of Birth</Typography>
                                <Typography variant="body2">{formatDate(documentDetails.candidate.dob)}</Typography>
                              </Box>
                            </DetailRow>
                          </CardContent>
                        </InfoCard>
                      </Grid>

                      <Grid size={{ xs: 12, md: 6 }}>
                        <InfoCard>
                          <CardContent>
                            <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 2 }}>
                              Professional Information
                            </Typography>
                            <DetailRow>
                              <DetailIcon><WorkIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Position</Typography>
                                <Typography variant="body2">{documentDetails.candidate.position}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><BusinessIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Department</Typography>
                                <Typography variant="body2">{documentDetails.candidate.department}</Typography>
                              </Box>
                            </DetailRow>
                            <DetailRow>
                              <DetailIcon><LocationIcon /></DetailIcon>
                              <Box>
                                <Typography variant="caption" color="textSecondary">Location</Typography>
                                <Typography variant="body2">{documentDetails.candidate.location}</Typography>
                              </Box>
                            </DetailRow>
                          </CardContent>
                        </InfoCard>
                      </Grid>
                    </Grid>
                  )}

                  {/* Verification History Tab */}
                  {activeTab === 2 && (
                    <Box>
                      {documentHistory.length === 0 ? (
                        <Typography variant="body2" color="textSecondary" sx={{ textAlign: 'center', py: 2 }}>
                          No verification history available
                        </Typography>
                      ) : (
                        <Timeline sx={{ p: 0, m: 0 }}>
                          {documentHistory.map((item, index) => (
                            <TimelineItem key={index}>
                              <TimelineOppositeContent color="textSecondary" sx={{ flex: 0.2 }}>
                                <Typography variant="caption">{formatDate(item.timestamp)}</Typography>
                              </TimelineOppositeContent>
                              <TimelineSeparator>
                                <TimelineDot sx={{ 
                                  backgroundColor: 
                                    item.action === 'VERIFIED' ? '#E8F5E9' :
                                    item.action === 'REJECTED' ? '#FFEBEE' : '#FFF3E0',
                                  color: 
                                    item.action === 'VERIFIED' ? '#2E7D32' :
                                    item.action === 'REJECTED' ? '#C62828' : '#E65100'
                                }}>
                                  {item.action === 'VERIFIED' ? <VerifiedIcon fontSize="small" /> :
                                   item.action === 'REJECTED' ? <ErrorIcon fontSize="small" /> :
                                   <HistoryIcon fontSize="small" />}
                                </TimelineDot>
                                {index < documentHistory.length - 1 && <TimelineConnector />}
                              </TimelineSeparator>
                              <TimelineContent sx={{ py: '12px', px: 2 }}>
                                <Typography variant="subtitle2">
                                  {item.action}
                                </Typography>
                                <Typography variant="caption" color="textSecondary">
                                  By: {item.performedBy}
                                </Typography>
                                {item.comments && (
                                  <Typography variant="caption" sx={{ display: 'block', mt: 0.5, fontStyle: 'italic' }}>
                                    "{item.comments}"
                                  </Typography>
                                )}
                              </TimelineContent>
                            </TimelineItem>
                          ))}
                        </Timeline>
                      )}
                    </Box>
                  )}
                </Paper>
              </>
            ) : (
              <Alert severity="info" sx={{ borderRadius: 1 }}>
                Please select a document to review
              </Alert>
            )}
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Verification Type */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Verification Type
              </Typography>

              <RadioGroup
                value={formData.verificationType}
                onChange={(e) => handleVerificationTypeChange(e.target.value)}
              >
                <FormControlLabel 
                  value="full" 
                  control={<Radio />} 
                  label={
                    <Box>
                      <Typography variant="body2">Full Verification</Typography>
                      <Typography variant="caption" color="textSecondary">
                        All document details are verified and match
                      </Typography>
                    </Box>
                  } 
                />
                <FormControlLabel 
                  value="partial" 
                  control={<Radio />} 
                  label={
                    <Box>
                      <Typography variant="body2">Partial Verification</Typography>
                      <Typography variant="caption" color="textSecondary">
                        Some fields are verified, others need attention
                      </Typography>
                    </Box>
                  } 
                />
                <FormControlLabel 
                  value="reject" 
                  control={<Radio />} 
                  label={
                    <Box>
                      <Typography variant="body2">Reject Document</Typography>
                      <Typography variant="caption" color="textSecondary">
                        Document is invalid or does not match requirements
                      </Typography>
                    </Box>
                  } 
                />
              </RadioGroup>
            </Paper>

            {/* Field-level Verification (for partial) */}
            {formData.verificationType === 'partial' && documentDetails && (
              <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Select Verified Fields
                </Typography>

                <Grid container spacing={1}>
                  {getVerificationFields(documentDetails.type).map((field) => (
                    <Grid size={{ xs: 12, sm: 6 }} key={field.id}>
                      <FormControlLabel
                        control={
                          <Checkbox
                            checked={formData.verifiedFields.includes(field.id)}
                            onChange={() => handleFieldToggle(field.id)}
                            size="small"
                          />
                        }
                        label={field.label}
                      />
                    </Grid>
                  ))}
                </Grid>

                {validationErrors.verifiedFields && (
                  <FormHelperText error>{validationErrors.verifiedFields}</FormHelperText>
                )}

                {/* Confidence Score */}
                <Box sx={{ mt: 2 }}>
                  <Typography variant="caption" color="textSecondary" gutterBottom>
                    Confidence Score: {formData.confidenceScore}%
                  </Typography>
                  <LinearProgress 
                    variant="determinate" 
                    value={formData.confidenceScore} 
                    sx={{ 
                      height: 8, 
                      borderRadius: 4,
                      backgroundColor: '#FFE0B2',
                      '& .MuiLinearProgress-bar': {
                        backgroundColor: formData.confidenceScore > 80 ? '#4CAF50' : 
                                        formData.confidenceScore > 50 ? '#FF9800' : '#F44336'
                      }
                    }}
                  />
                </Box>
              </Paper>
            )}

            {/* Rejection Reason */}
            {formData.verificationType === 'reject' && (
              <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Rejection Reason *
                </Typography>

                <TextField
                  fullWidth
                  size="small"
                  name="rejectionReason"
                  value={formData.rejectionReason}
                  onChange={handleChange}
                  multiline
                  rows={3}
                  placeholder="Please provide detailed reason for rejection..."
                  error={!!validationErrors.rejectionReason}
                  helperText={validationErrors.rejectionReason}
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                />

                <FormControlLabel
                  control={
                    <Checkbox
                      name="requiresSecondReview"
                      checked={formData.requiresSecondReview}
                      onChange={handleChange}
                      size="small"
                    />
                  }
                  label="Requires second review"
                  sx={{ mt: 2 }}
                />
              </Paper>
            )}

            {/* Comments */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Comments {formData.verificationType !== 'full' && '*'}
              </Typography>

              <TextField
                fullWidth
                size="small"
                name="comments"
                value={formData.comments}
                onChange={handleChange}
                multiline
                rows={3}
                placeholder={formData.verificationType === 'full' 
                  ? "Add verification comments (optional)" 
                  : "Please provide detailed comments about the verification"
                }
                error={!!validationErrors.comments}
                helperText={validationErrors.comments}
                sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
              />
            </Paper>

            {/* Additional Options */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Additional Options
              </Typography>

              <FormControlLabel
                control={
                  <Checkbox
                    name="notifyCandidate"
                    checked={formData.notifyCandidate}
                    onChange={handleChange}
                    size="small"
                  />
                }
                label="Notify candidate about verification status"
              />

              <FormControlLabel
                control={
                  <Checkbox
                    name="requiresSecondReview"
                    checked={formData.requiresSecondReview}
                    onChange={handleChange}
                    size="small"
                  />
                }
                label="Requires second review/approval"
              />
            </Paper>
          </Stack>
        );

      case 3:
        return (
          <Stack spacing={2}>
            {/* Verification Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Verification Summary
              </Typography>

              <Grid container spacing={2}>
                {/* Document Info */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Document
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      {documentDetails && getFileIcon(documentDetails.fileType)}
                      <Box sx={{ ml: 1 }}>
                        <Typography variant="body2">{documentDetails?.filename}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          {documentDetails?.documentType} • {documentDetails?.candidateName}
                        </Typography>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>

                {/* Verification Decision */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Verification Decision
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      {formData.verificationType === 'full' && (
                        <>
                          <VerifiedIcon sx={{ color: '#4CAF50' }} />
                          <Typography variant="body2">Full Verification - Document approved</Typography>
                        </>
                      )}
                      {formData.verificationType === 'partial' && (
                        <>
                          <GppMaybeIcon sx={{ color: '#FF9800' }} />
                          <Typography variant="body2">
                            Partial Verification - {formData.confidenceScore}% confidence
                          </Typography>
                        </>
                      )}
                      {formData.verificationType === 'reject' && (
                        <>
                          <GppBadIcon sx={{ color: '#F44336' }} />
                          <Typography variant="body2">Document Rejected</Typography>
                        </>
                      )}
                    </Box>
                    
                    {formData.verificationType === 'partial' && formData.verifiedFields.length > 0 && (
                      <Box sx={{ mt: 1 }}>
                        <Typography variant="caption" color="textSecondary">Verified Fields:</Typography>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                          {formData.verifiedFields.map(field => (
                            <Chip
                              key={field}
                              label={field.replace(/([A-Z])/g, ' $1').trim()}
                              size="small"
                              sx={{ backgroundColor: '#E8F5E9', color: '#2E7D32' }}
                            />
                          ))}
                        </Box>
                      </Box>
                    )}
                  </Paper>
                </Grid>

                {/* Comments */}
                {formData.comments && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Comments
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.comments}</Typography>
                    </Paper>
                  </Grid>
                )}

                {/* Rejection Reason */}
                {formData.verificationType === 'reject' && formData.rejectionReason && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Rejection Reason
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#FFEBEE', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.rejectionReason}</Typography>
                    </Paper>
                  </Grid>
                )}

                {/* Additional Flags */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Additional Settings
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    {formData.notifyCandidate && (
                      <Chip
                        icon={<EmailIcon />}
                        label="Notify Candidate"
                        size="small"
                        sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                      />
                    )}
                    {formData.requiresSecondReview && (
                      <Chip
                        icon={<VerifiedUserIcon />}
                        label="Requires Second Review"
                        size="small"
                        sx={{ backgroundColor: '#FFF3E0', color: '#E65100' }}
                      />
                    )}
                  </Box>
                </Grid>
              </Grid>
            </Paper>

            {/* Legal/Compliance Notice */}
            <Alert severity="info" sx={{ borderRadius: 1 }} icon={<GppGoodIcon />}>
              <Typography variant="body2">
                <strong>Verification Responsibility:</strong> By verifying this document, you confirm that 
                you have reviewed the document and it meets the required standards. This action will be 
                logged and attributed to your account.
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {Object.keys(validationErrors).length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Verify Document
        </Typography>
        {!verifying && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            <Stepper
              activeStep={activeStep}
              alternativeLabel
              connector={<ColorConnector />}
              sx={{ mb: 2, mt: 1 }}
            >
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>
                    <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || verifying}
              size="small"
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={verifying}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={verifying || !formData.documentId}
                  size="small"
                  startIcon={verifying ? <CircularProgress size={16} color="inherit" /> : <VerifiedIcon />}
                  sx={{
                    backgroundColor: formData.verificationType === 'full' ? '#2E7D32' :
                                   formData.verificationType === 'partial' ? '#FF9800' : '#C62828',
                    '&:hover': { 
                      backgroundColor: formData.verificationType === 'full' ? '#1B5E20' :
                                      formData.verificationType === 'partial' ? '#F57C00' : '#B71C1C'
                    }
                  }}
                >
                  {verifying ? 'Verifying...' : 
                   formData.verificationType === 'full' ? 'Verify & Approve' :
                   formData.verificationType === 'partial' ? 'Submit Partial Verification' : 'Reject Document'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={verifying}
                  size="small"
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <VerifiedIcon sx={{ fontSize: 64, color: '#4CAF50', mb: 2 }} />
            <Typography variant="h5" sx={{ mb: 2, color: '#101010', fontWeight: 600 }}>
              Document {verifyResult?.status === 'VERIFIED' ? 'Verified' : 'Processed'} Successfully!
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              {verifyResult?.comments}
            </Typography>
            
            {verifyResult && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', mb: 3, maxWidth: 400, mx: 'auto' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1 }}>
                  Verification Details
                </Typography>
                <Typography variant="body2">
                  <strong>Document ID:</strong> {verifyResult.documentId}
                </Typography>
                <Typography variant="body2">
                  <strong>Status:</strong> {verifyResult.status}
                </Typography>
                <Typography variant="body2">
                  <strong>Verified At:</strong> {formatDate(verifyResult.verifiedAt)}
                </Typography>
              </Paper>
            )}

            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  resetForm();
                  setSuccess(false);
                }}
                startIcon={<VerifiedIcon />}
              >
                Verify Another
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default VerifyDoc;