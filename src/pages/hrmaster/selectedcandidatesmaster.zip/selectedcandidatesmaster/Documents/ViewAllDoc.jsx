import React, { useState, useEffect } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  Badge,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Tables
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  
  // Progress
  LinearProgress,
  
  // Tabs
  Tab,
  Tabs,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction,
  
  // Menu
  Menu,
  MenuItem,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  Autocomplete,
  
} from '@mui/material';

// Icons - FIXED: Changed HourglassEmpty to HourglassIcon to match usage
import {
  Visibility as VisibilityIcon,
  Download as DownloadIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Share as ShareIcon,
  Print as PrintIcon,
  Refresh as RefreshIcon,
  Search as SearchIcon,
  FilterList as FilterIcon,
  Sort as SortIcon,
  MoreVert as MoreIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Verified as VerifiedIcon,
  Pending as PendingIcon,
  HourglassEmpty as HourglassIcon,  // Keep as HourglassIcon for usage
  Description as DescriptionIcon,
  PictureAsPdf as PdfIcon,
  Image as ImageIcon,
  InsertDriveFile as FileIcon,
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarTodayIcon,
  Folder as FolderIcon,
  CloudUpload as CloudUploadIcon,
  CloudDownload as CloudDownloadIcon,
  DeleteSweep as DeleteSweepIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  Close as CloseIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';

// Styled components
const StatusChip = styled(Chip)(({ theme, status }) => {
  const colors = {
    VERIFIED: { bg: '#E8F5E9', color: '#2E7D32' },
    PENDING: { bg: '#FFF3E0', color: '#E65100' },
    REJECTED: { bg: '#FFEBEE', color: '#C62828' },
    EXPIRED: { bg: '#F5F5F5', color: '#9E9E9E' },
    UPLOADED: { bg: '#E3F2FD', color: '#1976D2' },
    PROCESSING: { bg: '#F3E5F5', color: '#7B1FA2' }
  };
  const color = colors[status] || colors.PENDING;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    fontWeight: 500,
    fontSize: '0.75rem',
    height: '24px'
  };
});

const DocumentCard = styled(Card)(({ theme }) => ({
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  transition: 'all 0.2s',
  position: 'relative',
  overflow: 'visible',
  '&:hover': {
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
    transform: 'translateY(-2px)'
  }
}));

const VerifiedBadge = styled(Box)(({ theme }) => ({
  position: 'absolute',
  top: -10,
  right: -10,
  backgroundColor: '#4CAF50',
  color: 'white',
  borderRadius: '50%',
  width: 24,
  height: 24,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 1
}));

const StatsCard = styled(Card)(({ theme, color }) => ({
  backgroundColor: color || '#FFFFFF',
  borderRadius: 1,
  border: '1px solid #E0E0E0',
  '& .MuiCardContent-root': {
    padding: '16px !important'
  }
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontWeight: 500,
  '&.header': {
    backgroundColor: '#1976D2',
    color: 'white',
    fontWeight: 600
  }
}));

const ViewAllDoc = ({ open, onClose, candidateId: propCandidateId, onDocumentAction }) => {
  const [activeTab, setActiveTab] = useState(0);
  const [formData, setFormData] = useState({
    candidateId: propCandidateId || '',
    documentType: 'all',
    status: 'all',
    search: '',
    sortBy: 'uploadedAt',
    sortOrder: 'desc',
    page: 1,
    limit: 20
  });

  // Data states
  const [documents, setDocuments] = useState([]);
  const [filteredDocuments, setFilteredDocuments] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [documentStats, setDocumentStats] = useState({
    total: 0,
    verified: 0,
    pending: 0,
    rejected: 0,
    expired: 0
  });

  // Loading states
  const [loading, setLoading] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Pagination
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [totalPages, setTotalPages] = useState(0);

  // Menu states
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [sortAnchorEl, setSortAnchorEl] = useState(null);

  // Preview dialog
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');

  // Delete confirmation
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);

  // Candidate dropdown for filtering
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState('');
  const [candidatePage, setCandidatePage] = useState(1);
  const [candidateTotalPages, setCandidateTotalPages] = useState(1);
  const [candidateInputValue, setCandidateInputValue] = useState('');

  // Document types for filtering
  const documentTypes = [
    { id: 'all', label: 'All Types' },
    { id: 'aadhar', label: 'Aadhar Card' },
    { id: 'pan', label: 'PAN Card' },
    { id: 'voter', label: 'Voter ID' },
    { id: 'passport', label: 'Passport' },
    { id: 'driving', label: 'Driving License' },
    { id: 'ssc', label: 'SSC Certificate' },
    { id: 'hsc', label: 'HSC Certificate' },
    { id: 'graduation', label: 'Graduation Degree' },
    { id: 'postgraduation', label: 'Post Graduation' },
    { id: 'diploma', label: 'Diploma' },
    { id: 'experience', label: 'Experience Certificate' },
    { id: 'relieving', label: 'Relieving Letter' },
    { id: 'offer', label: 'Offer Letter' },
    { id: 'salary', label: 'Salary Slips' },
    { id: 'form16', label: 'Form 16' },
    { id: 'bank', label: 'Bank Details' },
    { id: 'photo', label: 'Photograph' },
    { id: 'signature', label: 'Signature' },
    { id: 'other', label: 'Other' }
  ];

  const statusTypes = [
    { id: 'all', label: 'All Status' },
    { id: 'VERIFIED', label: 'Verified', icon: <VerifiedIcon />, color: '#2E7D32' },
    { id: 'PENDING', label: 'Pending', icon: <PendingIcon />, color: '#E65100' },
    { id: 'REJECTED', label: 'Rejected', icon: <ErrorIcon />, color: '#C62828' },
    { id: 'EXPIRED', label: 'Expired', icon: <WarningIcon />, color: '#9E9E9E' },
    { id: 'UPLOADED', label: 'Uploaded', icon: <CloudUploadIcon />, color: '#1976D2' }
  ];

  const sortOptions = [
    { id: 'uploadedAt', label: 'Upload Date' },
    { id: 'documentName', label: 'Document Name' },
    { id: 'documentType', label: 'Document Type' },
    { id: 'status', label: 'Status' },
    { id: 'candidateName', label: 'Candidate Name' },
    { id: 'expiryDate', label: 'Expiry Date' }
  ];

  // Fetch candidates for filtering
  const fetchCandidates = async (search = '', page = 1) => {
    setCandidateLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setCandidates(response.data.data || []);
        } else {
          setCandidates(prev => [...prev, ...(response.data.data || [])]);
        }
        setCandidateTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
    } finally {
      setCandidateLoading(false);
    }
  };

  // Fetch documents
  const fetchDocuments = async () => {
    setLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('token');
      const params = {
        page: formData.page,
        limit: formData.limit,
        sortBy: formData.sortBy,
        sortOrder: formData.sortOrder
      };

      // Add filters
      if (formData.candidateId) {
        params.candidateId = formData.candidateId;
      }
      if (formData.documentType && formData.documentType !== 'all') {
        params.type = formData.documentType;
      }
      if (formData.status && formData.status !== 'all') {
        params.status = formData.status;
      }
      if (formData.search) {
        params.search = formData.search;
      }

      console.log('Fetching documents with params:', params);

      const response = await axios.get(`${BASE_URL}/api/documents`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: params
      });

      if (response.data.success) {
        setDocuments(response.data.data || []);
        setTotalCount(response.data.pagination?.total || 0);
        setTotalPages(response.data.pagination?.pages || 0);
        
        // Apply client-side filtering if needed
        filterDocuments(response.data.data || []);
      } else {
        setError(response.data.message || 'Failed to fetch documents');
      }
    } catch (err) {
      console.error('Error fetching documents:', err);
      if (err.response) {
        setError(err.response.data?.message || 'Failed to load documents');
      } else {
        setError('Network error. Please check your connection.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Fetch document statistics
  const fetchDocumentStats = async () => {
    setStatsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = {};
      
      if (formData.candidateId) {
        params.candidateId = formData.candidateId;
      }

      const response = await axios.get(`${BASE_URL}/api/documents/stats`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: params
      });

      if (response.data.success) {
        setDocumentStats(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching document stats:', err);
    } finally {
      setStatsLoading(false);
    }
  };

  // Apply client-side filtering and sorting
  const filterDocuments = (docs) => {
    let filtered = [...docs];

    // Apply search filter (client-side)
    if (formData.search && !formData.candidateId) {
      const searchLower = formData.search.toLowerCase();
      filtered = filtered.filter(doc => 
        doc.candidateName?.toLowerCase().includes(searchLower) ||
        doc.documentName?.toLowerCase().includes(searchLower) ||
        doc.documentNumber?.toLowerCase().includes(searchLower)
      );
    }

    setFilteredDocuments(filtered);
  };

  // Handle candidate scroll load more
  const handleCandidateScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (candidatePage < candidateTotalPages && !candidateLoading) {
        const nextPage = candidatePage + 1;
        setCandidatePage(nextPage);
        fetchCandidates(candidateSearch, nextPage);
      }
    }
  };

  // Load candidates when dropdown opens
  useEffect(() => {
    if (candidateOpen) {
      fetchCandidates(candidateSearch, 1);
    }
  }, [candidateOpen]);

  // Search candidates with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (candidateOpen) {
        setCandidatePage(1);
        fetchCandidates(candidateSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [candidateSearch, candidateOpen]);

  // Initial load
  useEffect(() => {
    if (open) {
      fetchDocuments();
      fetchDocumentStats();
    }
  }, [open, formData.candidateId, formData.documentType, formData.status, formData.page, formData.sortBy, formData.sortOrder]);

  // Handle search with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (formData.search) {
        fetchDocuments();
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [formData.search]);

  const handleChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value,
      page: 1 // Reset to first page on filter change
    }));
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
    // Update status filter based on tab
    const statusMap = {
      0: 'all',
      1: 'PENDING',
      2: 'VERIFIED',
      3: 'REJECTED'
    };
    handleChange('status', statusMap[newValue] || 'all');
  };

  const handleRefresh = () => {
    fetchDocuments();
    fetchDocumentStats();
    setSuccessMessage('Documents refreshed');
    setSuccess(true);
    setTimeout(() => setSuccess(false), 3000);
  };

  const handleMenuOpen = (event, document) => {
    setAnchorEl(event.currentTarget);
    setSelectedDocument(document);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedDocument(null);
  };

  const handleFilterClick = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setFilterAnchorEl(null);
  };

  const handleSortClick = (event) => {
    setSortAnchorEl(event.currentTarget);
  };

  const handleSortClose = () => {
    setSortAnchorEl(null);
  };

  const handleSortSelect = (sortBy) => {
    const newOrder = formData.sortBy === sortBy && formData.sortOrder === 'asc' ? 'desc' : 'asc';
    setFormData(prev => ({
      ...prev,
      sortBy: sortBy,
      sortOrder: newOrder
    }));
    handleSortClose();
  };

  const handleViewDocument = async (document) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents/${document._id}/download`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      setPreviewUrl(url);
      setPreviewDocument(document);
      setPreviewOpen(true);
    } catch (err) {
      console.error('Error viewing document:', err);
      setError('Failed to load document preview');
    }
    handleMenuClose();
  };

  const handleDownloadDocument = async (document) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/documents/${document._id}/download`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.download = document.filename || 'document.pdf';
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      setSuccessMessage('Document downloaded successfully');
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Error downloading document:', err);
      setError('Failed to download document');
    }
    handleMenuClose();
  };

  const handleDeleteClick = (document) => {
    setDocumentToDelete(document);
    setDeleteDialogOpen(true);
    handleMenuClose();
  };

  const handleDeleteConfirm = async () => {
    if (!documentToDelete) return;

    try {
      const token = localStorage.getItem('token');
      const response = await axios.delete(`${BASE_URL}/api/documents/${documentToDelete._id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.data.success) {
        setSuccessMessage('Document deleted successfully');
        setSuccess(true);
        fetchDocuments(); // Refresh list
        fetchDocumentStats(); // Refresh stats
      } else {
        setError(response.data.message || 'Failed to delete document');
      }
    } catch (err) {
      console.error('Error deleting document:', err);
      setError(err.response?.data?.message || 'Failed to delete document');
    } finally {
      setDeleteDialogOpen(false);
      setDocumentToDelete(null);
      setTimeout(() => setSuccess(false), 3000);
    }
  };

  const handleVerifyDocument = (document) => {
    // Open verify dialog or navigate to verify page
    if (onDocumentAction) {
      onDocumentAction('verify', document);
    }
    handleMenuClose();
  };

  const handleShareDocument = (document) => {
    // Open share dialog
    if (onDocumentAction) {
      onDocumentAction('share', document);
    }
    handleMenuClose();
  };

  const handlePrintDocument = (document) => {
    handleViewDocument(document);
    // Print will be handled in preview
    handleMenuClose();
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
    setFormData(prev => ({ ...prev, page: newPage + 1 }));
  };

  const handleRowsPerPageChange = (event) => {
    const newLimit = parseInt(event.target.value, 10);
    setRowsPerPage(newLimit);
    setFormData(prev => ({ ...prev, limit: newLimit, page: 1 }));
    setPage(0);
  };

  const resetFilters = () => {
    setFormData({
      candidateId: propCandidateId || '',
      documentType: 'all',
      status: 'all',
      search: '',
      sortBy: 'uploadedAt',
      sortOrder: 'desc',
      page: 1,
      limit: 20
    });
    setActiveTab(0);
    setSelectedCandidate(null);
  };

  const handleClose = () => {
    resetFilters();
    onClose();
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get file icon based on type
  const getFileIcon = (fileType) => {
    if (fileType === 'pdf') return <PdfIcon sx={{ fontSize: 40, color: '#C62828' }} />;
    if (fileType === 'image') return <ImageIcon sx={{ fontSize: 40, color: '#2E7D32' }} />;
    return <FileIcon sx={{ fontSize: 40, color: '#1976D2' }} />;
  };

  // Get status icon - FIXED: Changed HourglassEmptyIcon to HourglassIcon
  const getStatusIcon = (status) => {
    switch(status) {
      case 'VERIFIED':
        return <VerifiedIcon sx={{ fontSize: 16 }} />;
      case 'REJECTED':
        return <ErrorIcon sx={{ fontSize: 16 }} />;
      case 'EXPIRED':
        return <WarningIcon sx={{ fontSize: 16 }} />;
      case 'PENDING':
        return <HourglassIcon sx={{ fontSize: 16 }} />;  // Changed from HourglassEmptyIcon to HourglassIcon
      default:
        return <InfoIcon sx={{ fontSize: 16 }} />;
    }
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 1.5,
            maxHeight: '95vh',
            overflow: 'auto'
          }
        }}
      >
        <DialogTitle sx={{
          borderBottom: '1px solid #E0E0E0',
          py: 1.5,
          px: 2,
          backgroundColor: '#F8FAFC',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
            Document Management
          </Typography>
          <Box>
            <IconButton size="small" onClick={handleRefresh} sx={{ mr: 1, color: '#666' }}>
              <RefreshIcon fontSize="small" />
            </IconButton>
            <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Box>
        </DialogTitle>

        <DialogContent sx={{ p: 2, overflow: 'auto' }}>
          <Stack spacing={2}>
            {/* Stats Cards */}
            <Grid container spacing={1.5}>
              <Grid item xs={12} sm={6} md={2.4}>
                <StatsCard>
                  <CardContent>
                    <Typography variant="caption" color="textSecondary" gutterBottom>
                      Total Documents
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600 }}>
                      {statsLoading ? <CircularProgress size={20} /> : documentStats.total || 0}
                    </Typography>
                  </CardContent>
                </StatsCard>
              </Grid>
              <Grid item xs={12} sm={6} md={2.4}>
                <StatsCard sx={{ backgroundColor: '#E8F5E9' }}>
                  <CardContent>
                    <Typography variant="caption" color="textSecondary" gutterBottom>
                      Verified
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600, color: '#2E7D32' }}>
                      {statsLoading ? <CircularProgress size={20} /> : documentStats.verified || 0}
                    </Typography>
                  </CardContent>
                </StatsCard>
              </Grid>
              <Grid item xs={12} sm={6} md={2.4}>
                <StatsCard sx={{ backgroundColor: '#FFF3E0' }}>
                  <CardContent>
                    <Typography variant="caption" color="textSecondary" gutterBottom>
                      Pending
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600, color: '#E65100' }}>
                      {statsLoading ? <CircularProgress size={20} /> : documentStats.pending || 0}
                    </Typography>
                  </CardContent>
                </StatsCard>
              </Grid>
              <Grid item xs={12} sm={6} md={2.4}>
                <StatsCard sx={{ backgroundColor: '#FFEBEE' }}>
                  <CardContent>
                    <Typography variant="caption" color="textSecondary" gutterBottom>
                      Rejected
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600, color: '#C62828' }}>
                      {statsLoading ? <CircularProgress size={20} /> : documentStats.rejected || 0}
                    </Typography>
                  </CardContent>
                </StatsCard>
              </Grid>
              <Grid item xs={12} sm={6} md={2.4}>
                <StatsCard sx={{ backgroundColor: '#F5F5F5' }}>
                  <CardContent>
                    <Typography variant="caption" color="textSecondary" gutterBottom>
                      Expired
                    </Typography>
                    <Typography variant="h5" sx={{ fontWeight: 600, color: '#9E9E9E' }}>
                      {statsLoading ? <CircularProgress size={20} /> : documentStats.expired || 0}
                    </Typography>
                  </CardContent>
                </StatsCard>
              </Grid>
            </Grid>

            {/* Filters Bar */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Grid container spacing={1.5} alignItems="center">
                {/* Candidate Filter */}
                <Grid item xs={12} sm={6} md={3}>
                  <Autocomplete
                    size="small"
                    id="candidate-filter"
                    open={candidateOpen}
                    onOpen={() => setCandidateOpen(true)}
                    onClose={() => setCandidateOpen(false)}
                    options={candidates}
                    loading={candidateLoading}
                    value={formData.candidateId ? candidates.find(c => c._id === formData.candidateId) || null : null}
                    onChange={(event, newValue) => {
                      handleChange('candidateId', newValue?._id || '');
                      setSelectedCandidate(newValue);
                    }}
                    inputValue={candidateInputValue}
                    onInputChange={(event, newInputValue) => {
                      setCandidateInputValue(newInputValue);
                      setCandidateSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.name || ''}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Filter by Candidate"
                        placeholder="Select candidate"
                        size="small"
                        InputProps={{
                          ...params.InputProps,
                          startAdornment: (
                            <>
                              <PersonIcon sx={{ fontSize: 16, color: '#666', mr: 0.5 }} />
                              {params.InputProps.startAdornment}
                            </>
                          ),
                          endAdornment: (
                            <>
                              {candidateLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.name}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.email}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleCandidateScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>

                {/* Document Type Filter */}
                <Grid item xs={12} sm={6} md={2}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Document Type</InputLabel>
                    <Select
                      value={formData.documentType}
                      onChange={(e) => handleChange('documentType', e.target.value)}
                      label="Document Type"
                      startAdornment={<DescriptionIcon sx={{ fontSize: 16, color: '#666', mr: 1 }} />}
                    >
                      {documentTypes.map(type => (
                        <MenuItem key={type.id} value={type.id}>{type.label}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>

                {/* Status Filter - Hidden when tabs are used */}
                {activeTab === 0 && (
                  <Grid item xs={12} sm={6} md={2}>
                    <FormControl fullWidth size="small">
                      <InputLabel>Status</InputLabel>
                      <Select
                        value={formData.status}
                        onChange={(e) => handleChange('status', e.target.value)}
                        label="Status"
                      >
                        {statusTypes.map(status => (
                          <MenuItem key={status.id} value={status.id}>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              {status.icon && <Box sx={{ mr: 1, color: status.color }}>{status.icon}</Box>}
                              {status.label}
                            </Box>
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Grid>
                )}

                {/* Search */}
                <Grid item xs={12} sm={6} md={activeTab === 0 ? 3 : 5}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Search"
                    value={formData.search}
                    onChange={(e) => handleChange('search', e.target.value)}
                    placeholder="Search by document name, number..."
                    InputProps={{
                      startAdornment: <SearchIcon sx={{ fontSize: 16, color: '#666', mr: 0.5 }} />
                    }}
                  />
                </Grid>

                {/* Action Buttons */}
                <Grid item xs={12} sm={12} md={2}>
                  <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
                    <Button
                      size="small"
                      variant="outlined"
                      onClick={handleFilterClick}
                      startIcon={<FilterIcon />}
                    >
                      Filter
                    </Button>
                    <Button
                      size="small"
                      variant="outlined"
                      onClick={handleSortClick}
                      startIcon={<SortIcon />}
                    >
                      Sort
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </Paper>

            {/* Status Tabs */}
            <Paper sx={{ backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Tabs
                value={activeTab}
                onChange={handleTabChange}
                variant="fullWidth"
                sx={{
                  '& .MuiTab-root': {
                    minHeight: 48,
                    fontWeight: 500
                  }
                }}
              >
                <Tab 
                  label="All Documents" 
                  icon={<DescriptionIcon />} 
                  iconPosition="start"
                />
                <Tab 
                  label="Pending" 
                  icon={<HourglassIcon />}  // Changed from HourglassEmptyIcon to HourglassIcon
                  iconPosition="start"
                  sx={{ color: '#E65100' }}
                />
                <Tab 
                  label="Verified" 
                  icon={<VerifiedIcon />} 
                  iconPosition="start"
                  sx={{ color: '#2E7D32' }}
                />
                <Tab 
                  label="Rejected" 
                  icon={<ErrorIcon />} 
                  iconPosition="start"
                  sx={{ color: '#C62828' }}
                />
              </Tabs>
            </Paper>

            {/* Documents Table */}
            <Paper sx={{ backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              {loading ? (
                <Box sx={{ p: 4, textAlign: 'center' }}>
                  <CircularProgress size={40} />
                </Box>
              ) : error ? (
                <Box sx={{ p: 4, textAlign: 'center' }}>
                  <Alert severity="error" sx={{ borderRadius: 1 }}>
                    {error}
                  </Alert>
                </Box>
              ) : filteredDocuments.length === 0 ? (
                <Box sx={{ p: 4, textAlign: 'center' }}>
                  <DescriptionIcon sx={{ fontSize: 48, color: '#BDBDBD', mb: 2 }} />
                  <Typography variant="body1" color="textSecondary" gutterBottom>
                    No documents found
                  </Typography>
                  <Typography variant="caption" color="textSecondary">
                    Try adjusting your filters or upload new documents
                  </Typography>
                </Box>
              ) : (
                <>
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <StyledTableCell className="header">Document</StyledTableCell>
                          <StyledTableCell className="header">Candidate</StyledTableCell>
                          <StyledTableCell className="header">Type</StyledTableCell>
                          <StyledTableCell className="header">Uploaded</StyledTableCell>
                          <StyledTableCell className="header">Expiry</StyledTableCell>
                          <StyledTableCell className="header">Status</StyledTableCell>
                          <StyledTableCell className="header" align="center">Actions</StyledTableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {filteredDocuments
                          .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                          .map((doc) => (
                            <TableRow key={doc._id} hover>
                              <TableCell>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  {getFileIcon(doc.fileType)}
                                  <Box sx={{ ml: 1 }}>
                                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                      {doc.documentName || doc.filename}
                                    </Typography>
                                    <Typography variant="caption" color="textSecondary">
                                      {doc.documentNumber || 'No number'}
                                    </Typography>
                                  </Box>
                                </Box>
                              </TableCell>
                              <TableCell>
                                <Typography variant="body2">{doc.candidateName}</Typography>
                                <Typography variant="caption" color="textSecondary">
                                  {doc.candidateEmail}
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <Typography variant="body2">
                                  {documentTypes.find(t => t.id === doc.documentType)?.label || doc.documentType}
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <Typography variant="body2">{formatDate(doc.uploadedAt)}</Typography>
                                <Typography variant="caption" color="textSecondary">
                                  by {doc.uploadedBy}
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <Typography variant="body2" sx={{
                                  color: doc.expiryDate && new Date(doc.expiryDate) < new Date() ? '#C62828' : 'inherit'
                                }}>
                                  {formatDate(doc.expiryDate)}
                                </Typography>
                              </TableCell>
                              <TableCell>
                                <StatusChip
                                  label={doc.status}
                                  status={doc.status}
                                  size="small"
                                  icon={getStatusIcon(doc.status)}
                                />
                              </TableCell>
                              <TableCell align="center">
                                <IconButton
                                  size="small"
                                  onClick={(e) => handleMenuOpen(e, doc)}
                                  sx={{ color: '#666' }}
                                >
                                  <MoreIcon fontSize="small" />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </TableContainer>

                  <TablePagination
                    rowsPerPageOptions={[5, 10, 25, 50]}
                    component="div"
                    count={filteredDocuments.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handlePageChange}
                    onRowsPerPageChange={handleRowsPerPageChange}
                  />
                </>
              )}
            </Paper>

            {/* Info message about empty response */}
            {filteredDocuments.length === 0 && !loading && !error && (
              <Alert severity="info" sx={{ borderRadius: 1 }}>
                <Typography variant="body2">
                  No documents found. The API returned an empty array. This could mean:
                </Typography>
                <List dense disablePadding sx={{ mt: 1 }}>
                  <ListItem sx={{ py: 0 }}>
                    <ListItemIcon sx={{ minWidth: 24 }}>
                      <CheckCircleOutlineIcon sx={{ fontSize: 16, color: '#1976D2' }} />
                    </ListItemIcon>
                    <ListItemText primary="No documents have been uploaded yet" />
                  </ListItem>
                  <ListItem sx={{ py: 0 }}>
                    <ListItemIcon sx={{ minWidth: 24 }}>
                      <CheckCircleOutlineIcon sx={{ fontSize: 16, color: '#1976D2' }} />
                    </ListItemIcon>
                    <ListItemText primary="Filters are too restrictive" />
                  </ListItem>
                  <ListItem sx={{ py: 0 }}>
                    <ListItemIcon sx={{ minWidth: 24 }}>
                      <CheckCircleOutlineIcon sx={{ fontSize: 16, color: '#1976D2' }} />
                    </ListItemIcon>
                    <ListItemText primary="The selected candidate has no documents" />
                  </ListItem>
                </List>
              </Alert>
            )}
          </Stack>
        </DialogContent>

        <DialogActions sx={{
          px: 2,
          py: 1.5,
          borderTop: '1px solid #E0E0E0',
          backgroundColor: '#F8FAFC',
          justifyContent: 'space-between'
        }}>
          <Typography variant="caption" color="textSecondary">
            Total: {totalCount} documents • Page {formData.page} of {totalPages}
          </Typography>
          <Button
            variant="contained"
            onClick={handleClose}
            size="small"
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Document Actions Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => handleViewDocument(selectedDocument)}>
          <ListItemIcon>
            <VisibilityIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>View</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handleDownloadDocument(selectedDocument)}>
          <ListItemIcon>
            <DownloadIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Download</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handleVerifyDocument(selectedDocument)}>
          <ListItemIcon>
            <VerifiedIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Verify</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handleShareDocument(selectedDocument)}>
          <ListItemIcon>
            <ShareIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Share</ListItemText>
        </MenuItem>
        <MenuItem onClick={() => handlePrintDocument(selectedDocument)}>
          <ListItemIcon>
            <PrintIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Print</ListItemText>
        </MenuItem>
        <Divider />
        <MenuItem onClick={() => handleDeleteClick(selectedDocument)} sx={{ color: '#C62828' }}>
          <ListItemIcon>
            <DeleteIcon fontSize="small" sx={{ color: '#C62828' }} />
          </ListItemIcon>
          <ListItemText>Delete</ListItemText>
        </MenuItem>
      </Menu>

      {/* Filter Menu */}
      <Menu
        anchorEl={filterAnchorEl}
        open={Boolean(filterAnchorEl)}
        onClose={handleFilterClose}
      >
        <MenuItem onClick={() => { resetFilters(); handleFilterClose(); }}>
          <ListItemText>Clear All Filters</ListItemText>
        </MenuItem>
        <Divider />
        <MenuItem disabled>
          <ListItemText primary="Filter by Date Range" secondary="Coming soon" />
        </MenuItem>
        <MenuItem disabled>
          <ListItemText primary="Filter by Uploader" secondary="Coming soon" />
        </MenuItem>
      </Menu>

      {/* Sort Menu */}
      <Menu
        anchorEl={sortAnchorEl}
        open={Boolean(sortAnchorEl)}
        onClose={handleSortClose}
      >
        {sortOptions.map(option => (
          <MenuItem 
            key={option.id} 
            onClick={() => handleSortSelect(option.id)}
            selected={formData.sortBy === option.id}
          >
            <ListItemText>
              {option.label}
              {formData.sortBy === option.id && (
                <Typography component="span" variant="caption" sx={{ ml: 1, color: '#1976D2' }}>
                  ({formData.sortOrder === 'asc' ? '↑' : '↓'})
                </Typography>
              )}
            </ListItemText>
          </MenuItem>
        ))}
      </Menu>

      {/* Document Preview Dialog */}
      <Dialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle sx={{ 
          borderBottom: '1px solid #E0E0E0',
          py: 1.5,
          px: 2,
          backgroundColor: '#F8FAFC',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <Typography variant="subtitle2">
            {previewDocument?.documentName || previewDocument?.filename}
          </Typography>
          <IconButton size="small" onClick={() => setPreviewOpen(false)}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ p: 2, minHeight: 500 }}>
          {previewDocument?.fileType === 'pdf' ? (
            <iframe
              src={previewUrl}
              style={{ width: '100%', height: '70vh', border: 'none' }}
              title="Document Preview"
            />
          ) : previewDocument?.fileType === 'image' ? (
            <Box sx={{ textAlign: 'center' }}>
              <img
                src={previewUrl}
                alt="Document Preview"
                style={{ maxWidth: '100%', maxHeight: '70vh' }}
              />
            </Box>
          ) : (
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <DescriptionIcon sx={{ fontSize: 64, color: '#BDBDBD', mb: 2 }} />
              <Typography variant="body1" color="textSecondary">
                Preview not available for this file type
              </Typography>
              <Button
                variant="contained"
                size="small"
                onClick={() => handleDownloadDocument(previewDocument)}
                sx={{ mt: 2 }}
              >
                Download to View
              </Button>
            </Box>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#C62828' }}>
            Delete Document
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2}>
            <Typography variant="body2">
              Are you sure you want to delete this document?
            </Typography>
            {documentToDelete && (
              <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC' }}>
                <Typography variant="body2">
                  <strong>Document:</strong> {documentToDelete.documentName || documentToDelete.filename}
                </Typography>
                <Typography variant="body2">
                  <strong>Candidate:</strong> {documentToDelete.candidateName}
                </Typography>
                <Typography variant="body2">
                  <strong>Type:</strong> {documentToDelete.documentType}
                </Typography>
              </Paper>
            )}
            <Alert severity="warning" sx={{ borderRadius: 1 }}>
              This action cannot be undone. The document will be permanently deleted.
            </Alert>
          </Stack>
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            size="small"
            onClick={() => setDeleteDialogOpen(false)}
          >
            Cancel
          </Button>
          <Button
            size="small"
            variant="contained"
            color="error"
            onClick={handleDeleteConfirm}
            startIcon={<DeleteIcon />}
          >
            Delete Permanently
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success Snackbar */}
      <Snackbar
        open={success}
        autoHideDuration={3000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert severity="success" sx={{ width: '100%' }} onClose={() => setSuccess(false)}>
          {successMessage}
        </Alert>
      </Snackbar>
    </>
  );
};

export default ViewAllDoc;