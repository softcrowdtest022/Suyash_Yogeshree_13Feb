import React, { useState, useEffect, useCallback } from 'react';
import {
  // Layout components
  Box,
  Paper,
  Grid,
  Container,
  
  // Form components
  TextField,
  FormControl,
  FormHelperText,
  InputLabel,
  Select,
  MenuItem,
  Autocomplete,
  Checkbox,
  FormControlLabel,
  RadioGroup,
  Radio,
  
  // Feedback components
  Alert,
  Snackbar,
  CircularProgress,
  
  // Data display
  Typography,
  Chip,
  Divider,
  Card,
  CardContent,
  Avatar,
  LinearProgress,
  
  // Buttons and actions
  Button,
  IconButton,
  
  // Surfaces
  styled,
  
  // Utils
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  
  // Lists
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemSecondaryAction,
  
  // Progress
  Stepper,
  Step,
  StepLabel,
  StepConnector,
  stepConnectorClasses,
  
} from '@mui/material';
import { 
  Close as CloseIcon,
  CloudUpload as CloudUploadIcon,
  CheckCircle as CheckCircleIcon,
  CheckCircleOutline as CheckCircleOutlineIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  Refresh as RefreshIcon,
  Visibility as VisibilityIcon,
  Delete as DeleteIcon,
  Description as DescriptionIcon,
  PictureAsPdf as PdfIcon,
  Image as ImageIcon,
  InsertDriveFile as FileIcon,
  AttachFile as AttachIcon,
  Add as AddIcon,
  Remove as RemoveIcon,
  Upload as UploadIcon,
  Clear as ClearIcon,
  Folder as FolderIcon,
  Person as PersonIcon,
  Badge as BadgeIcon,
  School as SchoolIcon,
  Work as WorkIcon,
  Assignment as AssignmentIcon,
  Verified as VerifiedIcon,
  AccountBalance as AccountBalanceIcon,
  CreditCard as CreditCardIcon,
  Receipt as ReceiptIcon
} from '@mui/icons-material';
import axios from 'axios';
import BASE_URL from '../../../../config/Config';
import { useDropzone } from 'react-dropzone';

// 🔥 Document Type Enum from your schema
const DOCUMENT_TYPES = [
  'resume', 
  'offer_letter', 
  'appointment_letter', 
  'ctc_breakdown',
  'aadhar', 
  'pan', 
  'passport', 
  'voter_id', 
  'driving_license',
  'educational_certificate', 
  'experience_certificate', 
  'salary_slip',
  'bank_statement', 
  'photograph', 
  'other'
];

// Document type metadata for UI display
const documentTypeConfig = {
  // Employment Documents
  resume: { 
    label: 'Resume/CV', 
    category: 'Employment Documents',
    icon: <DescriptionIcon />, 
    acceptedTypes: ['pdf'] 
  },
  offer_letter: { 
    label: 'Offer Letter', 
    category: 'Employment Documents',
    icon: <AssignmentIcon />, 
    acceptedTypes: ['pdf'] 
  },
  appointment_letter: { 
    label: 'Appointment Letter', 
    category: 'Employment Documents',
    icon: <AssignmentIcon />, 
    acceptedTypes: ['pdf'] 
  },
  ctc_breakdown: { 
    label: 'CTC Breakdown', 
    category: 'Employment Documents',
    icon: <ReceiptIcon />, 
    acceptedTypes: ['pdf'] 
  },
  
  // Identity Documents
  aadhar: { 
    label: 'Aadhar Card', 
    category: 'Identity Documents',
    icon: <BadgeIcon />, 
    acceptedTypes: ['pdf', 'image'] 
  },
  pan: { 
    label: 'PAN Card', 
    category: 'Identity Documents',
    icon: <BadgeIcon />, 
    acceptedTypes: ['pdf', 'image'] 
  },
  passport: { 
    label: 'Passport', 
    category: 'Identity Documents',
    icon: <BadgeIcon />, 
    acceptedTypes: ['pdf', 'image'] 
  },
  voter_id: { 
    label: 'Voter ID', 
    category: 'Identity Documents',
    icon: <BadgeIcon />, 
    acceptedTypes: ['pdf', 'image'] 
  },
  driving_license: { 
    label: 'Driving License', 
    category: 'Identity Documents',
    icon: <BadgeIcon />, 
    acceptedTypes: ['pdf', 'image'] 
  },
  
  // Educational Documents
  educational_certificate: { 
    label: 'Educational Certificate', 
    category: 'Educational Documents',
    icon: <SchoolIcon />, 
    acceptedTypes: ['pdf'] 
  },
  
  // Experience Documents
  experience_certificate: { 
    label: 'Experience Certificate', 
    category: 'Experience Documents',
    icon: <WorkIcon />, 
    acceptedTypes: ['pdf'] 
  },
  salary_slip: { 
    label: 'Salary Slip', 
    category: 'Experience Documents',
    icon: <ReceiptIcon />, 
    acceptedTypes: ['pdf'] 
  },
  
  // Financial Documents
  bank_statement: { 
    label: 'Bank Statement', 
    category: 'Financial Documents',
    icon: <AccountBalanceIcon />, 
    acceptedTypes: ['pdf'] 
  },
  
  // Other Documents
  photograph: { 
    label: 'Photograph', 
    category: 'Other Documents',
    icon: <ImageIcon />, 
    acceptedTypes: ['image'] 
  },
  other: { 
    label: 'Other', 
    category: 'Other Documents',
    icon: <FileIcon />, 
    acceptedTypes: ['pdf', 'image'] 
  }
};

// Group document types by category for organized display
const getDocumentCategories = () => {
  const categories = {};
  
  DOCUMENT_TYPES.forEach(type => {
    const config = documentTypeConfig[type];
    if (config) {
      if (!categories[config.category]) {
        categories[config.category] = [];
      }
      categories[config.category].push({
        id: type,
        label: config.label,
        icon: config.icon,
        acceptedTypes: config.acceptedTypes
      });
    }
  });
  
  // Convert to array format for rendering
  return Object.entries(categories).map(([category, types]) => ({
    category,
    types
  }));
};

// 🔥 Modern Stepper Connector with Gradient
const ColorConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage: 'linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor: '#eaeaf0',
    borderRadius: 1,
  },
}));

// Styled components
const UploadArea = styled(Paper)(({ theme, isDragActive, hasError }) => ({
  border: `2px dashed ${hasError ? '#f44336' : (isDragActive ? '#1976D2' : '#E0E0E0')}`,
  borderRadius: 1,
  backgroundColor: isDragActive ? '#E3F2FD' : '#F8FAFC',
  padding: '32px',
  textAlign: 'center',
  cursor: 'pointer',
  transition: 'all 0.2s',
  '&:hover': {
    borderColor: '#1976D2',
    backgroundColor: '#F0F7FF'
  }
}));

const FileChip = styled(Chip)(({ theme, fileType }) => {
  const colors = {
    pdf: { bg: '#FFEBEE', color: '#C62828' },
    image: { bg: '#E8F5E9', color: '#2E7D32' },
    document: { bg: '#E3F2FD', color: '#1976D2' },
    other: { bg: '#F5F5F5', color: '#616161' }
  };
  const color = colors[fileType] || colors.other;
  
  return {
    backgroundColor: color.bg,
    color: color.color,
    '& .MuiChip-icon': {
      color: color.color
    }
  };
});

const DocumentTypeCard = styled(Card)(({ theme, selected }) => ({
  cursor: 'pointer',
  border: selected ? '2px solid #1976D2' : '1px solid #E0E0E0',
  borderRadius: 1,
  transition: 'all 0.2s',
  '&:hover': {
    borderColor: '#1976D2',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  }
}));

const UploadDoc = ({ open, onClose, onUpload, candidateId: propCandidateId }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    candidateId: propCandidateId || '',
    document: null,
    documentType: '',
    documentCategory: '',
    documentName: '',
    description: '',
    issueDate: '',
    expiryDate: '',
    issuingAuthority: '',
    documentNumber: '',
    verified: false,
    isConfidential: false,
    tags: [],
    remarks: ''
  });

  // File state
  const [selectedFile, setSelectedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [fileType, setFileType] = useState('');
  const [fileSize, setFileSize] = useState(0);
  const [uploadProgress, setUploadProgress] = useState(0);

  // Dropdown states
  const [candidates, setCandidates] = useState([]);
  const [candidateLoading, setCandidateLoading] = useState(false);
  const [candidateSearch, setCandidateSearch] = useState('');
  const [candidateOpen, setCandidateOpen] = useState(false);
  const [candidatePage, setCandidatePage] = useState(1);
  const [candidateTotalPages, setCandidateTotalPages] = useState(1);
  const [candidateInputValue, setCandidateInputValue] = useState('');

  // Tags input
  const [tagInput, setTagInput] = useState('');

  // Upload state
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [success, setSuccess] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [retryCount, setRetryCount] = useState(0);

  // Steps definition
  const steps = ['Select Candidate', 'Upload Document', 'Document Details', 'Review & Upload'];

  // Get document categories for UI display
  const documentCategories = getDocumentCategories();

  // Flatten document types for easy lookup
  const allDocumentTypes = DOCUMENT_TYPES.map(type => ({
    id: type,
    label: documentTypeConfig[type]?.label || type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
    icon: documentTypeConfig[type]?.icon || <FileIcon />,
    acceptedTypes: documentTypeConfig[type]?.acceptedTypes || ['pdf', 'image']
  }));

  // Fetch candidates
  const fetchCandidates = async (search = '', page = 1) => {
    setCandidateLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${BASE_URL}/api/candidates`, {
        headers: {
          'Authorization': `Bearer ${token}`
        },
        params: {
          page: page,
          limit: 10,
          search: search
        }
      });

      if (response.data.success) {
        if (page === 1) {
          setCandidates(response.data.data || []);
        } else {
          setCandidates(prev => [...prev, ...(response.data.data || [])]);
        }
        setCandidateTotalPages(response.data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error('Error fetching candidates:', err);
    } finally {
      setCandidateLoading(false);
    }
  };

  // Load candidates when dropdown opens
  useEffect(() => {
    if (candidateOpen) {
      fetchCandidates(candidateSearch, 1);
    }
  }, [candidateOpen]);

  // Search candidates with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (candidateOpen) {
        setCandidatePage(1);
        fetchCandidates(candidateSearch, 1);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [candidateSearch, candidateOpen]);

  // Handle candidate scroll load more
  const handleCandidateScroll = (event) => {
    const listboxNode = event.currentTarget;
    if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight - 50) {
      if (candidatePage < candidateTotalPages && !candidateLoading) {
        const nextPage = candidatePage + 1;
        setCandidatePage(nextPage);
        fetchCandidates(candidateSearch, nextPage);
      }
    }
  };

  // File drop handler
  const onDrop = useCallback((acceptedFiles, rejectedFiles) => {
    // Handle rejected files
    if (rejectedFiles.length > 0) {
      const errors = rejectedFiles[0].errors;
      if (errors[0].code === 'file-too-large') {
        setError('File size exceeds 10MB limit');
      } else if (errors[0].code === 'file-invalid-type') {
        setError('Invalid file type. Please upload PDF or image files.');
      } else {
        setError('File upload failed. Please try again.');
      }
      return;
    }

    // Handle accepted files
    const file = acceptedFiles[0];
    if (file) {
      processSelectedFile(file);
    }
  }, []);

  // Configure dropzone
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.bmp']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  // Process selected file
  const processSelectedFile = (file) => {
    setSelectedFile(file);
    setFileSize(file.size);
    
    // Determine file type
    if (file.type === 'application/pdf') {
      setFileType('pdf');
    } else if (file.type.startsWith('image/')) {
      setFileType('image');
    } else {
      setFileType('other');
    }

    // Create preview for images
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFilePreview(reader.result);
      };
      reader.readAsDataURL(file);
    } else {
      setFilePreview(null);
    }

    // Auto-set document name from filename
    const fileName = file.name.replace(/\.[^/.]+$/, ""); // Remove extension
    setFormData(prev => ({
      ...prev,
      documentName: fileName
    }));

    // Clear any previous errors
    setError('');
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    setFileType('');
    setFileSize(0);
    setUploadProgress(0);
  };

  const handleChange = (e) => {
    const { name, value, checked, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear field error when user types
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleDocumentTypeSelect = (typeId) => {
    setFormData(prev => ({
      ...prev,
      documentType: typeId
    }));
    
    // Auto-set category based on selected type
    const selectedDoc = documentTypeConfig[typeId];
    if (selectedDoc) {
      setFormData(prev => ({
        ...prev,
        documentCategory: selectedDoc.category || ''
      }));
    }

    if (validationErrors.documentType) {
      setValidationErrors(prev => ({
        ...prev,
        documentType: ''
      }));
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      handleAddTag();
    }
  };

  const validateStep = (step) => {
    const errors = {};

    if (step === 0) {
      if (!formData.candidateId) {
        errors.candidateId = 'Please select a candidate';
      }
    } else if (step === 1) {
      if (!selectedFile) {
        errors.document = 'Please select a document to upload';
      }
    } else if (step === 2) {
      if (!formData.documentType) {
        errors.documentType = 'Please select document type';
      } else if (!DOCUMENT_TYPES.includes(formData.documentType)) {
        errors.documentType = 'Invalid document type selected';
      }
      
      if (!formData.documentName.trim()) {
        errors.documentName = 'Document name is required';
      }
      if (formData.documentType === 'other' && !formData.description.trim()) {
        errors.description = 'Description is required for other document types';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prevStep) => prevStep + 1);
      setError('');
    } else {
      setError('Please complete all required fields in this section');
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setError('');
  };

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setError('');
    setValidationErrors({});
    // Small delay before retrying
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  const handleSubmit = async () => {
    if (!validateStep(2)) {
      setError('Please complete all required fields');
      return;
    }

    setUploading(true);
    setError('');
    setValidationErrors({});
    setUploadProgress(0);

    try {
      const token = localStorage.getItem('token');

      // Create FormData object for multipart/form-data upload
      const formDataToSend = new FormData();
      
      // Append file
      formDataToSend.append('document', selectedFile);
      
      // Append other fields as text
      formDataToSend.append('candidateId', formData.candidateId);
      formDataToSend.append('type', formData.documentType);
      formDataToSend.append('documentName', formData.documentName);
      formDataToSend.append('description', formData.description || '');
      formDataToSend.append('issueDate', formData.issueDate || '');
      formDataToSend.append('expiryDate', formData.expiryDate || '');
      formDataToSend.append('issuingAuthority', formData.issuingAuthority || '');
      formDataToSend.append('documentNumber', formData.documentNumber || '');
      formDataToSend.append('verified', formData.verified.toString());
      formDataToSend.append('isConfidential', formData.isConfidential.toString());
      formDataToSend.append('tags', JSON.stringify(formData.tags));
      formDataToSend.append('remarks', formData.remarks || '');

      console.log('Uploading document:', {
        candidateId: formData.candidateId,
        type: formData.documentType,
        fileName: selectedFile.name,
        fileSize: selectedFile.size
      });

      const response = await axios.post(`${BASE_URL}/api/documents/upload`, formDataToSend, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(percentCompleted);
        }
      });

      if (response.data.success) {
        setUploadResult(response.data.data);
        setSuccess(true);
        
        if (onUpload) {
          onUpload(response.data.data);
        }
        
        // Auto close after success
        setTimeout(() => {
          resetForm();
          onClose();
        }, 3000);
      } else {
        setError(response.data.message || 'Failed to upload document');
      }
    } catch (err) {
      console.error('Error uploading document:', err);
      
      if (err.response) {
        console.error('Error response:', err.response.data);
        
        const errorMessage = err.response.data?.message || 'Failed to upload document';
        
        // Handle specific error cases
        if (err.response.status === 400) {
          if (err.response.data.errors) {
            // Handle field validation errors
            const fieldErrors = {};
            err.response.data.errors.forEach(error => {
              fieldErrors[error.field] = error.message;
            });
            setValidationErrors(fieldErrors);
            setError('Please fix the validation errors');
          } else if (errorMessage.includes('duplicate') || errorMessage.includes('already exists')) {
            setError(
              <Box>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  A document with this type already exists for this candidate.
                </Typography>
                <Button
                  size="small"
                  variant="outlined"
                  startIcon={<VisibilityIcon />}
                  onClick={() => {
                    // Navigate to view documents
                    handleClose();
                    // You can add navigation logic here
                  }}
                  sx={{ mt: 1 }}
                >
                  View Documents
                </Button>
              </Box>
            );
          } else {
            setError(errorMessage);
          }
        } else if (err.response.status === 413) {
          setError('File too large. Maximum size is 10MB.');
        } else if (err.response.status === 415) {
          setError('Unsupported file type. Please upload PDF or image files.');
        } else if (err.response.status === 404) {
          setError('Candidate not found. Please select a valid candidate.');
        } else {
          setError(errorMessage);
        }
      } else {
        setError('Network error. Please check your connection and try again.');
      }
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      candidateId: propCandidateId || '',
      document: null,
      documentType: '',
      documentCategory: '',
      documentName: '',
      description: '',
      issueDate: '',
      expiryDate: '',
      issuingAuthority: '',
      documentNumber: '',
      verified: false,
      isConfidential: false,
      tags: [],
      remarks: ''
    });
    setSelectedFile(null);
    setFilePreview(null);
    setFileType('');
    setFileSize(0);
    setUploadProgress(0);
    setTagInput('');
    setError('');
    setValidationErrors({});
    setUploadResult(null);
    setSuccess(false);
    setActiveStep(0);
    setCandidateSearch('');
    setCandidateInputValue('');
    setRetryCount(0);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Format file size
  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Get file icon based on type
  const getFileIcon = () => {
    if (fileType === 'pdf') return <PdfIcon sx={{ fontSize: 40, color: '#C62828' }} />;
    if (fileType === 'image') return <ImageIcon sx={{ fontSize: 40, color: '#2E7D32' }} />;
    return <FileIcon sx={{ fontSize: 40, color: '#1976D2' }} />;
  };

  // Get document type label
  const getDocumentTypeLabel = (typeId) => {
    return documentTypeConfig[typeId]?.label || typeId.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Stack spacing={2}>
            {/* Select Candidate */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Select Candidate
              </Typography>

              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12 }}>
                  <Autocomplete
                    size="small"
                    id="candidate-autocomplete"
                    open={candidateOpen}
                    onOpen={() => setCandidateOpen(true)}
                    onClose={() => setCandidateOpen(false)}
                    options={candidates}
                    loading={candidateLoading}
                    value={formData.candidateId ? candidates.find(c => c._id === formData.candidateId) || null : null}
                    onChange={(event, newValue) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        candidateId: newValue?._id || null 
                      }));
                      if (validationErrors.candidateId) {
                        setValidationErrors(prev => ({ ...prev, candidateId: '' }));
                      }
                    }}
                    inputValue={candidateInputValue}
                    onInputChange={(event, newInputValue) => {
                      setCandidateInputValue(newInputValue);
                      setCandidateSearch(newInputValue);
                    }}
                    getOptionLabel={(option) => option?.name || ''}
                    fullWidth
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Select Candidate"
                        required
                        error={!!validationErrors.candidateId}
                        helperText={validationErrors.candidateId}
                        size="small"
                        placeholder="Search by name or email"
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            borderRadius: 1
                          }
                        }}
                        InputProps={{
                          ...params.InputProps,
                          endAdornment: (
                            <>
                              {candidateLoading ? <CircularProgress size={16} /> : null}
                              {params.InputProps.endAdornment}
                            </>
                          ),
                        }}
                      />
                    )}
                    renderOption={(props, option) => (
                      <MenuItem {...props} key={option._id} sx={{ py: 0.5 }}>
                        <Box>
                          <Typography variant="body2">{option.name}</Typography>
                          <Typography variant="caption" color="textSecondary">
                            {option.email} • {option.phone}
                          </Typography>
                        </Box>
                      </MenuItem>
                    )}
                    ListboxProps={{ onScroll: handleCandidateScroll, style: { maxHeight: 200 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Candidate Info (if selected) */}
            {formData.candidateId && candidates.find(c => c._id === formData.candidateId) && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                  Candidate Information
                </Typography>
                
                <Grid container spacing={1.5}>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                      {candidates.find(c => c._id === formData.candidateId)?.name}
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Email</Typography>
                    <Typography variant="body2">
                      {candidates.find(c => c._id === formData.candidateId)?.email}
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Phone</Typography>
                    <Typography variant="body2">
                      {candidates.find(c => c._id === formData.candidateId)?.phone}
                    </Typography>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Current Status</Typography>
                    <Chip 
                      label={candidates.find(c => c._id === formData.candidateId)?.status || 'Active'} 
                      size="small"
                      sx={{ backgroundColor: '#E3F2FD', color: '#1976D2', height: '24px' }}
                    />
                  </Grid>
                </Grid>
              </Paper>
            )}
          </Stack>
        );

      case 1:
        return (
          <Stack spacing={2}>
            {/* File Upload Area */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Upload Document *
              </Typography>

              {!selectedFile ? (
                <UploadArea
                  {...getRootProps()}
                  isDragActive={isDragActive}
                  hasError={!!validationErrors.document}
                >
                  <input {...getInputProps()} />
                  <CloudUploadIcon sx={{ fontSize: 48, color: '#1976D2', mb: 2 }} />
                  <Typography variant="body1" gutterBottom>
                    {isDragActive ? 'Drop the file here' : 'Drag & drop a file here, or click to select'}
                  </Typography>
                  <Typography variant="caption" color="textSecondary">
                    Supported formats: PDF, PNG, JPG, JPEG, GIF, BMP (Max 10MB)
                  </Typography>
                </UploadArea>
              ) : (
                <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', borderRadius: 1, border: '1px solid #E0E0E0' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box sx={{ mr: 2 }}>
                      {getFileIcon()}
                    </Box>
                    <Box sx={{ flex: 1 }}>
                      <Typography variant="subtitle2">{selectedFile.name}</Typography>
                      <Typography variant="caption" color="textSecondary">
                        {formatFileSize(fileSize)} • {fileType.toUpperCase()}
                      </Typography>
                    </Box>
                    <IconButton size="small" onClick={handleRemoveFile} sx={{ color: '#666' }}>
                      <DeleteIcon />
                    </IconButton>
                  </Box>

                  {filePreview && fileType === 'image' && (
                    <Box sx={{ mt: 2, textAlign: 'center' }}>
                      <img 
                        src={filePreview} 
                        alt="Preview" 
                        style={{ maxHeight: 150, maxWidth: '100%', borderRadius: '4px' }} 
                      />
                    </Box>
                  )}

                  {uploadProgress > 0 && uploadProgress < 100 && (
                    <Box sx={{ mt: 2 }}>
                      <LinearProgress variant="determinate" value={uploadProgress} />
                      <Typography variant="caption" color="textSecondary" sx={{ mt: 0.5, display: 'block' }}>
                        Uploading: {uploadProgress}%
                      </Typography>
                    </Box>
                  )}
                </Paper>
              )}

              {validationErrors.document && (
                <FormHelperText error sx={{ mt: 1 }}>
                  {validationErrors.document}
                </FormHelperText>
              )}
            </Paper>

            {/* File Guidelines */}
            <Alert severity="info" sx={{ borderRadius: 1 }} icon={<InfoIcon />}>
              <Typography variant="body2">
                <strong>Document Guidelines:</strong>
              </Typography>
              <List dense disablePadding>
                <ListItem sx={{ py: 0 }}>
                  <ListItemIcon sx={{ minWidth: 24 }}>
                    <CheckCircleOutlineIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                  </ListItemIcon>
                  <ListItemText primary="Files must be clear and legible" />
                </ListItem>
                <ListItem sx={{ py: 0 }}>
                  <ListItemIcon sx={{ minWidth: 24 }}>
                    <CheckCircleOutlineIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                  </ListItemIcon>
                  <ListItemText primary="Maximum file size: 10MB" />
                </ListItem>
                <ListItem sx={{ py: 0 }}>
                  <ListItemIcon sx={{ minWidth: 24 }}>
                    <CheckCircleOutlineIcon sx={{ fontSize: 16, color: '#4CAF50' }} />
                  </ListItemIcon>
                  <ListItemText primary="Supported formats: PDF, PNG, JPG, JPEG, GIF, BMP" />
                </ListItem>
              </List>
            </Alert>
          </Stack>
        );

      case 2:
        return (
          <Stack spacing={2}>
            {/* Document Type Selection - Using enum values */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Document Type *
              </Typography>

              {documentCategories.map((category) => (
                <Box key={category.category} sx={{ mb: 2 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    {category.category}
                  </Typography>
                  <Grid container spacing={1}>
                    {category.types.map((type) => (
                      <Grid size={{ xs: 12, sm: 6, md: 4 }} key={type.id}>
                        <DocumentTypeCard
                          selected={formData.documentType === type.id}
                          onClick={() => handleDocumentTypeSelect(type.id)}
                        >
                          <CardContent sx={{ p: 1.5, '&:last-child': { pb: 1.5 } }}>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <Box sx={{ color: formData.documentType === type.id ? '#1976D2' : '#666', mr: 1 }}>
                                {type.icon}
                              </Box>
                              <Typography variant="body2">{type.label}</Typography>
                              {formData.documentType === type.id && (
                                <CheckCircleIcon sx={{ ml: 'auto', fontSize: 16, color: '#1976D2' }} />
                              )}
                            </Box>
                          </CardContent>
                        </DocumentTypeCard>
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              ))}

              {validationErrors.documentType && (
                <FormHelperText error sx={{ mt: 1 }}>
                  {validationErrors.documentType}
                </FormHelperText>
              )}
            </Paper>

            {/* Document Details */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Document Details
              </Typography>

              <Grid container spacing={1.5}>
                <Grid size={{ xs: 12 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Document Name *"
                    name="documentName"
                    value={formData.documentName}
                    onChange={handleChange}
                    error={!!validationErrors.documentName}
                    helperText={validationErrors.documentName}
                    placeholder="Enter a descriptive name for this document"
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Document Number"
                    name="documentNumber"
                    value={formData.documentNumber}
                    onChange={handleChange}
                    placeholder="e.g., Aadhar number, PAN number"
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Issuing Authority"
                    name="issuingAuthority"
                    value={formData.issuingAuthority}
                    onChange={handleChange}
                    placeholder="e.g., UIDAI, Income Tax Dept"
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Issue Date"
                    name="issueDate"
                    type="date"
                    value={formData.issueDate}
                    onChange={handleChange}
                    InputLabelProps={{ shrink: true }}
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Expiry Date"
                    name="expiryDate"
                    type="date"
                    value={formData.expiryDate}
                    onChange={handleChange}
                    InputLabelProps={{ shrink: true }}
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>

                <Grid size={{ xs: 12 }}>
                  <TextField
                    fullWidth
                    size="small"
                    label="Description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    multiline
                    rows={2}
                    placeholder="Brief description of the document"
                    error={!!validationErrors.description}
                    helperText={validationErrors.description}
                    sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                  />
                </Grid>
              </Grid>
            </Paper>

            {/* Tags */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Tags (Optional)
              </Typography>

              <Box sx={{ display: 'flex', gap: 1, mb: 1 }}>
                <TextField
                  size="small"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Add a tag and press Enter"
                  sx={{ flex: 1 }}
                />
                <Button
                  variant="outlined"
                  onClick={handleAddTag}
                  disabled={!tagInput.trim()}
                  size="small"
                >
                  Add Tag
                </Button>
              </Box>

              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {formData.tags.map((tag) => (
                  <Chip
                    key={tag}
                    label={tag}
                    onDelete={() => handleRemoveTag(tag)}
                    size="small"
                    sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                  />
                ))}
              </Box>
            </Paper>

            {/* Additional Options */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Additional Options
              </Typography>

              <FormControlLabel
                control={
                  <Checkbox
                    name="verified"
                    checked={formData.verified}
                    onChange={handleChange}
                    size="small"
                  />
                }
                label="Mark as verified"
              />

              <FormControlLabel
                control={
                  <Checkbox
                    name="isConfidential"
                    checked={formData.isConfidential}
                    onChange={handleChange}
                    size="small"
                  />
                }
                label="Confidential document"
                sx={{ ml: 2 }}
              />

              <Box sx={{ mt: 2 }}>
                <TextField
                  fullWidth
                  size="small"
                  label="Remarks"
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleChange}
                  multiline
                  rows={2}
                  placeholder="Any additional remarks or notes..."
                  sx={{ '& .MuiOutlinedInput-root': { borderRadius: 1 } }}
                />
              </Box>
            </Paper>
          </Stack>
        );

      case 3:
        return (
          <Stack spacing={2}>
            {/* Review Summary */}
            <Paper sx={{ p: 2, backgroundColor: '#FFFFFF', borderRadius: 1, border: '1px solid #E0E0E0' }}>
              <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1.5, fontWeight: 600, fontSize: '0.9rem' }}>
                Review Upload Details
              </Typography>

              <Grid container spacing={2}>
                {/* Candidate Information */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Candidate
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Typography variant="body2">
                      {candidates.find(c => c._id === formData.candidateId)?.name}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {candidates.find(c => c._id === formData.candidateId)?.email}
                    </Typography>
                  </Paper>
                </Grid>

                {/* File Information */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    File
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      {getFileIcon()}
                      <Box sx={{ ml: 1 }}>
                        <Typography variant="body2">{selectedFile?.name}</Typography>
                        <Typography variant="caption" color="textSecondary">
                          {formatFileSize(fileSize)} • {fileType.toUpperCase()}
                        </Typography>
                      </Box>
                    </Box>
                  </Paper>
                </Grid>

                {/* Document Details */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Document Details
                  </Typography>
                  <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                    <Grid container spacing={1}>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Type</Typography>
                        <Typography variant="body2">
                          {getDocumentTypeLabel(formData.documentType)}
                        </Typography>
                      </Grid>
                      <Grid size={{ xs: 6 }}>
                        <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Name</Typography>
                        <Typography variant="body2">{formData.documentName}</Typography>
                      </Grid>
                      {formData.documentNumber && (
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Document No.</Typography>
                          <Typography variant="body2">{formData.documentNumber}</Typography>
                        </Grid>
                      )}
                      {formData.issuingAuthority && (
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Issuing Authority</Typography>
                          <Typography variant="body2">{formData.issuingAuthority}</Typography>
                        </Grid>
                      )}
                      {formData.issueDate && (
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Issue Date</Typography>
                          <Typography variant="body2">{formatDate(formData.issueDate)}</Typography>
                        </Grid>
                      )}
                      {formData.expiryDate && (
                        <Grid size={{ xs: 6 }}>
                          <Typography variant="caption" sx={{ color: '#666', display: 'block' }}>Expiry Date</Typography>
                          <Typography variant="body2">{formatDate(formData.expiryDate)}</Typography>
                        </Grid>
                      )}
                    </Grid>
                  </Paper>
                </Grid>

                {/* Tags */}
                {formData.tags.length > 0 && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Tags
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                      {formData.tags.map(tag => (
                        <Chip
                          key={tag}
                          label={tag}
                          size="small"
                          sx={{ backgroundColor: '#E3F2FD', color: '#1976D2' }}
                        />
                      ))}
                    </Box>
                  </Grid>
                )}

                {/* Status Flags */}
                <Grid size={{ xs: 12 }}>
                  <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                    Status
                  </Typography>
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    {formData.verified && (
                      <Chip
                        icon={<VerifiedIcon />}
                        label="Verified"
                        size="small"
                        sx={{ backgroundColor: '#E8F5E9', color: '#2E7D32' }}
                      />
                    )}
                    {formData.isConfidential && (
                      <Chip
                        label="Confidential"
                        size="small"
                        sx={{ backgroundColor: '#FFEBEE', color: '#C62828' }}
                      />
                    )}
                  </Box>
                </Grid>

                {/* Remarks */}
                {formData.remarks && (
                  <Grid size={{ xs: 12 }}>
                    <Typography variant="caption" sx={{ color: '#666', display: 'block', mb: 1 }}>
                      Remarks
                    </Typography>
                    <Paper sx={{ p: 1.5, backgroundColor: '#F8FAFC', borderRadius: 1 }}>
                      <Typography variant="body2">{formData.remarks}</Typography>
                    </Paper>
                  </Grid>
                )}
              </Grid>
            </Paper>

            {/* Upload Warning */}
            <Alert severity="warning" sx={{ borderRadius: 1 }} icon={<WarningIcon />}>
              <Typography variant="body2">
                <strong>Please verify:</strong> Once uploaded, this document will be associated with the candidate's profile.
                Ensure all information is accurate before proceeding.
              </Typography>
            </Alert>

            {/* Validation Errors */}
            {Object.keys(validationErrors).length > 0 && (
              <Alert severity="error" sx={{ borderRadius: 1 }}>
                <Typography variant="body2" fontWeight={600}>Please fix the following:</Typography>
                <Box component="ul" sx={{ m: 1, pl: 2 }}>
                  {Object.values(validationErrors).map((err, index) => (
                    <li key={index}>
                      <Typography variant="caption">{err}</Typography>
                    </li>
                  ))}
                </Box>
              </Alert>
            )}

            {/* General Error */}
            {error && !Object.keys(validationErrors).length && (
              <Alert 
                severity="error" 
                sx={{ borderRadius: 1 }}
                action={
                  typeof error !== 'string' ? null : (
                    <Button color="inherit" size="small" onClick={() => setError('')}>
                      Dismiss
                    </Button>
                  )
                }
              >
                {error}
              </Alert>
            )}
          </Stack>
        );

      default:
        return null;
    }
  };

  // Helper function to format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 1.5,
          maxHeight: '95vh',
          overflow: 'auto'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: '1px solid #E0E0E0',
        py: 1.5,
        px: 2,
        backgroundColor: '#F8FAFC',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography variant="subtitle1" component="div" sx={{ fontWeight: 600, color: '#101010' }}>
          Upload Document
        </Typography>
        {!uploading && !success && (
          <IconButton size="small" onClick={handleClose} sx={{ color: '#666' }}>
            <CloseIcon fontSize="small" />
          </IconButton>
        )}
      </DialogTitle>

      {!success ? (
        <>
          <DialogContent sx={{ p: 2, overflow: 'auto' }}>
            {/* Stepper */}
            <Stepper
              activeStep={activeStep}
              alternativeLabel
              connector={<ColorConnector />}
              sx={{ mb: 2, mt: 1 }}
            >
              {steps.map((label) => (
                <Step key={label}>
                  <StepLabel>
                    <Typography fontWeight={500} fontSize="0.85rem">{label}</Typography>
                  </StepLabel>
                </Step>
              ))}
            </Stepper>

            {renderStepContent(activeStep)}
          </DialogContent>

          <DialogActions sx={{
            px: 2,
            py: 1.5,
            borderTop: '1px solid #E0E0E0',
            backgroundColor: '#F8FAFC',
            justifyContent: 'space-between'
          }}>
            <Button
              onClick={handleBack}
              disabled={activeStep === 0 || uploading}
              size="small"
              sx={{ color: '#666' }}
            >
              Back
            </Button>
            <Box>
              <Button
                onClick={handleClose}
                disabled={uploading}
                size="small"
                sx={{ mr: 1, color: '#666' }}
              >
                Cancel
              </Button>
              {activeStep === steps.length - 1 ? (
                <Button
                  variant="contained"
                  onClick={handleSubmit}
                  disabled={uploading || !selectedFile}
                  size="small"
                  startIcon={uploading ? <CircularProgress size={16} color="inherit" /> : <CloudUploadIcon />}
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  {uploading ? `Uploading ${uploadProgress}%` : 'Upload Document'}
                </Button>
              ) : (
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={uploading}
                  size="small"
                  sx={{
                    backgroundColor: '#1976D2',
                    '&:hover': { backgroundColor: '#1565C0' }
                  }}
                >
                  Next
                </Button>
              )}
            </Box>
          </DialogActions>
        </>
      ) : (
        <DialogContent sx={{ p: 3, textAlign: 'center' }}>
          <Box sx={{ py: 3 }}>
            <VerifiedIcon sx={{ fontSize: 64, color: '#4CAF50', mb: 2 }} />
            <Typography variant="h5" sx={{ mb: 2, color: '#101010', fontWeight: 600 }}>
              Document Uploaded Successfully!
            </Typography>
            <Typography variant="body1" color="textSecondary" sx={{ mb: 3 }}>
              Your document has been uploaded and associated with the candidate's profile.
            </Typography>
            
            {uploadResult && (
              <Paper sx={{ p: 2, backgroundColor: '#F8FAFC', mb: 3, maxWidth: 400, mx: 'auto' }}>
                <Typography variant="subtitle2" sx={{ color: '#1976D2', mb: 1 }}>
                  Upload Details
                </Typography>
                <Typography variant="body2">
                  <strong>Filename:</strong> {uploadResult.filename}
                </Typography>
                <Typography variant="body2">
                  <strong>Type:</strong> {getDocumentTypeLabel(uploadResult.type)}
                </Typography>
                <Typography variant="body2">
                  <strong>Path:</strong> {uploadResult.path}
                </Typography>
              </Paper>
            )}

            <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleClose}
                startIcon={<CloseIcon />}
              >
                Close
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  resetForm();
                  setSuccess(false);
                }}
                startIcon={<CloudUploadIcon />}
              >
                Upload Another
              </Button>
            </Box>
          </Box>
        </DialogContent>
      )}
    </Dialog>
  );
};

export default UploadDoc;